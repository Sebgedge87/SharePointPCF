(()=>{
// read-only copy: for a client or support team. Everything can be viewed, searched, checked and diagrammed; nothing can be changed
const RO=typeof DME_MODE!=='undefined'&&DME_MODE==='readonly';
const DME_VERSION="6.0.1";   // from package.json, written in by build.py
// the page's own source, taken before anything on it changes, so "Read-only copy" can write a copy of this same page
const PAGE_SRC=RO?null:{head:document.head.outerHTML,body:document.body.innerHTML,lang:document.documentElement.getAttribute('lang')||'en'};
// In Dataverse the page, this code and each library are separate web resources. If one did not load, or one is from
// another version (an import that did not finish, or an old copy cached by the browser), say so before anything else.
const APP_BUILD="6.0.1-8540880d2e";
(()=>{
  const miss=[['XLSX','SheetJS (lib/xlsx.full.min.js)'],['ExcelJS','ExcelJS (lib/exceljs.min.js)'],['JSZip','JSZip (lib/jszip.min.js)']].filter(([g])=>typeof window[g]==='undefined').map(x=>x[1]);
  const mixed=typeof DME_BUILD!=='undefined'&&DME_BUILD!==APP_BUILD;
  if(!miss.length&&!mixed) return;
  const msg=miss.length?'Part of the page did not load: '+miss.join(', ')+'. Check that every web resource in the Data Model Explorer solution was imported and published.':'The parts of this page are from different versions. Publish all customizations, then reload the page with Ctrl+F5.';
  const d=document.createElement('div'); d.id='partsbad'; d.setAttribute('role','alert');
  d.style.cssText='position:fixed;left:0;right:0;top:0;z-index:99999;background:#b42318;color:#fff;padding:10px 16px;font:600 14px/1.4 system-ui,sans-serif';
  d.textContent=msg; document.body.appendChild(d);
})();
if(RO){document.body.classList.add('ro'); document.title+=' (read-only)'}
'use strict';
/* ---------- helpers ---------- */
const $=(s,r=document)=>r.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const XLSX_OPTS={type:'array'}; // how every workbook is read
const clean=v=>{
  if(v===null||v===undefined) return '';
  if(v===true) return 'True'; if(v===false) return 'False';
  return String(v).replace(/_x000D_/g,'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').replace(/[ \t]+\n/g,'\n').replace(/\n{2,}/g,'\n').trim();
};
const norm=s=>String(s||'').toLowerCase().replace(/^formus_?/,'').replace(/[^a-z0-9]/g,'');
// set() returns false when the browser refuses to store (quota, private mode, blocked site data)
const store={get(k){try{return JSON.parse(localStorage.getItem(k))}catch(e){return null}},set(k,v){try{if(v==null)localStorage.removeItem(k);else localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}},del(k){try{localStorage.removeItem(k)}catch(e){}}};
// header indicator: are the edits safely stored in this browser?
function saveState(ok,msg){
  const el=$('#saveState'); if(!el) return;
  el.className='savestate '+(ok?'ok':'bad');
  el.textContent=ok?'kept in browser':'not saved: export now';
  el.title=msg||(ok?'Your edits are stored in this browser and survive a reload.':'This browser would not store your edits. They will be lost on reload. Export the change log or the workbook now.');
  if(!ok&&!saveState.warned){saveState.warned=true;toast('Your edits could not be saved in this browser. Export them before closing the page.')}
  if(ok) saveState.warned=false;
}
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove('show'),2200)}
const ICON_FILTER='<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M3 5h18l-7 8v6l-4 2v-8z"/></svg>';

/* ---------- state ---------- */
const S={fileName:'',sheets:[],byLogical:{},views:{},cur:null,edits:new Map(),metaEd:new Map(),pending:[],diff:null,rowOv:new Map(),ui:{density:'normal',hidden:{}},sideFilter:'',storeKey:'',collapsed:{}};
const HIDE_DEFAULT=['Schema Name','Type','Object Type Code','Relationship Name'];   // Relationship Name: optional, the solution generator names relationships when it is blank
const WIDTHS={'Logical Name':240,'Schema Name':200,'Display Name':190,'Attribute Type':150,'Description':300,'Custom Attribute':100,'Type':84,'Required Level':175,'Additional data':290,'Add to RAF Form?':190,'Comment':280,'Field Level Security':110,
 'Table':190,'Area':130,'Table Name':170,'Out of the box/custom table?':130,'Static Data?':90,'Purpose':360,'FormusPro Comments':300,'Added to ERD?':90,'Defined in data model?':110};
const ENUM_COLS=new Set(['custom attribute','required level','attribute type','type']);
S.tmplOpts={};
const nk=v=>String(v||'').toLowerCase().replace(/[^a-z0-9]/g,'');
const FREE_RE=/description|comment|additional|purpose|notes?\b|logical|schema|display name|table name|\bname$|\bid$/i;
function colValues(sh,col){
  if(sh.kind==='entity') return S.allView.items.map(x=>getVal(x.sh,x.row,col));
  return sh.rows.map(r=>getVal(sh,r,col));
}
function isChoiceCol(sh,col){
  const l=col.toLowerCase();
  if(ENUM_COLS.has(l)||(S.tmplOpts[l]&&S.tmplOpts[l].length)) return true;
  if(col==='Table'||FREE_RE.test(col)) return false;
  const key=(sh.kind==='entity'?'E':'T'+sh.idx)+'|'+l;
  S.choiceCache=S.choiceCache||{};
  if(key in S.choiceCache) return S.choiceCache[key];
  const vals=colValues(sh,col).map(v=>String(v||'').replace(/\s+/g,' ').trim()).filter(Boolean);
  const set=new Set(vals.map(nk));
  const ok=vals.length>=4&&set.size>=1&&set.size<=15&&set.size<=Math.max(2,vals.length*0.4)&&vals.every(v=>v.length<=80);
  return S.choiceCache[key]=ok;
}
function choiceOptions(sh,col){
  const m=new Map();
  const add=(v,n)=>{v=String(v||'').replace(/\s+/g,' ').trim();if(!v)return;const k=nk(v);const e=m.get(k);if(e){e.n+=n;if(n>=e.b){e.b=n;e.label=v}}else m.set(k,{label:v,n,b:n,k})};
  colValues(sh,col).forEach(v=>add(v,1));
  (S.tmplOpts[col.toLowerCase()]||[]).forEach(v=>add(v,0.5));
  return [...m.values()].sort((a,b)=>b.n-a.n||a.label.localeCompare(b.label));
}

/* ---------- parsing ---------- */
function canonHeader(h){
  const t=clean(h); const l=t.toLowerCase();
  if(l==='add to raf form?') return 'Add to RAF Form?';
  return t;
}
function parseWorkbook(wb){
  const sheets=[];
  wb.SheetNames.forEach((name,idx)=>{
    const ws=wb.Sheets[name]; if(!ws) return;
    if(name==='Change log') return; // written by this tool on export
    const m=XLSX.utils.sheet_to_json(ws,{header:1,defval:'',raw:true,blankrows:true});
    let r0=0,c0=0;try{const rg=XLSX.utils.decode_range(ws['!ref']);r0=rg.s.r;c0=rg.s.c}catch(e){}
    if(!m.length) return;
    let hi=m.findIndex(r=>clean(r[0]).toLowerCase()==='logical name'&&clean(r[1]).toLowerCase()==='schema name');
    let kind='entity';
    if(hi<0){
      kind='table';
      hi=m.findIndex(r=>r.filter(c=>clean(c)!=='').length>=3);
      if(hi<0) return;
    }
    const hdrRow=m[hi];
    // Forms:/Views: sections sit below the field list (their headers start in column B)
    const isMark=r=>kind==='entity'&&/^(forms?|views?)\s*:$/i.test(clean(m[r]&&m[r][0]));
    let fieldEnd=m.length; const marks=[];
    for(let r=hi+1;r<m.length;r++) if(isMark(r)){ if(!marks.length) fieldEnd=r; marks.push(r); }
    const width=Math.max(...m.slice(hi).map(r=>r.length));
    const colIdx=[];
    for(let c=0;c<width;c++){
      const h=clean(hdrRow[c]);
      const any=m.slice(hi+1,fieldEnd).some(r=>clean(r[c])!=='');
      if(h!==''||any) colIdx.push(c);
    }
    const cols=colIdx.map((c,i)=>canonHeader(hdrRow[c])||('Column '+(i+1)));
    const rows=[];
    for(let r=hi+1;r<fieldEnd;r++){
      const vals=colIdx.map(c=>clean(m[r][c]));
      if(vals.every(v=>v==='')) continue;
      rows.push({vals,orig:vals.slice(),r});
    }
    let kc=0; if(kind!=='entity'){const j=cols.findIndex(c=>/^table name$/i.test(c)); if(j>=0)kc=j;}
    const seen={},rowMap={};
    rows.forEach(rw=>{let k=(rw.orig[kc]||rw.orig.find(v=>v!=='')||('row '+rw.r)).toLowerCase().slice(0,80);seen[k]=(seen[k]||0)+1;if(seen[k]>1)k+='#'+seen[k];rw.key=k;rowMap[k]=rw;});
    const subs=[];
    marks.forEach((mr,k)=>{
      const end=k+1<marks.length?marks[k+1]:m.length;
      let h=-1; for(let r=mr+1;r<end;r++){if(m[r].some(c=>clean(c)!=='')){h=r;break}}
      const label=clean(m[mr][0]);
      const sub={label,title:label.replace(/:\s*$/,''),cols:[],pos:[],rows:[]};
      if(h>=0){
        const idxs=[];m[h].forEach((c,i)=>{if(clean(c)!=='')idxs.push(i)});
        sub.cols=idxs.map(i=>clean(m[h][i])); sub.pos=idxs.map(i=>i+1+c0);
        for(let r=h+1;r<end;r++){
          const vals=idxs.map(i=>clean(m[r][i]));
          if(vals.every(v=>v==='')){ if(sub.rows.length) break; else continue; }
          sub.rows.push({vals});
        }
      }
      subs.push(sub);
    });
    // meta + hints + notes
    const meta=[],hints={},notes=[],noteCells=[],metaR={},metaFree=[];
    for(let r=0;r<hi;r++){
      const cells=(m[r]||[]).map(clean);
      const nz=cells.map((v,i)=>[v,i]).filter(x=>x[0]!=='');
      if(!nz.length){if(r<hi-1) metaFree.push(r+1+r0); continue;}
      if(kind==='entity'){
        if(nz.length>=1&&cells[0]!==''&&nz.length<=2&&r<hi-1){meta.push([cells[0],cells[1]||'']);metaR[cells[0].toLowerCase()]=r+1+r0;continue;}   // every label/value row above the hint row is a table detail, however many there are
        // hint row: text sitting above header columns
        nz.forEach(([v,ci])=>{const k=colIdx.indexOf(ci);if(k>=0)hints[cols[k]]=v;});
      } else {
        notes.push(nz.map(x=>x[0]).join(' '));
        nz.forEach(([v,ci])=>noteCells.push({r:r+1+r0,c:ci+1+c0,v}));
      }
    }
    const mo={}; meta.forEach(([k,v])=>mo[k.toLowerCase()]=v);
    const sh={idx:sheets.length,name,kind,cols,rows,meta,mo,hints,notes,noteCells,subs,pos:colIdx.map(c=>c+1+c0),hdrRow:hi+1+r0,r0,
      label:kind==='entity'?(mo['entity']||name):name,
      logical:(mo['logical name']||'').toLowerCase(),schema:mo['schema name']||'',
      custom:(mo['is custom entity']||'').toLowerCase()==='true',
      area:'',colIdx:{},rowMap,hi,fieldEnd:marks.length?fieldEnd:null,c0,metaR,metaFree,metaOrig:Object.assign({},mo),metaAdded:[]};
    // table details the template has but this table lacks are added blank, so they can be filled in here
    if(kind==='entity'&&T.entityMeta&&T.entityMeta.length) T.entityMeta.forEach(k=>{if(mo[k.toLowerCase()]===undefined){meta.push([k,'']);mo[k.toLowerCase()]='';sh.metaAdded.push(k)}});
    // columns the template has but this sheet lacks are added (blank), so they can be filled in here.
    // Their header is written into the file with the first value saved in them.
    sh.tmplAdded=[];
    const tc=T.entityCols&&T.entityCols.length?(kind==='entity'?T.entityCols:((T.byName[name.toLowerCase()]||{}).cols||[])):[];
    if(tc.length){
      const have=new Set(cols.map(c=>c.toLowerCase())); let nx=Math.max(...sh.pos)+1;
      tc.forEach(c=>{if(have.has(c.toLowerCase())||/^Column \d+$/.test(c)) return; have.add(c.toLowerCase());
        cols.push(c); sh.pos.push(nx++); rows.forEach(r=>{r.vals.push('');r.orig.push('')}); sh.tmplAdded.push(c);
        const ts=kind==='entity'?T.sheets.find(t=>t.kind==='entity'&&t.hints[c]):T.byName[name.toLowerCase()];
        if(ts&&ts.hints[c]&&!hints[c]) hints[c]=ts.hints[c]});
    }
    cols.forEach((c,i)=>sh.colIdx[c]=i);
    sheets.push(sh);
  });
  // link dictionary -> entity sheets
  const dict=sheets.find(s=>s.kind==='table'&&s.cols.some(c=>/table name/i.test(c)));
  if(dict){
    dict.isDict=true; dict.label='Table Dictionary';
    const tn=dict.colIdx['Table Name'], ar=dict.colIdx['Area'];
    const ents=sheets.filter(s=>s.kind==='entity');
    const cand=e=>[e.label,e.mo['plural display name'],e.schema,e.logical,e.name.replace(/\s*\(.*\)\s*$/,'')].map(norm).filter(Boolean);
    const linked=new Set();
    dict.rows.forEach(row=>{
      const dn=norm(row.vals[tn]); if(!dn) return;
      // prefer a tab no earlier entry has claimed, so entries sharing a name (two "Email" tables) link to different tabs
      const free=e=>!linked.has(e.idx);
      let hit=ents.find(e=>free(e)&&cand(e).includes(dn))||ents.find(e=>cand(e).includes(dn))
           ||ents.find(e=>free(e)&&cand(e).some(c=>c.endsWith(dn)||dn.endsWith(c)))||ents.find(e=>cand(e).some(c=>c.endsWith(dn)||dn.endsWith(c)));
      if(hit){row.link=hit.idx; linked.add(hit.idx); if(ar>=0&&!hit.area) hit.area=row.vals[ar];}
    });
  }
  return sheets;
}

/* ---------- areas (from the Table Dictionary) ---------- */
const NOAREA='Other tables';   // tables with no Area
const areaOf=sh=>sh.area||NOAREA;
// every area with its table count, named areas first, "Other tables" last
function areaList(){const m=new Map();S.sheets.filter(s=>s.kind==='entity').forEach(s=>m.set(areaOf(s),(m.get(areaOf(s))||0)+1));return [...m.entries()].sort((a,b)=>(a[0]===NOAREA)-(b[0]===NOAREA)||a[0].localeCompare(b[0]))}
const hasAreas=()=>areaList().length>1;
const areaLabel=set=>!set||!set.size?'All areas':set.size===1?[...set][0]:set.size+' areas';
const AREA_COLS=['#0A4873','#BB1C73','#1B7F5C','#B54708','#6941C6','#0E7090','#C11574','#4E5BA6','#7A5C00','#344054','#027A48','#9E165F'];
const areaColour=a=>{const i=areaList().findIndex(x=>x[0]===a);return i<0?'#667085':AREA_COLS[i%AREA_COLS.length]};
// re-read each table's area from the dictionary, so an edited Area applies straight away
function relinkAreas(){
  const dict=S.sheets.find(s=>s.isDict); if(!dict||dict.colIdx['Area']===undefined) return;
  S.sheets.forEach(s=>{if(s.kind==='entity') s.area=''});
  dict.rows.forEach(r=>{if(r.link==null) return; const sh=S.sheets[r.link], a=getVal(dict,r,'Area').trim(); if(sh&&a&&!sh.area) sh.area=a});
}
// pick areas: a checklist popover; onApply gets the chosen set (empty means every area)
function areaPop(anchor,cur,onApply,hint){
  closePops();
  const all=areaList(), el=document.createElement('div'); el.className='pop';
  const on=a=>!cur||!cur.size||cur.has(a);
  el.innerHTML=`<div class="ph"><span>Areas</span><span class="dim" style="font-weight:400">${all.length}</span></div>${hint?`<div class="dim" style="padding:0 10px 6px;font-size:12px">${hint}</div>`:''}
    <div class="plist">${all.map(([a,n])=>`<label><input type="checkbox" data-area="${esc(a)}" ${on(a)?'checked':''}><span style="word-break:break-word">${esc(a)}</span><span class="n">${n} table${n===1?'':'s'}</span></label>`).join('')}</div>
    <div class="pf"><button class="btn" data-pa="all">All</button><button class="btn" data-pa="none">None</button><span style="flex:1"></span><button class="btn primary" data-pa="apply">Apply</button></div>`;
  el.addEventListener('click',e=>{const b=e.target.closest('[data-pa]'); if(!b) return; const boxes=[...el.querySelectorAll('[data-area]')];
    if(b.dataset.pa==='all') boxes.forEach(x=>x.checked=true);
    else if(b.dataset.pa==='none') boxes.forEach(x=>x.checked=false);
    else {const sel=new Set(boxes.filter(x=>x.checked).map(x=>x.dataset.area)); closePops(); onApply(sel.size===boxes.length?new Set():sel)}});
  placePop(el,anchor);
}

/* ---------- edits ---------- */
const ekey=(sh,row,col)=>sh.name+'\u0001'+row.key+'\u0001'+col;
// Edits are stored per project: one workbook and the newer versions you chose to carry edits forward to.
// A different client model gets its own project, so its edits never meet this one's.
const EDIT_STORE_OLD='dme.edits.v2';
const editKey=p=>'dme.edits.v3:'+(p||'bundled');
const newProj=()=>'p'+Date.now().toString(36)+Math.random().toString(36).slice(2,6);
function persist(){
  if(RO) return; // read-only copy
  S.hayV=(S.hayV||0)+1; // searchable text of rows is cached; any saved change makes it stale
  // cells of rows added in the page are stored with the row itself, not as edits
  const arr=[...S.edits.values()].filter(e=>!e.row.added).map(e=>({s:e.sh.name,l:e.sh.logical,k:e.row.key,c:e.col,o:e.old,n:e.nw}))
    .concat(addedRows().map(({sh,row})=>({a:row.added,s:sh.name,l:sh.logical,v:rowObj(sh,row)})))
    .concat([...S.metaEd.values()].map(e=>({d:1,s:e.sh.name,l:e.sh.logical,k:e.k,o:e.old,n:e.nw})))
    .concat(S.pending.map(p=>p.rec));
  saveState(store.set(editKey(S.proj),arr.length?arr:null));
}
function storedEdits(proj){return store.get(editKey(proj))||[]}
function applyStored(){
  const arr=storedEdits(S.proj); S.pending=[]; let n=0;
  const sheetOf=rec=>S.sheets.find(s=>s.name===rec.s)||(rec.l&&S.sheets.find(s=>s.kind==='entity'&&s.logical===rec.l));
  // rows added in the page first, so edits never depend on them
  arr.forEach(rec=>{
    if(!rec.a) return;
    const sh=sheetOf(rec); if(!sh){S.pending.push({type:'orphan',rec});return}
    const ln=String((rec.v||{})['Logical Name']||'').trim().toLowerCase();
    if(ln&&sh.rows.some(r=>getVal(sh,r,'Logical Name').trim().toLowerCase()===ln)){S.pending.push({type:'exists',rec,sh});return}   // a newer version already has it
    addRow(sh,rec.v,rec.a); n++;
  });
  // changed table details
  arr.forEach(rec=>{
    if(!rec.d) return;
    const sh=sheetOf(rec); if(!sh){S.pending.push({type:'orphan',rec});return}
    const cur=sh.metaOrig[String(rec.k).toLowerCase()]==null?'':sh.metaOrig[String(rec.k).toLowerCase()];
    if(cur===rec.o){setMeta(sh,rec.k,rec.n,true);n++}
    else if(cur!==rec.n) S.pending.push({type:'mconflict',rec,sh,up:cur});
  });
  arr.forEach(rec=>{
    if(rec.a||rec.d) return;
    const sh=S.sheets.find(s=>s.name===rec.s)||(rec.l&&S.sheets.find(s=>s.kind==='entity'&&s.logical===rec.l));
    const row=sh&&sh.rowMap[rec.k]; const ci=sh?sh.colIdx[rec.c]:undefined;
    if(!sh||!row||ci===undefined){S.pending.push({type:'orphan',rec});return}
    if(row.orig[ci]===rec.o){setVal(sh,row,rec.c,rec.n,true);n++}
    else if(row.orig[ci]===rec.n){}
    else S.pending.push({type:'conflict',rec,sh,row,up:row.orig[ci]});
  });
  return n;
}
function getVal(sh,row,col){const i=sh.colIdx[col];return i===undefined?'':row.vals[i]}
/* ---------- rows added in the page ---------- */
// An added row starts blank (orig all ''), so each value is an ordinary edit: it shows as edited, is checked,
// drawn and built like any other row, and is written by both exports. It is stored as one record per row.
let addSeq=0;
const rowObj=(sh,row)=>{const o={};sh.cols.forEach((c,i)=>{if(row.vals[i]!=='')o[c]=row.vals[i]});return o};
const rowNo=row=>row.r==null?'new row':'row '+(row.r+1);
function addRow(sh,vals,id){
  if(RO) return; // read-only copy
  id=id||(Date.now().toString(36)+(addSeq++).toString(36)+Math.random().toString(36).slice(2,5));
  const row={vals:sh.cols.map(()=>''),orig:sh.cols.map(()=>''),r:null,key:'new:'+id,added:id};
  sh.rows.push(row); sh.rowMap[row.key]=row;
  Object.entries(vals||{}).forEach(([c,v])=>{if(v!=null&&v!=='')setVal(sh,row,c,String(v),true)});
  rowsChanged(); return row;
}
function removeRow(sh,row){
  if(RO) return; // read-only copy
  const i=sh.rows.indexOf(row); if(i>=0) sh.rows.splice(i,1); delete sh.rowMap[row.key];
  [...S.edits.entries()].forEach(([k,e])=>{if(e.row===row)S.edits.delete(k)});
  if(S.selItem===row){S.selIt=null;S.selItem=null;$('#detail').classList.remove('open')}
  rowsChanged();
}
function rowsChanged(){S.issues=null;S.adj=null;S.choiceCache={};S.allView=buildAll();relinkAreas()}
function addedRows(){const o=[];(S.sheets||[]).forEach(sh=>sh.rows.forEach(row=>{if(row.added)o.push({sh,row})}));return o}
// the number shown on the Changes button: edits, rows added, table details changed, and edits waiting for a decision
const changeTotal=()=>[...S.edits.values()].filter(e=>!e.row.added).length+addedRows().length+S.metaEd.size+S.pending.length;
// anything to write into the workbook
const hasWrites=()=>S.edits.size>0||S.metaEd.size>0;
/* ---------- table details (the label/value rows above the field list) ---------- */
const mkey=(sh,k)=>sh.name+'\u0001'+String(k).toLowerCase();
// the label as this sheet writes it ("Primary Key" or "primary key"), or the given one when the sheet lacks it
const metaLabel=(sh,want)=>{const m=sh.meta.find(x=>x[0].toLowerCase()===want.toLowerCase());return m?m[0]:want};
function setMeta(sh,label,val,silent){
  if(RO) return; // read-only copy
  val=String(val==null?'':val).replace(/\r\n?/g,'\n'); const k=label.toLowerCase();
  let m=sh.meta.find(x=>x[0].toLowerCase()===k); if(!m){m=[label,''];sh.meta.push(m)}
  m[1]=val; sh.mo[k]=val; S.issues=null; S.adj=null;
  const o=sh.metaOrig[k]==null?'':sh.metaOrig[k];
  if(val===o) S.metaEd.delete(mkey(sh,k)); else S.metaEd.set(mkey(sh,k),{sh,k:m[0],old:o,nw:val});
  if(!silent){persist();updateCounts();}
}
// a sub-grid on a form, documented in the field list: not a column, so it has no logical name and is not checked or built
const isSubgridRow=(sh,row)=>/^sub[\s_-]*grids?$/i.test(getVal(sh,row,'Attribute Type').trim())||sh.colIdx['Type']!==undefined&&/^sub[\s_-]*grids?$/i.test(getVal(sh,row,'Type').trim());
const isGuidType=t=>/^(uniqueidentifier|primarykey|guid)$/i.test(String(t||'').replace(/[^a-z]/gi,''));
function setVal(sh,row,col,val,silent){
  if(RO) return; // read-only copy
  S.hayV=(S.hayV||0)+1;
  const i=sh.colIdx[col]; if(i===undefined) return;
  val=String(val).replace(/\r\n?/g,'\n');
  row.vals[i]=val; S.issues=null;
  if(sh.isDict&&col==='Area') relinkAreas();   // the sidebar, ERD and filters regroup at once
  const k=ekey(sh,row,col);
  if(val===row.orig[i]) S.edits.delete(k);
  else S.edits.set(k,{sh,row,col,old:row.orig[i],nw:val});
  if(!silent){persist();updateCounts();}
}
function isEdited(sh,row,col){return S.edits.has(ekey(sh,row,col))}
function sheetEditCount(sh){let n=0;S.edits.forEach(e=>{if(e.sh===sh)n++});return n}
function updateCounts(){
  const n=changeTotal();
  $('#chgCount').textContent=n; {const c=issueCounts(), k=c.error+c.warn, b=$('#chkCount'); if(b){b.textContent=k; b.style.display=k?'':'none'; b.title=c.error+' error'+(c.error===1?'':'s')+', '+c.warn+' warning'+(c.warn===1?'':'s')}}
  $('#chgCount').style.display=n?'':'none';
  {const bb=$('#btnBuild'); if(bb){bb.disabled=isStarter(); bb.title=isStarter()?'Open a data-model workbook first':'Turn the workbook into a Dataverse solution you import with one script'}}
  $('#chgCount').style.background=S.pending.length?'var(--pink)':'';
  {const C=S.conf||[];const n=C.filter(x=>x.isNew||x.extra.length||x.missing.length).length;$('#tmplCount').textContent=n;$('#tmplCount').style.display=n?'':'none'}
  $('#btnVer').style.display=S.diff?'':'none'; $('#verCount').textContent=S.diff?S.diff.total:0;
  renderNav();
}

/* ---------- template ---------- */
const T={name:'',b64:'',sheets:[],byName:{},entityCols:[]};
function loadTemplate(b64,name){
  T.entityCols=[]; T.byName={}; T.entityMeta=[];   // the template is read as it is, without columns from the previous one
  const sheets=parseWorkbook(XLSX.read(b64ToU8(b64),XLSX_OPTS));
  T.name=name;T.b64=b64;T.sheets=sheets;T.byName={};
  sheets.forEach(s=>T.byName[s.name.toLowerCase()]=s);
  const ents=sheets.filter(s=>s.kind==='entity');
  const u=[];ents.forEach(s=>s.cols.forEach(c=>{if(!u.includes(c))u.push(c)}));
  T.entityCols=u;
  {const tm=[];ents.forEach(s=>s.meta.forEach(([k])=>{if(!tm.some(x=>x.toLowerCase()===k.toLowerCase()))tm.push(k)}));T.entityMeta=tm}
  readTemplateOpts(b64);
}
async function readTemplateOpts(b64){
  S.tmplOpts={};
  try{
    const ct=v=>v==null?'':typeof v==='object'?(v.richText?v.richText.map(x=>x.text).join(''):v.result!=null?String(v.result):v.text!=null?String(v.text):''):String(v);
    const cn=L=>L.split('').reduce((a,c)=>a*26+c.charCodeAt(0)-64,0);
    const buf=b64ToU8(b64); const wb=new ExcelJS.Workbook(); await wb.xlsx.load(buf.buffer.slice(buf.byteOffset,buf.byteOffset+buf.byteLength));
    wb.worksheets.forEach(ws=>{
      let hdr=null;
      ws.eachRow((row,r)=>{if(hdr)return;if(ct(row.getCell(1).value).trim()==='Logical Name'&&ct(row.getCell(2).value).trim()==='Schema Name'){hdr={};row.eachCell((cell,c)=>{hdr[c]=ct(cell.value).trim()})}});
      if(!hdr) return;
      const dv=(ws.dataValidations&&ws.dataValidations.model)||{}; const seen=new Set();
      Object.keys(dv).forEach(addr=>{
        const d=dv[addr]; if(!d||d.type!=='list'||!d.formulae||!d.formulae[0]) return;
        const m=addr.match(/^([A-Z]+)\d+$/); if(!m) return;
        const name=hdr[cn(m[1])]; if(!name||seen.has(name)) return; seen.add(name);
        const f=String(d.formulae[0]).trim(); let vals=[];
        if(/^".*"$/.test(f)) vals=f.slice(1,-1).split(',');
        else{const r=f.match(/^(?:'?([^'!]+)'?!)?\$?([A-Z]+)\$?(\d+)(?::\$?([A-Z]+)\$?(\d+))?$/);
          if(r){const w=(r[1]&&wb.getWorksheet(r[1]))||ws;const c1=cn(r[2]),c2=r[4]?cn(r[4]):c1,r1=+r[3],r2=r[5]?+r[5]:r1;for(let rr=r1;rr<=r2;rr++)for(let cc=c1;cc<=c2;cc++)vals.push(ct(w.getCell(rr,cc).value))}}
        vals=vals.map(s=>s.trim()).filter(Boolean);
        if(vals.length){const k=name.toLowerCase();S.tmplOpts[k]=[...new Set((S.tmplOpts[k]||[]).concat(vals))]}
      });
    });
  }catch(e){}
}
function refCols(sh){
  const ts=T.byName[sh.name.toLowerCase()];
  if(ts) return {cols:ts.cols,matched:true};
  if(sh.kind==='entity'&&T.entityCols.length) return {cols:T.entityCols,matched:false};
  return null;
}
function conformance(){
  const out=[];
  S.sheets.forEach(sh=>{
    const r=refCols(sh); if(!r){out.push({sh,isNew:true,extra:[],missing:[]});return}
    const lc=r.cols.map(c=>c.toLowerCase()), sc=sh.cols.map(c=>c.toLowerCase());
    out.push({sh,isNew:!r.matched&&!(sh.kind==='entity'&&T.entityCols.length),extra:sh.cols.filter(c=>!lc.includes(c.toLowerCase())),missing:r.matched?r.cols.filter(c=>!sc.includes(c.toLowerCase())):[]});
  });
  S.conf=out; return out;
}
function isExtraCol(view,c){
  if(c==='Table') return false;
  if(view.kind==='all') return T.entityCols.length&&!T.entityCols.some(x=>x.toLowerCase()===c.toLowerCase());
  const r=refCols(view.sh); return !!r&&!r.cols.some(x=>x.toLowerCase()===c.toLowerCase());
}
function renderTemplate(){
  const d=$('#tmplpanel'); const C=S.conf||[];
  const newT=C.filter(x=>x.isNew), extra=C.filter(x=>x.extra.length), miss=C.filter(x=>x.missing.length);
  let h=`<header><div style="flex:1;min-width:0"><h3>Template</h3><div class="mono dim">${esc(T.name)} · ${T.sheets.length} sheets</div></div><button class="btn ghost" data-tclose>✕</button></header><div class="body">
  <p class="dim" style="margin-top:0">The template defines the layout and formatting used when you export. Any workbook with the same structure can be loaded. The template only needs the Table Dictionary and one example table. Every other table is laid out and styled like that example when exported. Extra columns are kept, and are formatted like the template.</p>
  <div class="stats" style="margin:0 0 12px">${[['tables in file',C.length],['not in template',newT.length],['with extra columns',extra.length],['missing columns',miss.length]].map(x=>`<div class="stat" style="cursor:default"><b>${x[1]}</b><span>${x[0]}</span></div>`).join('')}</div>
  <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px"><button class="btn primary" data-act="tmpl-dl">Download blank template</button><button class="btn" data-act="tmpl-use">Use a different template…</button><button class="btn" data-act="tmpl-reset">Reset to bundled</button></div>`;
  const addedC=C.filter(x=>x.sh.tmplAdded&&x.sh.tmplAdded.length);
  if(addedC.length){const u=[...new Set(addedC.flatMap(x=>x.sh.tmplAdded))]; h+=`<div class="vline"><span class="pill p-blue">ADDED FROM THE TEMPLATE</span> ${u.map(c=>`<span class="tchip dead">${esc(c)}</span>`).join('')}<div class="dim">${addedC.length} table${addedC.length===1?' does':'s do'} not have ${u.length===1?'this column':'these columns'} in the workbook. ${u.length===1?'It is':'They are'} shown so you can fill ${u.length===1?'it':'them'} in, and added to the file when you save a value in ${u.length===1?'it':'them'}.</div></div>`}
  if(!newT.length&&!extra.length&&!miss.length&&!addedC.length) h+='<div class="empty">This workbook matches the template exactly.</div>';
  newT.forEach(x=>h+=`<div class="vline"><span class="pill p-blue">NEW TABLE</span> <a href="#" data-vgo="${x.sh.idx}">${esc(x.sh.label)}</a><div class="dim">Not in the template. It will be formatted like the template's entity tables.</div></div>`);
  C.filter(x=>!x.isNew&&(x.extra.length||x.missing.length)||x.isNew&&x.extra.length).forEach(x=>{
    h+=`<div class="vline"><a href="#" data-vgo="${x.sh.idx}"><b>${esc(x.sh.label)}</b></a>`;
    if(x.extra.length) h+=`<div style="margin-top:3px"><span class="pill p-green">EXTRA</span> ${x.extra.map(c=>`<span class="tchip dead">${esc(c)}</span>`).join('')}</div>`;
    if(x.missing.length) h+=`<div style="margin-top:3px"><span class="pill p-amber">MISSING</span> ${x.missing.map(c=>`<span class="tchip dead">${esc(c)}</span>`).join('')}</div>`;
    h+='</div>';
  });
  d.innerHTML=h+'</div>'; ['#changes','#versions','#detail'].forEach(s=>$(s).classList.remove('open')); d.classList.add('open');
}
async function exportTemplated(){
  const base=S.fileName.replace(/\.[^.]+$/,'');
  const tw=new ExcelJS.Workbook();
  const buf=b64ToU8(T.b64); await tw.xlsx.load(buf.buffer.slice(buf.byteOffset,buf.byteOffset+buf.byteLength));
  const clone=o=>o?JSON.parse(JSON.stringify(o)):{};
  const txt=v=>{if(v==null)return '';if(typeof v==='object'){if(v.richText)return v.richText.map(x=>x.text).join('');if('result' in v)return String(v.result??'');if('text' in v)return String(v.text);return ''}return String(v)};
  const info=ws=>{
    let hr=0;
    ws.eachRow({includeEmpty:false},(row,r)=>{if(hr)return;if(txt(row.getCell(1).value).toLowerCase()==='logical name'&&txt(row.getCell(2).value).toLowerCase()==='schema name')hr=r});
    let kind='entity';
    if(!hr){kind='table';ws.eachRow({includeEmpty:false},(row,r)=>{if(hr)return;let n=0;row.eachCell({includeEmpty:false},c=>{if(txt(c.value)!=='')n++});if(n>=3)hr=r})}
    if(!hr) return null;
    const cols={},order=[];
    ws.getRow(hr).eachCell({includeEmpty:false},(cell,c)=>{const nm=txt(cell.value).trim();if(!nm)return;order.push(nm);cols[nm.toLowerCase()]={pos:c,width:ws.getColumn(c).width,hdr:clone(cell.style),data:clone(ws.getCell(hr+1,c).style),hint:hr>1?clone(ws.getCell(hr-1,c).style):{},hintText:hr>1?txt(ws.getCell(hr-1,c).value):''}});  // a header on row 1 has no hint row above it
    const meta=[];for(let r=1;r<hr-1;r++)meta.push({a:clone(ws.getCell(r,1).style),b:clone(ws.getCell(r,2).style),h:ws.getRow(r).height});
    const notes=[];if(kind==='table')ws.eachRow({includeEmpty:false},(row,r)=>{if(r>=hr)return;row.eachCell({includeEmpty:false},(cell,c)=>{if(txt(cell.value)!=='')notes.push({r,c,v:txt(cell.value),s:clone(cell.style)})})});
    const subs=[];
    if(kind==='entity') ws.eachRow({includeEmpty:false},(row,r)=>{
      if(r<=hr) return; const lt=txt(row.getCell(1).value);
      if(!/^(forms?|views?)\s*:$/i.test(lt.trim())) return;
      const hdr=[],data={};
      ws.getRow(r+1).eachCell({includeEmpty:false},(cell,c)=>{const nm=txt(cell.value).trim();if(nm){hdr.push({name:nm,pos:c,style:clone(cell.style)});data[c]=clone(ws.getCell(r+2,c).style)}});
      subs.push({label:lt.trim(),title:lt.replace(/:\s*$/,'').trim().toLowerCase(),labelStyle:clone(row.getCell(1).style),hdr,data});
    });
    return {kind,subs,hr,cols,order,meta,notes,hdrH:ws.getRow(hr).height,views:clone(ws.views),dataH:ws.getRow(hr+1).height};
  };
  const infos={};let entityProto=null;
  tw.worksheets.forEach(ws=>{const i=info(ws);if(i){infos[ws.name.toLowerCase()]=i;if(i.kind==='entity'&&(!entityProto||i.order.length>entityProto.order.length))entityProto=i}});
  tw.worksheets.slice().forEach(w=>tw.removeWorksheet(w.id));
  const sx=s=>Object.assign({},s);
  S.sheets.forEach((sh,si)=>{
    const proto=infos[sh.name.toLowerCase()]||(sh.kind==='entity'?entityProto:null);
    const name=sh.name.slice(0,31);
    const ws=tw.addWorksheet(name);
    const last=proto?proto.cols[proto.order[proto.order.length-1].toLowerCase()]:null;
    const isEnt=sh.kind==='entity';
    const hr=isEnt?Math.max(proto?proto.hr:11,sh.meta.length+2):(proto?proto.hr:(sh.hdrRow||1));
    const pos=isEnt?sh.cols.map((c,i)=>i+1):sh.pos;
    if(isEnt){
      sh.meta.forEach(([k,v],i)=>{const r=i+1;const m=proto&&proto.meta.length?proto.meta[Math.min(i,proto.meta.length-1)]:{};
        const a=ws.getCell(r,1);a.value=k;if(m.a)a.style=sx(m.a);const b=ws.getCell(r,2);b.value=v===''?null:v;if(m.b)b.style=sx(m.b);if(m.h)ws.getRow(r).height=m.h});
    } else {
      const src=(sh.noteCells&&sh.noteCells.length)?sh.noteCells:(proto?proto.notes:[]);
      src.forEach(n=>{const c=ws.getCell(n.r,n.c);c.value=n.v;const ps=proto&&proto.notes.find(x=>x.r===n.r&&x.c===n.c);if(ps)c.style=sx(ps.s)});
    }
    sh.cols.forEach((cn,i)=>{
      const pc=(proto&&proto.cols[cn.toLowerCase()])||last;
      const p=pos[i];
      const h=ws.getCell(hr,p);h.value=cn;if(pc&&pc.hdr)h.style=sx(pc.hdr);else h.font={bold:true};
      if(isEnt){const ht=sh.hints[cn]||(proto&&proto.cols[cn.toLowerCase()]?proto.cols[cn.toLowerCase()].hintText:'');if(ht){const hc=ws.getCell(hr-1,p);hc.value=ht;if(pc&&pc.hint)hc.style=sx(pc.hint)}}
      ws.getColumn(p).width=(proto&&proto.cols[cn.toLowerCase()]&&proto.cols[cn.toLowerCase()].width)||(last&&last.width)||24;
      const ds=pc&&pc.data?pc.data:null;
      for(let k=0;k<sh.rows.length;k++){
        const v=sh.rows[k].vals[i]; const c=ws.getCell(hr+1+k,p);
        if(v!=='')c.value=v; if(ds)c.style=sx(ds);
      }
    });
    if(isEnt){
      let r=hr+1+Math.max(1,sh.rows.length)+2;
      const psubs=(proto&&proto.subs)||[];
      const secs=(sh.subs&&sh.subs.some(s=>s.cols.length))?sh.subs.filter(s=>s.cols.length):psubs.map(p=>({label:p.label,title:p.title,cols:p.hdr.map(h=>h.name),pos:p.hdr.map(h=>h.pos),rows:[]}));
      secs.forEach(s=>{
        const ps=psubs.find(p=>p.title===s.title.toLowerCase());
        const lc=ws.getCell(r,1);lc.value=s.label;if(ps)lc.style=sx(ps.labelStyle);
        s.cols.forEach((cn,i)=>{const ph=ps&&ps.hdr.find(h=>h.name.toLowerCase()===cn.toLowerCase())||(ps&&ps.hdr[0]);const c=ws.getCell(r+1,s.pos[i]);c.value=cn;if(ph)c.style=sx(ph.style);else c.font={bold:true}});
        s.rows.forEach((row,k)=>row.vals.forEach((v,i)=>{const c=ws.getCell(r+2+k,s.pos[i]);if(v!=='')c.value=v;const d=ps&&ps.data[s.pos[i]];if(d)c.style=sx(d)}));
        r+=2+Math.max(1,s.rows.length)+1;
      });
    }
    if(proto&&proto.hdrH)ws.getRow(hr).height=proto.hdrH;
    const minP=Math.min.apply(null,pos),maxP=Math.max.apply(null,pos);
    ws.autoFilter={from:{row:hr,column:minP},to:{row:hr+Math.max(1,sh.rows.length),column:maxP}};
    const fv=proto&&proto.views&&proto.views[0];
    if(fv&&fv.state==='frozen') ws.views=[{state:'frozen',xSplit:fv.xSplit||0,ySplit:hr,topLeftCell:'A'+(hr+1)}];
  });
  if(hasWrites()){
    const cl=tw.addWorksheet('Change log');
    changeRows().forEach((r,i)=>{const row=cl.addRow(r);if(i===0)row.font={bold:true}});
    [26,30,24,50,50].forEach((w,i)=>cl.getColumn(i+1).width=w);
  }
  const cut=fitExcelJS(tw), out=await tw.xlsx.writeBuffer();
  const fn=await nameDialog(nextName(S.fileName,' (edited)'),'Rebuilt in the current template'); if(!fn) return;
  download(fn,new Blob([out],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}));
  toast('Exported '+fn+' in template format'); cutReport(cut,fn);
}

/* ---------- version diff ---------- */
function verLabel(name){const m=String(name||'').match(/v?(\d+(?:\.\d+)+)/i);return m?'v'+m[1]:String(name||'').replace(/\.[^.]+$/,'')}
function computeDiff(prev,cur,prevName,curName){
  const D={prevName,curName,pl:verLabel(prevName),cl:verLabel(curName),addedTables:[],removedTables:[],newRows:[],goneRows:[],changes:[],
    colsAdded:[],colsRemoved:[],metaChanges:[],subChanges:[],relChanges:[],bySheet:new Map()};
  const pm=new Map(prev.map(s=>[norm(s.name),s]));
  const byLog=new Map(prev.filter(s=>s.kind==='entity'&&s.logical).map(s=>[s.logical,s]));
  const take=sh=>{let k=norm(sh.name),ps=pm.get(k);if(ps){pm.delete(k);return ps}
    ps=sh.logical&&byLog.get(sh.logical);if(ps&&pm.get(norm(ps.name))===ps){pm.delete(norm(ps.name));return ps}return null};
  const bucket=sh=>{let b=D.bySheet.get(sh);if(!b){b={added:[],gone:[],changed:[],colsAdded:[],colsRemoved:[],meta:[],subs:[],rels:[]};D.bySheet.set(sh,b)}return b};
  const lc=s=>String(s).toLowerCase();
  // lookup targets held in a row's Additional data, as of that version of the file
  const tgts=(s,row)=>{const i=s.colIdx['Additional data'];return i===undefined?[]:targetsFromText(row.orig[i])};
  const isLookup=(s,row)=>{const i=s.colIdx['Attribute Type'];return i!==undefined&&/lookup|owner|customer/i.test(row.orig[i])};
  const fieldName=(s,row)=>row.orig[s.colIdx['Logical Name']??0]||row.key;
  const rel=(sh,field,added,removed)=>{if(!added.length&&!removed.length)return;const x={sh,field,added,removed};D.relChanges.push(x);bucket(sh).rels.push(x)};
  cur.forEach(sh=>{
    const ps=take(sh);
    if(!ps){sh.isNewTable=true;D.addedTables.push(sh);return}
    const pIdx={}; ps.cols.forEach((c,i)=>pIdx[lc(c)]=i);   // columns are matched without regard to case
    sh.rows.forEach(row=>{
      const pr=ps.rowMap[row.key];
      if(!pr){row.isNew=true;D.newRows.push({sh,row});bucket(sh).added.push(row);if(isLookup(sh,row))rel(sh,fieldName(sh,row),tgts(sh,row),[]);return}
      sh.cols.forEach((c,ci)=>{
        const pi=pIdx[lc(c)]; if(pi===undefined) return;
        if(pr.orig[pi]!==row.orig[ci]){
          (row.chg=row.chg||{})[c]=pr.orig[pi];
          const ch={sh,row,col:c,old:pr.orig[pi],nw:row.orig[ci]}; D.changes.push(ch); bucket(sh).changed.push(ch);
        }
      });
      // a relationship appears or disappears when a field becomes or stops being a lookup, or its targets change
      const a=isLookup(sh,row)?tgts(sh,row):[], b=isLookup(ps,pr)?tgts(ps,pr):[];
      rel(sh,fieldName(sh,row),a.filter(t=>!b.includes(t)),b.filter(t=>!a.includes(t)));
    });
    ps.rows.forEach(pr=>{if(!sh.rowMap[pr.key]){const g={sh,key:pr.key,label:pr.orig[ps.colIdx['Display Name']]||''};D.goneRows.push(g);bucket(sh).gone.push(g);if(isLookup(ps,pr))rel(sh,fieldName(ps,pr),[],tgts(ps,pr))}});
    // columns added or removed
    const cset=new Set(sh.cols.map(lc));
    sh.cols.forEach(c=>{if(pIdx[lc(c)]===undefined){D.colsAdded.push({sh,col:c});bucket(sh).colsAdded.push(c)}});
    ps.cols.forEach(c=>{if(!cset.has(lc(c))){D.colsRemoved.push({sh,col:c});bucket(sh).colsRemoved.push(c)}});
    // table details above the field list (ownership, description, audit…), or the notes above a plain table
    const meta=(k,o,nw)=>{if(o===nw)return;const x={sh,key:k,old:o,nw};D.metaChanges.push(x);bucket(sh).meta.push(x)};
    if(sh.kind==='entity'){
      const label=k=>((sh.meta.find(m=>lc(m[0])===k)||ps.meta.find(m=>lc(m[0])===k)||[k])[0]);
      new Set([...Object.keys(ps.mo),...Object.keys(sh.mo)]).forEach(k=>meta(label(k),ps.mo[k]||'',sh.mo[k]||''));
    } else meta('Notes above the table',ps.notes.join('\n'),sh.notes.join('\n'));
    // Forms and Views: items added or removed (an item whose columns changed shows as one removed and one added)
    const items=s=>{const m=new Map();(s.subs||[]).forEach(x=>m.set(lc(x.title),{title:x.title,rows:x.rows.map(r=>r.vals.filter(Boolean).join(' · ')).filter(Boolean)}));return m};
    const pS=items(ps), cS=items(sh);
    new Set([...pS.keys(),...cS.keys()]).forEach(k=>{
      const p=pS.get(k)||{rows:[]}, c=cS.get(k)||{rows:[]}, title=(c.title||p.title);
      const added=c.rows.filter(r=>!p.rows.includes(r)), removed=p.rows.filter(r=>!c.rows.includes(r));
      if(added.length||removed.length){const x={sh,title,added,removed};D.subChanges.push(x);bucket(sh).subs.push(x)}
    });
  });
  pm.forEach(ps=>D.removedTables.push(ps));
  D.subCount=D.subChanges.reduce((a,x)=>a+x.added.length+x.removed.length,0);
  // relationship changes are another view of field changes already counted, so they are not added to the total
  D.total=D.addedTables.length+D.removedTables.length+D.newRows.length+D.goneRows.length+D.changes.length+D.colsAdded.length+D.colsRemoved.length+D.metaChanges.length+D.subCount;
  D.bySheet.forEach((b,sh)=>sh.chgCount=b.added.length+b.changed.length+b.gone.length+b.colsAdded.length+b.colsRemoved.length+b.meta.length+b.subs.reduce((a,x)=>a+x.added.length+x.removed.length,0));
  return D;
}
function renderVersions(){
  const D=S.diff,d=$('#versions'); if(!D){d.classList.remove('open');return}
  const link=(sh,row,txt)=>`<a href="#" data-vgo="${sh.idx}" ${row?`data-vrow="${esc(row.key)}"`:''}>${txt}</a>`;
  let h=`<header><div style="flex:1;min-width:0"><h3>What changed</h3><div class="mono dim">${esc(D.pl)} → ${esc(D.cl)}</div></div><button class="btn" data-act="exp-diff">Export (CSV)</button><button class="btn ghost" data-vclose>✕</button></header><div class="body">`;
  h+=`<div class="stats" style="margin:0 0 14px">${[['tables added',D.addedTables.length],['tables removed',D.removedTables.length],['fields added',D.newRows.length],['fields removed',D.goneRows.length],['values changed',D.changes.length],['columns added or removed',D.colsAdded.length+D.colsRemoved.length],['table details changed',D.metaChanges.length],['form and view changes',D.subCount],['relationships changed',D.relChanges.reduce((a,x)=>a+x.added.length+x.removed.length,0)]].map(x=>`<div class="stat" style="cursor:default"><b>${x[1]}</b><span>${x[0]}</span></div>`).join('')}</div>`;
  if(!D.total) h+='<div class="empty">No differences between these versions.</div>';
  if(D.addedTables.length) h+=`<div class="fld"><div class="k">New tables</div>${D.addedTables.map(s=>`<span class="tchip" data-vgo="${s.idx}">${esc(s.label)}</span>`).join('')}</div>`;
  if(D.removedTables.length) h+=`<div class="fld"><div class="k">Tables no longer present</div>${D.removedTables.map(s=>`<span class="tchip dead">${esc(s.label)}</span>`).join('')}</div>`;
  D.bySheet.forEach((b,sh)=>{
    if(!b.added.length&&!b.gone.length&&!b.changed.length&&!b.colsAdded.length&&!b.colsRemoved.length&&!b.meta.length&&!b.subs.length&&!b.rels.length) return;
    h+=`<div class="vsec"><h4>${link(sh,null,esc(sh.label))} <span class="dim">${b.added.length?'+'+b.added.length+' ':''}${b.gone.length?'−'+b.gone.length+' ':''}${b.changed.length?'✎'+b.changed.length:''}</span></h4>`;
    const blank=v=>v?esc(v):'<i>(blank)</i>';
    if(b.colsAdded.length) h+=`<div class="vline"><span class="pill p-green">+ COLUMN ADDED</span> ${b.colsAdded.map(c=>`<span class="tchip dead">${esc(c)}</span>`).join('')}</div>`;
    if(b.colsRemoved.length) h+=`<div class="vline"><span class="pill p-red">− COLUMN REMOVED</span> ${b.colsRemoved.map(c=>`<span class="tchip dead">${esc(c)}</span>`).join('')}</div>`;
    b.meta.forEach(m=>h+=`<div class="vline"><span class="pill p-violet">TABLE DETAIL</span> <b>${esc(m.key)}</b><div class="d"><div class="o">${blank(m.old)}</div><div class="nw">${m.nw?esc(m.nw):'<i>(cleared)</i>'}</div></div></div>`);
    b.subs.forEach(x=>{x.added.forEach(r=>h+=`<div class="vline"><span class="pill p-green">+ ${esc(x.title.toUpperCase())} ADDED</span> ${esc(r)}</div>`);x.removed.forEach(r=>h+=`<div class="vline"><span class="pill p-red">− ${esc(x.title.toUpperCase())} REMOVED</span> ${esc(r)}</div>`)});
    b.rels.forEach(x=>h+=`<div class="vline"><span class="pill p-lookup">RELATIONSHIP</span> <span class="mono">${esc(x.field)}</span>${x.added.length?` now looks up ${x.added.map(t=>`<span class="tchip dead">${esc(t)}</span>`).join('')}`:''}${x.removed.length?` ${x.added.length?'and ':''}no longer looks up ${x.removed.map(t=>`<span class="tchip dead">${esc(t)}</span>`).join('')}`:''}</div>`);
    b.added.forEach(r=>h+=`<div class="vline"><span class="pill p-green">+ NEW</span> ${link(sh,r,'<span class="mono">'+esc(r.orig[0])+'</span>')} <span class="dim">${esc(getVal(sh,r,'Display Name'))}</span></div>`);
    b.gone.forEach(g=>h+=`<div class="vline"><span class="pill p-red">− REMOVED</span> <span class="mono">${esc(g.key)}</span> <span class="dim">${esc(g.label)}</span></div>`);
    const relField=new Set(b.rels.map(x=>x.field)), fn=c=>c.row.orig[c.sh.colIdx['Logical Name']??0]||c.row.key;
    b.changed.filter(c=>!(c.col==='Additional data'&&relField.has(fn(c)))).forEach(c=>h+=`<div class="vline"><span class="pill p-blue">${esc(c.col)}</span> ${link(sh,c.row,'<span class="mono">'+esc(c.row.orig[0])+'</span>')}<div class="d"><div class="o">${c.old?esc(c.old):'<i>(blank)</i>'}</div><div class="nw">${c.nw?esc(c.nw):'<i>(cleared)</i>'}</div></div></div>`);
    h+='</div>';
  });
  d.innerHTML=h+'</div>'; $('#changes').classList.remove('open'); $('#detail').classList.remove('open'); $('#tmplpanel').classList.remove('open'); d.classList.add('open');
}
function diffRows(){
  const D=S.diff; const rows=[['Table','Field','Change','Column','Previous','New']];
  D.addedTables.forEach(s=>rows.push([s.label,'','Table added','','','']));
  D.removedTables.forEach(s=>rows.push([s.label,'','Table removed','','','']));
  D.newRows.forEach(x=>rows.push([x.sh.label,x.row.orig[0],'Field added','','','']));
  D.goneRows.forEach(g=>rows.push([g.sh.label,g.key,'Field removed','','','']));
  D.changes.forEach(c=>rows.push([c.sh.label,c.row.orig[0],'Value changed',c.col,c.old,c.nw]));
  D.colsAdded.forEach(x=>rows.push([x.sh.label,'','Column added',x.col,'','']));
  D.colsRemoved.forEach(x=>rows.push([x.sh.label,'','Column removed',x.col,'','']));
  D.metaChanges.forEach(x=>rows.push([x.sh.label,'','Table detail changed',x.key,x.old,x.nw]));
  D.subChanges.forEach(x=>{x.added.forEach(r=>rows.push([x.sh.label,'',x.title+' added','','',r]));x.removed.forEach(r=>rows.push([x.sh.label,'',x.title+' removed','',r,'']))});
  D.relChanges.forEach(x=>{x.added.forEach(t=>rows.push([x.sh.label,x.field,'Relationship added','Lookup target','',t]));x.removed.forEach(t=>rows.push([x.sh.label,x.field,'Relationship removed','Lookup target',t,'']))});
  return rows;
}

/* ---------- views ---------- */
function buildAll(){
  const ents=S.sheets.filter(s=>s.kind==='entity');
  const cols=['Table'];
  ents.forEach(s=>s.cols.forEach(c=>{if(!cols.includes(c))cols.push(c)}));
  const rows=[];
  ents.forEach(sh=>sh.rows.forEach(row=>rows.push({sh,row})));
  return {id:'__all',kind:'all',label:'All fields',cols,items:rows,ents};
}
function viewFor(id){
  if(id==='__all') return S.allView;
  const sh=S.sheets[+id];
  return {id:String(sh.idx),kind:'sheet',sh,label:sh.label,cols:sh.cols,items:sh.rows.map(row=>({sh,row}))};
}
function vstate(id){
  if(!S.views[id]) S.views[id]={sort:null,filters:{},q:'',quick:{},shown:150};
  return S.views[id];
}
function cellVal(view,it,col){
  if(col==='Table') return it.sh.label;
  return getVal(it.sh,it.row,col);
}
function facet(col,v){
  v=(v||'').replace(/\s+/g,' ').trim();
  const l=col.toLowerCase();
  if(l==='required level'){
    const k=v.toLowerCase().replace(/[^a-z]/g,'');
    return ({'':'(blank)',none:'None',businessrequired:'BusinessRequired',systemrequired:'SystemRequired',applicationrequired:'ApplicationRequired',recommended:'Recommended',optional:'Optional',rollup:'Roll-up',formula:'Formula'})[k]||v;
  }
  if(l==='custom attribute') return v===''?'(blank)':(v.toLowerCase()==='true'?'True':'False');
  return v===''?'(blank)':v;
}
function hidden(view){
  // keyed by sheet name, not position, so a choice made in one workbook doesn't hide a column in another
  const key=view.kind==='all'?'__all':'s:'+view.sh.name.toLowerCase();
  if(!S.ui.hidden[key]){
    S.ui.hidden[key]=HIDE_DEFAULT.filter(c=>view.cols.includes(c));
    if(view.kind==='all') S.ui.hidden[key].push('Description');
  }
  return S.ui.hidden[key];
}
function visibleCols(view){const h=hidden(view);return view.cols.filter(c=>!h.includes(c))}

function filterItems(view){
  const st=vstate(view.id);
  const q=st.q.trim().toLowerCase();
  const terms=q?q.split(/\s+/):[];
  const cols=view.cols;
  const quick=st.quick;
  const rafCol=cols.find(c=>c.toLowerCase()==='add to raf form?');
  const customCol=cols.find(c=>c.toLowerCase()==='custom attribute');
  const cmtCol=cols.find(c=>c.toLowerCase()==='comment');
  const reqCol=cols.find(c=>c.toLowerCase()==='required level');
  const hk=(S.hayV||0)+'\u0001'+cols.join('\u0001');
  let out=view.items.filter(it=>{
    if(terms.length){
      if(it._hk!==hk){it._hay=cols.map(c=>cellVal(view,it,c)).join('\n').toLowerCase(); it._hk=hk} // built once, reused for every keystroke
      const hay=it._hay;
      for(const t of terms) if(!hay.includes(t)) return false;
    }
    if(quick.custom&&customCol&&facet(customCol,getVal(it.sh,it.row,customCol))!=='True') return false;
    if(quick.raf&&rafCol&&getVal(it.sh,it.row,rafCol)==='') return false;
    if(quick.comment&&cmtCol&&getVal(it.sh,it.row,cmtCol)==='') return false;
    if(quick.req&&reqCol&&!/required/i.test(facet(reqCol,getVal(it.sh,it.row,reqCol)))) return false;
    if(quick.changed&&!(it.row.isNew||it.row.chg)) return false;
    if(view.kind==='all'&&st.areas&&st.areas.size&&!st.areas.has(areaOf(it.sh))) return false;
    if(quick.edited){let e=false;for(const c of cols){if(c!=='Table'&&isEdited(it.sh,it.row,c)){e=true;break}}if(!e)return false}
    for(const c in st.filters){
      const f=st.filters[c];
      const v=cellVal(view,it,c);
      if(f.text&&!v.toLowerCase().includes(f.text.toLowerCase())) return false;
      if(f.sel&&!f.sel.has(facet(c,v))) return false;
    }
    return true;
  });
  if(st.sort){
    const {col,dir}=st.sort;
    out=out.map((it,i)=>[it,i]).sort((a,b)=>{
      const x=cellVal(view,a[0],col),y=cellVal(view,b[0],col);
      const r=x.localeCompare(y,undefined,{numeric:true,sensitivity:'base'});
      return (r*dir)||(a[1]-b[1]);
    }).map(x=>x[0]);
  }
  return out;
}

/* ---------- rendering: nav ---------- */
function renderNav(){
  const nav=$('#nav'); const f=S.sideFilter.toLowerCase();
  const groups={}; const order=[];
  const add=(g,html)=>{if(!groups[g]){groups[g]=[];order.push(g)}groups[g].push(html)};
  const item=(id,icon,label,sub,count,edits,chg)=>`<button class="navitem ${S.cur===id?'active':''}" data-view="${id}"><span class="ico">${icon}</span><span class="nm">${esc(label)}${sub?`<small>${esc(sub)}</small>`:''}</span>${chg?'<span class="ed vd" title="'+esc(chg)+'"></span>':''}${edits?'<span class="ed" title="'+edits+' edits"></span>':''}${count!=null?`<span class="ct">${count}</span>`:''}</button>`;
  const ic=issueCounts();
  let top=item('__overview','◎','Overview','Summary, completeness and changes',null,0)+item('__issues','⚑','Checks',ic.error+' error'+(ic.error===1?'':'s')+' · '+ic.warn+' warning'+(ic.warn===1?'':'s'),ic.error+ic.warn,0)+item('__erd','◇','ERD','Tables and their relationships',null,0);
  const dict=S.sheets.find(s=>s.isDict);
  if(dict) top+=item(String(dict.idx),'☰','Table Dictionary',null,dict.rows.length,sheetEditCount(dict));
  S.sheets.filter(s=>s.kind==='entity').forEach(s=>{
    if(f&&!(s.label+' '+s.logical+' '+s.schema+' '+s.area).toLowerCase().includes(f)) return;
    const g=s.area||'Other tables';
    add(g,item(String(s.idx),s.custom?'●':'○',s.label,s.logical+' · '+lookupCount(s)+' lookup'+(lookupCount(s)===1?'':'s'),s.rows.length,sheetEditCount(s),s.isNewTable?'New table':(s.chgCount?s.chgCount+' changes in '+S.diff.cl:'')));
  });
  S.sheets.filter(s=>s.kind==='table'&&!s.isDict).forEach(s=>{
    add('Other sheets',item(String(s.idx),'☰',s.label,null,s.rows.length,sheetEditCount(s)));
  });
  S.groups=order.slice();
  order.sort((a,b)=>{const rank=g=>g==='Other tables'?2:g==='Other sheets'?3:g==='All'?0:1;return rank(a)-rank(b)||a.localeCompare(b)});
  if(S.initCollapse){if(order.length>1) order.forEach(g=>S.collapsed[g]=true); S.initCollapse=false}   // a single group starts open
  const keepScroll=nav.scrollTop;
  nav.innerHTML=top+order.map(g=>{
    const col=S.collapsed[g]&&!f;
    return `<div class="navgroup"><h4 data-grp="${esc(g)}"><span>${esc(g)}</span><span>${groups[g].length} ${col?'▸':'▾'}</span></h4>${col?'':groups[g].join('')}</div>`;
  }).join('')+'<div class="navgroup" style="margin-top:8px;border-top:1px solid var(--line2);padding-top:8px">'+item('__all','▦','All fields','Every table, searchable',S.allView.items.length,0)+'</div>';
  nav.scrollTop=keepScroll;
}

/* ---------- rendering: main ---------- */
function pillType(v){
  const l=v.toLowerCase();
  const cls=/lookup|owner|customer/.test(l)?'p-lookup':/choice|state|status|picklist/.test(l)?'p-choice':/date/.test(l)?'p-date':/whole|currency|double|decimal|number|big/.test(l)?'p-num':/two options|boolean/.test(l)?'p-bool':'p-text';
  return `<span class="pill ${cls}">${esc(v)}</span>`;
}
function hl(text,terms){
  // match on the raw text, then escape each piece, so a search for "amp" or "lt" can't break &amp; or &lt;
  text=String(text??''); terms=terms.filter(Boolean);
  if(!terms.length) return esc(text);
  const re=new RegExp('('+terms.sort((a,b)=>b.length-a.length).map(t=>t.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|')+')','gi');
  return text.split(re).map((p,i)=>i%2?'<mark>'+esc(p)+'</mark>':esc(p)).join('');
}
function renderAddl(text,full){
  if(!text) return '';
  const lines=text.split('\n').map(l=>l.trim()).filter(Boolean);
  let html='',sec=null,buf=[];
  const flush=()=>{
    if(sec===null) return;
    if(/^targets?$/i.test(sec)){
      html+='<div class="kv"><b>Targets</b> '+buf.map(t=>{const hit=S.byLogical[t.toLowerCase()];return hit!=null?`<span class="tchip" data-golog="${esc(t.toLowerCase())}" title="Open ${esc(S.sheets[hit].label)}">${esc(t)}</span>`:`<span class="tchip dead" title="Not in this workbook">${esc(t)}</span>`}).join('')+'</div>';
    } else if(/^options?$/i.test(sec)){
      const items=full?buf:buf.slice(0,4);
      html+='<div class="kv"><b>Options</b> ('+buf.length+')<ul>'+items.map(o=>'<li>'+esc(o.replace(/\s*\(no color\)\s*$/i,''))+'</li>').join('')+(!full&&buf.length>4?'<li class="dim">+'+(buf.length-4)+' more…</li>':'')+'</ul></div>';
    } else {
      html+='<div class="kv"><b>'+esc(sec)+'</b> '+esc(buf.join(', '))+'</div>';
    }
    sec=null;buf=[];
  };
  lines.forEach(l=>{
    const m=l.match(/^([^:]{1,40}):\s*(.*)$/);
    if(m&&!/^\d+$/.test(m[1])){ // header-ish
      flush();
      if(m[2]===''){sec=m[1];buf=[]}
      else html+='<div class="kv"><b>'+esc(m[1])+'</b> '+esc(m[2])+'</div>';
    } else if(sec!==null) buf.push(l);
    else html+='<div class="kv">'+esc(l)+'</div>';
  });
  flush();
  return '<div class="addl">'+html+'</div>';
}
function cellHTML(view,it,col,terms){
  const v=cellVal(view,it,col); const l=col.toLowerCase();
  if(col==='Table') return `<a href="#" data-go="${it.sh.idx}" data-goname="${esc(it.row.vals[0])}">${hl(v,terms)}</a>`;
  if(v==='') return l==='required level'?'':'';
  if(l==='attribute type') return pillType(v);
  if(l==='required level'){
    const f=facet(col,v);
    const cls=f==='SystemRequired'?'p-red':/Required/.test(f)?'p-amber':f==='Recommended'?'p-blue':'p-slate';
    return f==='None'?'<span class="dim">–</span>':`<span class="pill ${cls}">${esc(f)}</span>`;
  }
  if(l==='custom attribute') return facet(col,v)==='True'?'<span class="pill p-violet">Custom</span>':'<span class="dim">Standard</span>';
  if(l==='add to raf form?') return `<span class="pill p-green">${hl(v,terms)}</span>`;
  if(l==='field level security') return `<span class="pill p-amber">${esc(v)}</span>`;
  if(l==='additional data') return renderAddl(v,true);
  if(l==='logical name'||l==='schema name') return `<span class="mono">${hl(v,terms)}</span>`;
  if(/^(static data\?|added to erd\?|defined in data model\?)$/.test(l)) return `<span class="pill ${/^yes/i.test(v)?'p-green':'p-slate'}">${esc(v)}</span>`;
  if(l==='out of the box/custom table?') return `<span class="pill ${/custom/i.test(v)?'p-violet':/ootb/i.test(v)?'p-blue':'p-slate'}">${esc(v)}</span>`;
  if(l==='area') return `<span class="pill p-slate">${esc(v)}</span>`;
  if(l==='table name'&&it.row.link!=null) return `<a href="#" data-go="${it.row.link}"><b>${hl(v,terms)}</b></a>`;
  return hl(v,terms);
}
function isEditable(view,col){return !RO&&col!=='Table'}
function lookupCount(sh){
  const i=sh.colIdx['Attribute Type']; if(i===undefined) return 0;
  let n=0; sh.rows.forEach(r=>{if(/^lookup$/i.test(r.vals[i]))n++}); return n;
}
function statOn(s,st){if(s.filter){const f=st.filters[s.filter[0]];return !!(f&&f.sel&&f.sel.size===1&&f.sel.has(s.filter[1]))}return !!(s.k&&st.quick[s.k])}
function statTile(s,st){
  let on=s.k&&st.quick[s.k];
  if(s.filter){const f=st.filters[s.filter[0]];on=!!(f&&f.sel&&f.sel.size===1&&f.sel.has(s.filter[1]))}
  return `<button class="stat ${s.type?'ty':''} ${on?'on':''}" ${s.k?`data-quick="${s.k}"`:''} ${s.filter?`data-qf="${esc(s.filter.join('|'))}"`:''}><b>${s.v}</b><span>${esc(s.l)}</span></button>`;
}
function typeStats(view){
  const ac=view.cols.find(c=>c.toLowerCase()==='attribute type'); if(!ac) return [];
  const m=new Map();
  view.items.forEach(it=>{const f=facet(ac,getVal(it.sh,it.row,ac));if(f==='(blank)')return;m.set(f,(m.get(f)||0)+1)});
  return [...m.entries()].sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0])).map(([k,v])=>({type:true,v,l:k,filter:[ac,k]}));
}
function statsHTML(view,st){
  const ty=typeStats(view);
  // field types: the eight most common, the rest behind "+N more" (a filtered type always stays visible)
  const show=S.ui.allTypes?ty:ty.filter((s,i)=>i<8||statOn(s,st)), more=ty.length-show.length;
  return stats(view).map(s=>statTile(s,st)).join('')+(ty.length?`<div class="tyrow"><span class="tylbl">By field type</span>${show.map(s=>statTile(s,st)).join('')}${more?`<button class="btn ghost" data-act="alltypes" style="height:26px">+${more} more</button>`:S.ui.allTypes&&ty.length>8?`<button class="btn ghost" data-act="alltypes" style="height:26px">Fewer</button>`:''}</div>`:'');
}
function stats(view){
  const items=view.items; const cols=view.cols;
  const g=n=>cols.find(c=>c.toLowerCase()===n);
  const cc=g('custom attribute'),rc=g('required level'),fc=g('add to raf form?'),mc=g('comment'),ac=g('attribute type');
  if(view.kind==='all'||(view.sh&&view.sh.kind==='entity')){
    const n=(fn)=>items.filter(fn).length;
    return [
      {k:'',v:items.length,l:'fields'},
      cc&&{k:'custom',v:n(it=>facet(cc,getVal(it.sh,it.row,cc))==='True'),l:'custom'},
      rc&&{k:'req',v:n(it=>/required/i.test(facet(rc,getVal(it.sh,it.row,rc)))),l:'required'},
      fc&&{k:'raf',v:n(it=>getVal(it.sh,it.row,fc)!==''),l:'on RAF form'},
      mc&&{k:'comment',v:n(it=>getVal(it.sh,it.row,mc)!==''),l:'with comments'},
    ].filter(Boolean);
  }
  const out=[{k:'',v:items.length,l:'rows'}];
  if(view.sh&&view.sh.isDict){const n=S.sheets.filter(s=>s.kind==='entity').reduce((a,s)=>a+lookupCount(s),0);out.push({k:'',v:n,l:'lookups across all tables'})}
  return out;
}
function renderMain(){
  const view=viewFor(S.cur); S.view=view;
  const st=vstate(view.id);
  const main=$('#main');
  const sh=view.sh;
  let head=`<div class="vhead"><h1>${esc(view.label)}`;
  if(sh&&sh.kind==='entity'){
    head+=`${sh.custom?'<span class="chip custom">Custom table</span>':'<span class="chip ootb">Out of the box</span>'}</h1><div class="sub">${esc(sh.schema)} · ${esc(sh.logical)}</div>`;
    const d=sh.mo['description']; if(d) head+=`<div class="desc">${esc(d)}</div>`;
    // primary name and key are always shown: "not set" or "assumed" when the workbook doesn't record them
    const pkRec=String(sh.mo['primary key']||'').trim(), pkGuess=!pkRec&&sh.logical&&sh.rows.some(r=>isPkRow(sh,r))?pkOf(sh):'';
    const pn=String(sh.mo['primary name column']||'').trim();
    const pchips=`${pn?`<span class="chip pkchip">Primary name: <b>${esc(pn)}</b></span>`:`<span class="chip warnchip" title="Use Set as primary name on a field, or Table details. A new table can't be built without it.">Primary name: <b>not set</b></span>`}${pkRec?`<span class="chip pkchip">Primary key: <b>${esc(pkRec)}</b></span>`:pkGuess?`<span class="chip pkchip" title="Not recorded in the workbook, so the table name followed by id is assumed. Use Set as primary key on a field, or Table details, to record it.">Primary key: <b>${esc(pkGuess)}</b> (assumed)</span>`:`<span class="chip warnchip" title="Use Set as primary key on a field, or Table details.">Primary key: <b>not set</b></span>`}`;
    const ch=[['Plural',sh.mo['plural display name']],['Ownership',sh.mo['ownership type']],['Audit',sh.mo['audit tracking']],['Type code',sh.mo['object type code']],['Area',sh.area]].filter(x=>x[1]);
    (sh.subs||[]).filter(s=>s.cols.length).forEach(s=>ch.push([s.title,String(s.rows.length)]));
    head+=`<div class="chips">${pchips}${ch.map(c=>`<span class="chip">${esc(c[0])}: <b>${esc(c[1])}</b></span>`).join('')}<button class="btn ghost" data-act="details" style="height:22px;font-size:12px" title="See and change this table's details: primary name column, primary key, ownership and the rest">✎ Table details${[...S.metaEd.values()].some(e=>e.sh===sh)?' •':''}</button></div>`;
  } else if(view.kind==='all'){
    head+=`</h1><div class="sub">${view.ents.length} tables · every attribute in one filterable list</div>`;
  } else {
    head+=`</h1><div class="sub">${esc(sh.name)}</div>`;
    sh.notes.forEach(n=>head+=`<div class="note">${esc(n)}</div>`);
  }
  head+=`<div class="stats">${statsHTML(view,st)}</div></div>`;
  const filtered=filterItems(view); S.filtered=filtered;
  const cols=visibleCols(view);
  const nQuick=Object.values(st.quick).filter(Boolean).length;
  const tb=`<div class="toolbar">
    <button class="btn ${st.quick.edited?'on':''}" data-quick="edited">✎ Edited only</button>
    ${S.diff?`<button class="btn ${st.quick.changed?'on':''}" data-quick="changed">Δ Changed in ${esc(S.diff.cl)}</button>`:''}
    ${view.kind==='all'&&hasAreas()?`<button class="btn ${st.areas&&st.areas.size?'on':''}" data-areabtn="all">Area: ${esc(areaLabel(st.areas))} ▾</button>`:''}
    ${view.kind!=='all'?`<button class="btn" data-act="addrow" title="${sh.kind==='entity'?'Add a field or an N:N relationship to this table':'Add a row to this sheet'}">＋ ${sh.kind==='entity'?'Add field':'Add row'}</button>`:''}
    <button class="btn" data-act="cols">Columns ▾</button>
    <button class="btn" data-act="expall" title="Show full text in every row, or clamp rows to two lines">${S.ui.expanded===false?'⊞ Expand all rows':'⊟ Collapse all rows'}</button>
        <span class="grow"></span>
    <span class="count" id="count"></span></div>`;
  const afs=[];
  if(st.q) afs.push(`<span class="af">Search: ${esc(st.q)} <button data-clr="q">×</button></span>`);
  Object.keys(st.quick).forEach(k=>{if(st.quick[k])afs.push(`<span class="af">${({custom:'Custom only',raf:'On RAF form',comment:'Has comment',req:'Required',edited:'Edited',changed:'Changed in '+(S.diff?S.diff.cl:'new version')})[k]} <button data-clr="quick:${k}">×</button></span>`)});
  if(st.areas&&st.areas.size) afs.push(`<span class="af">Area: ${esc([...st.areas].join(', '))} <button data-clr="areas">×</button></span>`);
  Object.keys(st.filters).forEach(c=>{const f=st.filters[c];const d=[];if(f.text)d.push('contains “'+f.text+'”');if(f.sel)d.push([...f.sel].slice(0,4).join(', ')+(f.sel.size>4?' +'+(f.sel.size-4):''));afs.push(`<span class="af">${esc(c)}: ${esc(d.join(' · '))} <button data-clr="col:${esc(c)}">×</button></span>`)});
  const afHTML=afs.length?`<div class="active-filters">${afs.join('')}<button class="btn ghost" style="height:24px" data-clr="all">Clear all</button></div>`:'';
  main.innerHTML=head+tb+afHTML+`<div class="gridwrap" id="gridwrap"></div>`;
  renderGrid();
}
function subsHTML(view){
  const sh=view.sh; if(!sh||!sh.subs||!sh.subs.length) return '';
  const hasAny=sh.subs.some(s=>s.cols.length);
  if(!hasAny) return '';
  return '<div class="subs">'+sh.subs.filter(s=>s.cols.length).map(s=>`<div class="subsec"><h4>${esc(s.title)} <span class="dim">· ${s.rows.length}</span></h4>${s.rows.length?`<table class="subtbl"><thead><tr>${s.cols.map(c=>`<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${s.rows.map(r=>`<tr>${r.vals.map(v=>`<td>${esc(v)}</td>`).join('')}</tr>`).join('')}</tbody></table>`:'<div class="dim">None listed.</div>'}</div>`).join('')+'<div class="dim" style="padding:0 0 4px">Forms and views are listed here separately from the fields, and are included in the export.</div></div>';
}
function renderGrid(append){
  const view=S.view; const st=vstate(view.id);
  const wrap=$('#gridwrap'); if(!wrap) return;
  const cols=visibleCols(view);
  const terms=st.q.trim().toLowerCase().split(/\s+/).filter(Boolean);
  const items=S.filtered;
  $('#count').textContent=items.length===view.items.length?`${items.length} rows`:`${items.length} of ${view.items.length} rows`;
  if(!items.length){wrap.innerHTML='<div class="empty"><b>No rows match.</b><br>Try clearing a filter or search.</div>';return}
  const upto=Math.min(items.length,st.shown);
  const fcols=Object.keys(st.filters);
  let h='<table class="grid"><colgroup>'+cols.map(c=>`<col style="width:${WIDTHS[c]||160}px">`).join('')+'</colgroup><thead><tr>';
  cols.forEach((c,i)=>{
    const so=st.sort&&st.sort.col===c?(st.sort.dir>0?' ▲':' ▼'):'';
    const on=fcols.includes(c);
    const hint=(view.sh&&view.sh.hints[c])||'';
    h+=`<th class="${i===0?'stickycol':''} ${hint?'hint':''}" ${hint?`title="${esc(hint)}"`:''}><div class="th"><span class="lbl" data-sort="${esc(c)}">${esc(c)}${so}${isExtraCol(view,c)?'<span class="xtag" title="Not in the template. It is kept, and formatted like the template header on export.">new</span>':''}${view.sh&&view.sh.tmplAdded&&view.sh.tmplAdded.includes(c)?'<span class="xtag" title="From the template: this workbook does not have this column yet. It is added to the file when you save a value in it.">added</span>':''}</span><button class="fbtn ${on?'on':''}" data-filter="${esc(c)}" title="Filter">${ICON_FILTER}</button></div></th>`;
  });
  h+='</tr></thead><tbody>';
  for(let i=0;i<upto;i++){
    const it=items[i];
    const open=S.rowOv.has(it.row)?S.rowOv.get(it.row):S.ui.expanded!==false;
    h+=`<tr data-i="${i}" tabindex="0" class="${S.selItem===it.row?'sel':''} ${open?'':'rcol'}">`;
    cols.forEach((c,ci)=>{
      const edited=c!=='Table'&&isEdited(it.sh,it.row,c);
      const v=cellVal(view,it,c);
      const upd=c!=='Table'&&it.row.chg&&Object.prototype.hasOwnProperty.call(it.row.chg,c);
      const tog=ci===0?`<button class="rt" data-rt title="${open?'Collapse':'Expand'} this row">${open?'▾':'▸'}</button>`:'';
      const newTag=tog+(ci===0&&it.row.added?'<span class="pill p-green" style="margin-right:6px" title="Added in this page. It is written to the workbook when you save or export.">ADDED</span>':ci===0&&it.row.isNew?'<span class="pill p-green" style="margin-right:6px">NEW</span>':'');
      h+=`<td class="${ci===0?'stickycol':''} ${isEditable(view,c)?'editable':''} ${edited?'edited':''} ${upd&&!edited?'upd':''}" data-col="${esc(c)}" ${upd?`title="Changed in ${esc(S.diff.cl)} — was: ${esc(it.row.chg[c]||'(blank)')}"`:''}><div class="cell">${newTag}${cellHTML(view,it,c,terms)}${ci===0&&isPkRow(it.sh,it.row)?' <span class="pill p-pk" title="The primary key of this table">Primary key</span>':''}${ci===0&&isPnameRow(it.sh,it.row)?' <span class="pill p-blue" title="The primary name column of this table">Primary name</span>':''}${ci===0&&isNNRow(it.sh,it.row)?' <span class="pill p-violet" title="A many-to-many relationship, not a field">N:N</span>':''}</div></td>`;
    });
    h+='</tr>';
  }
  h+='</tbody></table>';
  h+=subsHTML(view)+dvHTML(view.sh);
  if(upto<items.length) h+=`<div class="more"><button class="btn" data-act="more">Show ${Math.min(150,items.length-upto)} more (${items.length-upto} remaining)</button></div>`;
  const sc=wrap.scrollTop;
  wrap.innerHTML=h; if(append) wrap.scrollTop=sc;
}

/* ---------- editing ---------- */
function startEdit(td,it,col){
  if(RO) return; // read-only copy
  if(td.classList.contains('editing')) return;
  const view=S.view; const sh=it.sh,row=it.row;
  const cur=getVal(sh,row,col);
  const l=col.toLowerCase();
  td.classList.add('editing');
  const long=cur.length>60||cur.includes('\n')||/comment|description|additional|purpose/i.test(col);
  const choice=isChoiceCol(sh,col)&&cur.length<=60&&!cur.includes('\n');
  let el,touched=false,isSel=false,swapping=false;
  const mkInput=()=>{const i=document.createElement('input');i.type='text';i.value=cur;return i};
  if(choice){
    isSel=true; const ck=nk(cur); const opts=choiceOptions(sh,col);
    el=document.createElement('select'); el.className='cellsel';
    el.innerHTML='<option value="">(blank)</option>'+opts.map(o=>`<option value="${esc(o.label)}" ${cur&&o.k===ck?'selected':''}>${esc(o.label)}</option>`).join('')+(cur&&!opts.some(o=>o.k===ck)?`<option value="${esc(cur)}" selected>${esc(cur)}</option>`:'')+'<option value="__new__">＋ New value…</option>';
    if(!cur) el.value='';
  } else if(!long){ el=mkInput(); }
  else {el=document.createElement('textarea'); el.value=cur; el.rows=Math.min(8,Math.max(3,cur.split('\n').length+1))}
  td.innerHTML=''; td.appendChild(el); el.focus(); if(el.select&&!long&&!isSel) el.select();
  let done=false;
  const finish=(commit)=>{
    if(done) return; done=true;
    if(commit&&(!isSel||touched)&&el.value!==cur&&el.value!=='__new__'){setVal(sh,row,col,el.value); askLookupTarget(sh,row,col,()=>{afterEdit()})}
    afterEdit();
  };
  const wire=(e,sel)=>{
    e.addEventListener('keydown',ev=>{
      if(ev.key==='Escape'){ev.preventDefault();ev.stopPropagation();finish(false)} // Esc cancels the edit only, it doesn't also close panels
      else if(ev.key==='Enter'&&(sel||!long||!ev.shiftKey)){ev.preventDefault();finish(true)}
      else if(ev.key==='Tab'){ev.preventDefault();finish(true)}
    });
    e.addEventListener('blur',()=>{if(!swapping)finish(true)});
  };
  wire(el,isSel);
  if(isSel) el.addEventListener('change',()=>{
    touched=true;
    if(el.value==='__new__'){
      const old=el; const i=mkInput(); i.value=''; i.placeholder='New value for '+col;
      swapping=true; isSel=false; touched=false; el=i; td.innerHTML=''; td.appendChild(i); wire(i,false); swapping=false; i.focus();
    } else finish(true);
  });
}
function afterEdit(){
  const keepTop=$('#gridwrap')?$('#gridwrap').scrollTop:0, keepLeft=$('#gridwrap')?$('#gridwrap').scrollLeft:0;
  if(vstate(S.view.id).quick.edited||Object.keys(vstate(S.view.id).filters).length) S.filtered=filterItems(S.view);
  renderGrid(true); const w=$('#gridwrap'); if(w){w.scrollTop=keepTop;w.scrollLeft=keepLeft}
  if($('#detail').classList.contains('open')&&S.selItem) renderDetail();
  if($('#changes').classList.contains('open')) renderChanges();
  refreshStats();
}
function refreshStats(){
  // re-render stat counts only
  const box=$('.stats'); if(!box) return;
  const st=vstate(S.view.id);
  box.innerHTML=statsHTML(S.view,st);
}

/* ---------- detail drawer ---------- */
function renderDetail(){
  const d=$('#detail'); const it=S.selIt; if(!it){d.classList.remove('open');return}
  const {sh,row}=it;
  const idx=S.filtered.indexOf(it);
  const title=getVal(sh,row,'Display Name')||getVal(sh,row,'Table Name')||getVal(sh,row,sh.cols[0])||'Row';
  let h=`<header><div style="min-width:0;flex:1"><h3>${esc(title)}</h3><div class="mono dim">${esc(sh.label)}${idx>=0?` · ${idx+1} of ${S.filtered.length}`:''}</div></div>
    ${row.added?'<button class="btn danger" data-rmrow title="Remove this added row">Remove row</button>':''}<button class="btn" data-dnav="-1" title="Previous (k)">↑</button><button class="btn" data-dnav="1" title="Next (j)">↓</button><button class="btn ghost" data-dclose>✕</button></header><div class="body">`;
  if(sh.kind==='entity'&&getVal(sh,row,'Logical Name').trim()&&!isNNRow(sh,row)){
    const isK=String(sh.mo['primary key']||'').trim().toLowerCase()===getVal(sh,row,'Logical Name').trim().toLowerCase(), isN=isPnameRow(sh,row);
    h+=`<div class="keybar">${isK?'<span class="pill p-pk">Primary key</span>':'<button class="btn" data-setkey="pk" title="Record this field as the table\'s primary key in its table details">Set as primary key</button>'}${isN?'<span class="pill p-blue">Primary name</span>':'<button class="btn" data-setkey="pn" title="Record this field as the table\'s primary name column in its table details">Set as primary name</button>'}</div>`;
  }
  sh.cols.forEach(c=>{
    const v=getVal(sh,row,c); const edited=isEdited(sh,row,c); const l=c.toLowerCase();
    let shown;
    if(l==='additional data') shown=v?renderAddl(v,true):'<span class="dim">—</span>';
    else if(l==='attribute type'&&v) shown=pillType(v);
    else shown=v===''?'<span class="dim">— click to add —</span>':esc(v);
    const o=row.orig[sh.colIdx[c]];
    h+=`<div class="fld" data-fcol="${esc(c)}"><div class="k">${esc(c)}</div><div class="v ${edited?'edited':''}" data-fedit tabindex="0" role="button" aria-label="Edit ${esc(c)}">${shown}</div>${edited?`<div class="orig">was: <i>${esc(o||'(blank)')}</i><a href="#" data-revert="${esc(c)}">revert</a></div>`:''}${row.chg&&Object.prototype.hasOwnProperty.call(row.chg,c)?`<div class="orig">changed in ${esc(S.diff.cl)} — was: <i>${esc(row.chg[c]||'(blank)')}</i></div>`:''}</div>`;
  });
  d.innerHTML=h+'</div>'; d.classList.add('open');
}
function openDetail(it){$('#changes').classList.remove('open');$('#versions').classList.remove('open');S.selIt=it;S.selItem=it.row;renderDetail();document.querySelectorAll('#gridwrap tr.sel').forEach(r=>r.classList.remove('sel'));const tr=$(`#gridwrap tr[data-i="${S.filtered.indexOf(it)}"]`);if(tr)tr.classList.add('sel')}
function editInDetail(box,col){
  if(RO) return; // read-only copy
  const {sh,row}=S.selIt; const cur=getVal(sh,row,col);
  const v=box.querySelector('.v'); if(v.querySelector('textarea,input,select')) return;
  const choice=isChoiceCol(sh,col)&&cur.length<=60&&!cur.includes('\n');
  let el,isSel=false,touched=false,swapping=false,done=false;
  const mkText=()=>{const ta=document.createElement('textarea');ta.value=cur;ta.rows=Math.min(10,Math.max(2,cur.split('\n').length+1));return ta};
  if(choice){
    isSel=true; const ck=nk(cur); const opts=choiceOptions(sh,col);
    el=document.createElement('select'); el.className='cellsel';
    el.innerHTML='<option value="">(blank)</option>'+opts.map(o=>`<option value="${esc(o.label)}" ${cur&&o.k===ck?'selected':''}>${esc(o.label)}</option>`).join('')+(cur&&!opts.some(o=>o.k===ck)?`<option value="${esc(cur)}" selected>${esc(cur)}</option>`:'')+'<option value="__new__">＋ New value…</option>';
    if(!cur) el.value='';
  } else el=mkText();
  v.innerHTML=''; v.appendChild(el); el.focus();
  const fin=c=>{if(done)return;done=true;if(c&&(!isSel||touched)&&el.value!==cur&&el.value!=='__new__'){setVal(sh,row,col,el.value); askLookupTarget(sh,row,col,()=>{afterEdit();renderDetail()})}afterEdit();renderDetail()};
  const wire=e=>{
    e.addEventListener('keydown',ev=>{if(ev.key==='Escape'){ev.preventDefault();ev.stopPropagation();fin(false)}else if(ev.key==='Enter'&&(isSel||!ev.shiftKey)){ev.preventDefault();fin(true)}});
    e.addEventListener('blur',()=>{if(!swapping)fin(true)});
  };
  wire(el);
  if(isSel) el.addEventListener('change',()=>{
    touched=true;
    if(el.value==='__new__'){const i=mkText();i.value='';i.placeholder='New value for '+col;swapping=true;isSel=false;touched=false;el=i;v.innerHTML='';v.appendChild(i);wire(i);swapping=false;i.focus()}
    else fin(true);
  });
}

/* ---------- adding rows ---------- */
function dropAdded(sh,row,fromChanges){
  const ln=getVal(sh,row,'Logical Name')||getVal(sh,row,'Table Name');
  removeRow(sh,row); persist(); updateCounts(); applyAndRender();
  if(fromChanges||$('#changes').classList.contains('open')) renderChanges();
  toast((ln?'"'+ln+'"':'The row')+' was removed');
}
// after a row is added: show it, open it in the detail panel, and keep everything in step
function showAdded(sh,row){
  persist(); updateCounts(); go(sh.idx,{focusRow:row});
  const it=S.filtered.find(x=>x.row===row); if(it) openDetail(it);
}
function addRowUI(sh){
  if(RO) return; // read-only copy
  if(sh.kind!=='entity'){const row=addRow(sh,{}); showAdded(sh,row); toast('Row added at the end. Fill it in on the right.'); return}
  addFieldDialog(sh);
}
const FIELD_TYPES=['String','Memo','Integer','Decimal','Double','Money','DateTime','Boolean','Picklist','MultiSelectPicklist','Lookup','Customer'];
// the publisher prefix for a new field: the table's own when it is a custom table, otherwise the workbook's usual one
function fieldPrefix(sh){const m=/^([a-z][a-z0-9]{1,7})_/.exec(sh.logical||''), own=ownPrefixes(); if(m&&sh.custom&&!isMsPrefix(m[1])&&(!myPubs().length||own.has(m[1]))) return m[1]; return solDefaults().prefix}
function addFieldDialog(sh){
  const P=fieldPrefix(sh), strip=s=>String(s||'').toLowerCase().replace(/^[a-z0-9]{2,8}_/,'').replace(/[^a-z0-9]/g,'');
  const has=c=>sh.colIdx[c]!==undefined;
  const opts=(col,dflt)=>{const seen=new Set(), o=[]; choiceOptions(sh,col).map(x=>x.label).concat(dflt).forEach(v=>{const k=nk(v); if(v&&!seen.has(k)){seen.add(k);o.push(v)}}); return o};
  const tables=S.sheets.filter(s=>s.kind==='entity'&&s.logical).map(s=>s.logical).sort();
  const dl=(id,vals)=>`<datalist id="${id}">${vals.map(v=>`<option value="${esc(v)}"></option>`).join('')}</datalist>`;
  const f=(k,label,input,hint)=>`<label class="solf" data-f="${k}"><span>${label}</span>${input}<small>${hint||''}</small></label>`;
  const m=document.createElement('div'); m.className='convmask'; m.setAttribute('role','dialog'); m.setAttribute('aria-modal','true'); m.setAttribute('aria-label','Add a field');
  m.innerHTML=`<div class="convbox solbox"><h3>Add to ${esc(sh.label)}</h3><p class="dim" style="margin:4px 0 12px">The new row goes at the end of the field list. Everything else (choice options, length, format, cascade) can be filled in on the row afterwards.</p>
    <div class="solgrid">
      ${f('kind','Add',`<select data-k="kind"><option value="field">A field</option>${has('Relationship Type')?'<option value="nn">An N:N relationship</option>':''}</select>`,has('Relationship Type')?'':'N:N needs a Relationship Type column (in the current template)')}
      ${f('Display Name','Display name',`<input data-k="Display Name" autocomplete="off">`)}
      ${f('Logical Name','Logical name',`<input data-k="Logical Name" autocomplete="off" spellcheck="false">`,'lower case, with the prefix')}
      ${has('Schema Name')?f('Schema Name','Schema name',`<input data-k="Schema Name" autocomplete="off" spellcheck="false">`):''}
      ${has('Attribute Type')?f('Attribute Type','Field type',`<input data-k="Attribute Type" list="dme-at" autocomplete="off">`+dl('dme-at',opts('Attribute Type',FIELD_TYPES)),'pick one or type it'):''}
      ${f('target','Related table',`<input data-k="target" list="dme-tb" autocomplete="off" spellcheck="false">`+dl('dme-tb',tables),'the table it points to (logical name)')}
      ${has('Required Level')?f('Required Level','Required level',`<input data-k="Required Level" list="dme-rl" autocomplete="off">`+dl('dme-rl',opts('Required Level',['None','Recommended','ApplicationRequired']))):''}
      ${has('Description')?f('Description','Description',`<input data-k="Description" autocomplete="off">`):''}
    </div>
    <div class="solerr" id="adderr"></div>
    <div class="convbtns"><button class="btn" data-add="cancel">Cancel</button> <button class="btn primary" data-add="go">Add</button></div></div>`;
  document.body.appendChild(m);
  const q=k=>m.querySelector(`[data-k="${k}"]`), show=(k,on)=>{const x=m.querySelector(`[data-f="${k}"]`); if(x) x.style.display=on?'':'none'};
  const touched=new Set();
  const isNN=()=>q('kind').value==='nn', isLk=()=>!isNN()&&q('Attribute Type')&&isLookupType(q('Attribute Type').value);
  // names follow the display name (or, for N:N, the two tables) until you type them yourself
  const auto=()=>{
    show('Attribute Type',!isNN()); show('Required Level',!isNN()); show('target',isNN()||isLk());
    m.querySelector('[data-f="target"] small').textContent=isNN()?'the other table in the relationship':'the table the lookup points to';
    const dn=q('Display Name').value.trim(), words=dn.replace(/[^A-Za-z0-9 ]/g,' ').split(/\s+/).filter(Boolean);
    let ln, sn;
    if(isNN()){const tg=q('target').value.trim().toLowerCase(); ln=tg?P+'_'+strip(sh.logical)+'_'+strip(tg):''; sn=ln}
    else {ln=words.length?P+'_'+words.join('').toLowerCase():''; sn=words.length?P+'_'+words.map(w=>w[0].toUpperCase()+w.slice(1)).join(''):''}
    if(!touched.has('Logical Name')) q('Logical Name').value=ln;
    if(q('Schema Name')&&!touched.has('Schema Name')) q('Schema Name').value=sn;
  };
  m.addEventListener('input',e=>{const k=e.target.dataset.k; if(k==='Logical Name'||k==='Schema Name') touched.add(k); auto()});
  m.addEventListener('change',auto); auto();
  const read=()=>{
    const o={}; m.querySelectorAll('[data-k]').forEach(i=>o[i.dataset.k]=i.value.trim());
    const err=[], ln=o['Logical Name'].toLowerCase(), tg=o.target.toLowerCase();
    if(!ln) err.push('Give it a logical name.');
    else if(!/^[a-z][a-z0-9_]*$/.test(ln)) err.push('Logical names are lower-case letters, digits and underscores, starting with a letter.');
    else if(sh.rows.some(r=>getVal(sh,r,'Logical Name').trim().toLowerCase()===ln)) err.push('"'+ln+'" is already in this table.');
    if((isNN()||isLk())&&!tg) err.push(isNN()?'Pick the other table.':'Pick the table the lookup points to.');
    if(!isNN()&&!o['Display Name']) err.push('Give it a display name.');
    m.querySelector('#adderr').innerHTML=err.map(x=>`<div>${esc(x)}</div>`).join('');
    if(err.length) return null;
    const v={'Logical Name':ln,'Schema Name':o['Schema Name']||'','Display Name':o['Display Name'],'Description':o.Description||''};
    if(isNN()){v['Relationship Type']='N:N'; v['Additional data']='Targets: '+tg}
    else {
      v['Attribute Type']=o['Attribute Type']||''; v['Required Level']=o['Required Level']||'';
      if(isLk()){v['Relationship Type']='N:1'; v['Additional data']='Targets: '+tg}
      if(has('Custom Attribute')&&ln.startsWith(P+'_')) v['Custom Attribute']='True';
    }
    return v;
  };
  const close=()=>{document.removeEventListener('keydown',key,true);m.remove()};
  const submit=()=>{const v=read(); if(!v) return; close(); const row=addRow(sh,v); showAdded(sh,row); toast('"'+v['Logical Name']+'" added to '+sh.label+'. Fill in the rest on the right.')};
  const key=e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();close()}else if(e.key==='Enter'&&e.target.tagName!=='SELECT'){e.preventDefault();e.stopPropagation();submit()}};
  document.addEventListener('keydown',key,true);
  m.addEventListener('click',e=>{const b=e.target.closest('[data-add]'); if(!b){if(e.target===m)close();return} if(b.dataset.add==='cancel') close(); else submit()});
  q('Display Name').focus();
}

// A field changed to Lookup with no table in "Targets:" yet: ask which table, then write "Targets: <table>" into Additional data
// (and N:1 into an empty Relationship Type), as Add field does for a new lookup. Skipping leaves it for Checks to flag.
function askLookupTarget(sh,row,col,done){
  if(col!=='Attribute Type'||!/^lookup$/i.test(getVal(sh,row,col).trim())||sh.colIdx['Additional data']===undefined||lookupTargetsOf(sh,row).length) return;
  const ln=getVal(sh,row,'Logical Name').trim(), name=getVal(sh,row,'Display Name').trim()||ln||'this field';
  const tables=[...new Set([...S.sheets.filter(s=>s.kind==='entity'&&s.logical).map(s=>s.logical.toLowerCase()).sort(),'account','contact','systemuser','team','businessunit','transactioncurrency'])];
  const m=document.createElement('div'); m.className='convmask'; m.setAttribute('role','dialog'); m.setAttribute('aria-modal','true'); m.setAttribute('aria-label','Lookup table');
  m.innerHTML=`<div class="convbox solbox" style="max-width:520px"><h3>Which table does ${esc(name)} look up to?</h3><p class="dim" style="margin:4px 0 12px">Adds <span class="mono">Targets:</span> and the table to Additional data${sh.colIdx['Relationship Type']!==undefined&&!getVal(sh,row,'Relationship Type').trim()?', and N:1 as the Relationship Type':''}.</p>
    <label class="solf"><span>Related table (logical name)</span><input data-lt list="dme-lt" autocomplete="off" spellcheck="false" placeholder="for example account"><small></small></label><datalist id="dme-lt">${tables.map(t=>`<option value="${esc(t)}"></option>`).join('')}</datalist>
    <div class="solerr" id="lterr"></div>
    <div class="convbtns"><button class="btn" data-lta="skip">Skip</button> <button class="btn primary" data-lta="go">Add target</button></div></div>`;
  document.body.appendChild(m);
  const inp=m.querySelector('[data-lt]');
  const close=()=>{document.removeEventListener('keydown',key,true);m.remove()};
  const go=()=>{const tg=inp.value.trim().toLowerCase();
    if(!/^[a-z][a-z0-9_]*$/.test(tg)){m.querySelector('#lterr').textContent='Pick a table, or type its logical name (lower-case letters, digits and underscores).';return}
    const ad=getVal(sh,row,'Additional data').replace(/\s+$/,'');
    setVal(sh,row,'Additional data',(ad?ad+'\n':'')+'Targets: '+tg,true);
    if(sh.colIdx['Relationship Type']!==undefined&&!getVal(sh,row,'Relationship Type').trim()) setVal(sh,row,'Relationship Type','N:1',true);
    persist(); updateCounts(); close(); if(done) done(); toast(name+' now looks up to '+tg)};
  const key=e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();close()}else if(e.key==='Enter'){e.preventDefault();e.stopPropagation();go()}};
  document.addEventListener('keydown',key,true);
  m.addEventListener('click',e=>{const b=e.target.closest('[data-lta]'); if(!b){if(e.target===m)close();return} if(b.dataset.lta==='skip') close(); else go()});
  setTimeout(()=>inp.focus(),0);
}
/* ---------- table details dialog ---------- */
function detailsDialog(sh){
  const fields=sh.rows.map(r=>getVal(sh,r,'Logical Name').trim()).filter(Boolean);
  const listFor=k=>/^(primary name column|primary key)$/i.test(k)?'dme-fl':/^(is activity|has notes|has activities|is custom entity|audit tracking)$/i.test(k)?'dme-tf':/^ownership type$/i.test(k)?'dme-own':'';
  const m=document.createElement('div'); m.className='convmask'; m.setAttribute('role','dialog'); m.setAttribute('aria-modal','true'); m.setAttribute('aria-label','Table details');
  m.innerHTML=`<div class="convbox solbox"><h3>Table details · ${esc(sh.label)}</h3><p class="dim" style="margin:4px 0 12px">The label and value rows above the field list. Details the template has but this table lacks are included, blank. Changes are kept with your edits and written to the workbook when you save or export.</p>
    <div class="solgrid">${sh.meta.map(([k,v],i)=>{const o=sh.metaOrig[k.toLowerCase()]; return `<label class="solf"><span>${esc(k)}${sh.metaAdded.includes(k)?' <span class="xtag" title="From the template">added</span>':''}</span><input data-mi="${i}" value="${esc(v)}" ${listFor(k)?`list="${listFor(k)}"`:''} autocomplete="off" spellcheck="false"><small>${o!=null&&o!==v?'was: '+esc(o||'(blank)'):''}</small></label>`}).join('')}</div>
    <datalist id="dme-fl">${fields.map(x=>`<option value="${esc(x)}"></option>`).join('')}</datalist><datalist id="dme-tf"><option value="True"></option><option value="False"></option></datalist><datalist id="dme-own"><option value="UserOwned"></option><option value="OrganizationOwned"></option></datalist>
    <div class="convbtns"><button class="btn" data-dd="cancel">Cancel</button> <button class="btn primary" data-dd="save">Save</button></div></div>`;
  document.body.appendChild(m);
  const close=()=>{document.removeEventListener('keydown',key,true);m.remove()};
  const save=()=>{let n=0; m.querySelectorAll('[data-mi]').forEach(i=>{const d=sh.meta[+i.dataset.mi]; if(d&&i.value!==d[1]){setMeta(sh,d[0],i.value,true);n++}}); close(); if(n){persist();updateCounts();applyAndRender();if($('#changes').classList.contains('open'))renderChanges();toast(n+' detail'+(n===1?'':'s')+' changed')}};
  const key=e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();close()}else if(e.key==='Enter'){e.preventDefault();e.stopPropagation();save()}};
  document.addEventListener('keydown',key,true);
  m.addEventListener('click',e=>{const b=e.target.closest('[data-dd]'); if(!b){if(e.target===m)close();return} if(b.dataset.dd==='cancel') close(); else save()});
  const first=m.querySelector('[data-mi]'); if(first) first.focus();
}
/* ---------- change log ---------- */
function renderChanges(){
  const d=$('#changes');
  const list=[...S.edits.values()], adds=addedRows();
  let h=`<header><h3>Changes (${changeTotal()})</h3><button class="btn" data-act="exp-log" ${list.length?'':'disabled'}>Export log (CSV)</button><button class="btn" data-act="revert-all" ${list.length||adds.length||S.metaEd.size?'':'disabled'}>Revert all</button><button class="btn ghost" data-cclose>✕</button></header><div class="body">`;
  if(S.pending.length){
    h+=`<div class="vsec"><h4 style="color:var(--pink)">Needs your attention (${S.pending.length})</h4><div class="dim" style="margin-bottom:8px">These edits were made on an earlier version and could not be applied automatically.</div>`;
    S.pending.forEach((p,i)=>{
      const r=p.rec;
      if(p.type==='mconflict') h+=`<div class="chg"><div class="w"><b>${esc(p.sh.label)}</b> · table details · ${esc(r.k)} <span style="flex:1"></span></div><div class="dim" style="margin-top:4px">The new version changed this detail, and you had changed it.</div><div class="d"><div class="o">New version: ${p.up?esc(p.up):'<i>(blank)</i>'}</div><div class="nw">Yours: ${r.n?esc(r.n):'<i>(cleared)</i>'}</div></div><div style="display:flex;gap:6px;margin-top:6px"><button class="btn" data-papply="${i}">Keep mine</button><button class="btn" data-pdrop="${i}">Use new version</button></div></div>`;
      else if(p.type==='conflict') h+=`<div class="chg"><div class="w"><b>${esc(p.sh.label)}</b> · <span class="mono">${esc(r.k)}</span> · ${esc(r.c)} <span style="flex:1"></span><a href="#" data-pgo="${i}">go</a></div><div class="dim" style="margin-top:4px">The new version changed this value, and you had edited it.</div><div class="d"><div class="o">New version: ${p.up?esc(p.up):'<i>(blank)</i>'}</div><div class="nw">Your edit: ${r.n?esc(r.n):'<i>(cleared)</i>'}</div></div><div style="display:flex;gap:6px;margin-top:6px"><button class="btn" data-papply="${i}">Keep mine</button><button class="btn" data-pdrop="${i}">Use new version</button></div></div>`;
      else if(p.type==='exists') h+=`<div class="chg"><div class="w"><b>${esc(p.sh.label)}</b> · <span class="mono">${esc((r.v||{})['Logical Name']||'')}</span> · row you added</div><div class="dim" style="margin-top:4px">The new version already has a field with this logical name.</div><div style="display:flex;gap:6px;margin-top:6px"><button class="btn" data-pdrop="${i}">Use the new version's</button><button class="btn" data-papply="${i}">Add mine as well</button></div></div>`;
      else if(r.d) h+=`<div class="chg"><div class="w"><b>${esc(r.s)}</b> · table details · ${esc(r.k)}</div><div class="dim" style="margin-top:4px">This table is not in the new version.</div><div style="margin-top:6px"><button class="btn" data-pdrop="${i}">Discard</button></div></div>`;
      else if(r.a) h+=`<div class="chg"><div class="w"><b>${esc(r.s)}</b> · <span class="mono">${esc((r.v||{})['Logical Name']||'')}</span> · row you added</div><div class="dim" style="margin-top:4px">This table is not in the new version.</div><div style="margin-top:6px"><button class="btn" data-pdrop="${i}">Discard</button></div></div>`;
      else h+=`<div class="chg"><div class="w"><b>${esc(r.s)}</b> · <span class="mono">${esc(r.k)}</span> · ${esc(r.c)}</div><div class="dim" style="margin-top:4px">This field or table is not in the new version.</div><div class="d"><div class="nw">Your edit: ${r.n?esc(r.n):'<i>(cleared)</i>'}</div></div><div style="margin-top:6px"><button class="btn" data-pdrop="${i}">Discard</button></div></div>`;
    });
    h+='</div>';
  }
  if(adds.length){
    h+=`<div class="vsec"><h4>Rows added (${adds.length})</h4>`;
    adds.forEach(({sh,row},i)=>{const ln=getVal(sh,row,'Logical Name')||getVal(sh,row,'Table Name')||getVal(sh,row,sh.cols[0])||'(blank row)', dn=getVal(sh,row,'Display Name');
      h+=`<div class="chg"><div class="w"><b>${esc(sh.label)}</b> · <span class="mono">${esc(ln)}</span>${dn&&dn!==ln?' · '+esc(dn):''}${isNNRow(sh,row)?' · N:N':''} <span style="flex:1"></span><a href="#" data-ago="${i}">go</a><a href="#" data-arm="${i}">remove</a></div></div>`});
    h+='</div>';
  }
  if(S.metaEd.size){
    h+=`<div class="vsec"><h4>Table details (${S.metaEd.size})</h4>`;
    [...S.metaEd.values()].forEach((e,i)=>{h+=`<div class="chg"><div class="w"><b>${esc(e.sh.label)}</b> · ${esc(e.k)} <span style="flex:1"></span><a href="#" data-mgo="${i}">go</a><a href="#" data-mrev="${i}">revert</a></div><div class="d">${e.old?`<div class="o">${esc(e.old)}</div>`:''}<div class="nw">${e.nw?esc(e.nw):'<i>(cleared)</i>'}</div></div></div>`});
    h+='</div>';
  }
  if(!list.length&&!adds.length&&!S.metaEd.size&&!S.pending.length) h+='<div class="empty">No edits yet.<br>Double-click any cell to edit it, or open a row and click a value. Use ＋ Add field to add a row to a table.<br>Edits are saved in this browser and survive a reload.</div>';
  list.forEach((e,i)=>{
    if(e.row.added) return;   // listed with its row above
    const key=getVal(e.sh,e.row,'Logical Name')||getVal(e.sh,e.row,'Table Name')||rowNo(e.row);
    h+=`<div class="chg"><div class="w"><b>${esc(e.sh.label)}</b> · <span class="mono">${esc(key)}</span> · ${esc(e.col)} <span style="flex:1"></span><a href="#" data-cgo="${i}">go</a><a href="#" data-crev="${i}">revert</a></div><div class="d">${e.old?`<div class="o">${esc(e.old)}</div>`:''}<div class="nw">${e.nw?esc(e.nw):'<i>(cleared)</i>'}</div></div></div>`;
  });
  d.innerHTML=h+'</div>'; $('#versions').classList.remove('open'); $('#detail').classList.remove('open'); d.classList.add('open');
}

/* ---------- popovers ---------- */
function closePops(){document.querySelectorAll('.pop,.menu').forEach(p=>p.remove())}
function placePop(el,anchor){
  document.body.appendChild(el);
  const r=anchor.getBoundingClientRect(); const w=el.offsetWidth,hh=el.offsetHeight;
  el.style.left=Math.max(8,Math.min(innerWidth-w-8,r.left))+'px';
  el.style.top=Math.min(innerHeight-hh-8,r.bottom+6)+'px';
}
function filterPop(col,anchor){
  closePops();
  const view=S.view; const st=vstate(view.id);
  const counts=new Map();
  view.items.forEach(it=>{const f=facet(col,cellVal(view,it,col));counts.set(f,(counts.get(f)||0)+1)});
  let vals=[...counts.entries()].sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0]));
  const high=vals.length>60;
  const cur=st.filters[col]||{sel:null,text:''};
  const sel=new Set(cur.sel||vals.map(v=>v[0]));
  const el=document.createElement('div'); el.className='pop';
  el.innerHTML=`<div class="ph"><span>${esc(col)}</span><span class="dim" style="font-weight:400">${vals.length} values</span></div>
   <input type="text" placeholder="${high?'Contains…':'Find value…'}" value="${esc(cur.text||'')}">
   <div class="plist"></div>
   <div class="pf"><button class="btn" data-pa="all">All</button><button class="btn" data-pa="none">None</button><span style="flex:1"></span><button class="btn primary" data-pa="apply">Apply</button></div>`;
  const inp=el.querySelector('input'), list=el.querySelector('.plist');
  const draw=()=>{
    const q=inp.value.toLowerCase();
    const shown=vals.filter(v=>!q||v[0].toLowerCase().includes(q)).slice(0,high?100:400);
    list.innerHTML=shown.map(v=>`<label><input type="checkbox" ${sel.has(v[0])?'checked':''} data-v="${esc(v[0])}"><span style="word-break:break-word">${esc(v[0])}</span><span class="n">${v[1]}</span></label>`).join('')||'<div class="dim" style="padding:8px">No values</div>';
  };
  draw();
  inp.addEventListener('input',draw);
  list.addEventListener('change',e=>{const v=e.target.dataset.v;if(e.target.checked)sel.add(v);else sel.delete(v)});
  el.addEventListener('click',e=>{
    const a=e.target.dataset.pa; if(!a) return;
    if(a==='all'){vals.forEach(v=>sel.add(v[0]));draw()}
    if(a==='none'){sel.clear();draw()}
    if(a==='apply'){
      const allSel=sel.size===vals.length;
      const useText=high?inp.value:'';
      if(allSel&&!useText) delete st.filters[col];
      else st.filters[col]={sel:allSel?null:new Set(sel),text:useText};
      st.shown=150; closePops(); applyAndRender();
    }
  });
  placePop(el,anchor); inp.focus();
}
function colsMenu(anchor){
  closePops();
  const view=S.view; const h=hidden(view);
  const el=document.createElement('div'); el.className='menu';
  el.innerHTML=view.cols.map(c=>`<label><input type="checkbox" data-c="${esc(c)}" ${h.includes(c)?'':'checked'}> ${esc(c)}</label>`).join('');
  el.addEventListener('change',e=>{
    const c=e.target.dataset.c; const arr=hidden(view);
    if(e.target.checked){const i=arr.indexOf(c);if(i>=0)arr.splice(i,1)}else arr.push(c);
    store.set('dme.ui',S.ui); renderGrid();
  });
  placePop(el,anchor);
}
// every workbook this browser keeps, newest first, then the empty template built into the page
function keptWorkbooks(){
  const list=S.lib.slice();
  if(!store.get('dme.hideb')) list.push({id:'bundled',name:'Empty template',b64:EMBEDDED_B64,bundled:true});
  return list;
}
function wbLabel(){const el=$('#wbName'); if(el){el.textContent=isStarter()?'No workbook open':S.fileName; el.parentElement.title=(isStarter()?'No workbook open. ':'Open: '+S.fileName+'. ')+'Switch to another workbook kept in this browser, or open a new one.'}}
function wbMenu(anchor){
  closePops();
  const el=document.createElement('div'); el.className='menu'; el.style.minWidth='300px';
  const items=keptWorkbooks().map(r=>{const on=r.b64===S.curB64;
    return `<button data-wb="${esc(r.id)}" ${on?'aria-current="true"':''}><span>${on?'✓ ':''}${esc(r.name)}</span><small>${r.bundled?'Built into this page':(r.tables??'?')+' tables · added '+esc(new Date(r.added).toLocaleDateString())}${on?' · open now':''}</small></button>`}).join('');
  el.innerHTML=`${isStarter()?'':`<button data-wb="__ver">Load a newer version of this workbook…<small>Your edits carry over, and the differences are shown</small></button>`}<button data-wb="__open">Open another workbook…<small>An .xlsx data model or a Metadata Document Generator export</small></button>${LIVE?'<button data-wb="__live">Load from this environment…<small>A solution\'s tables, read live</small></button>':''}<hr><div class="mh">Workbooks kept in this browser</div>${items}<hr><button data-wb="__files">Manage files…<small>Compare, download or remove</small></button>`;
  placePop(el,anchor); el.style.left=Math.max(8,Math.min(innerWidth-el.offsetWidth-8,anchor.getBoundingClientRect().left))+'px';
}
// switch to, or act on, a workbook chosen from the selector, the Overview, or the starter page
function wbChoose(id){
  closePops();
  if(id==='__open'||id==='__ver') return pickFile();
  if(id==='__live') return renderDv();
  if(id==='__files') return renderFiles();
  if(id==='__menu') return wbMenu($('#btnWb'));
  const r=keptWorkbooks().find(x=>x.id===id); if(!r||r.b64===S.curB64) return;
  libOpen(id,'open');
}
// small screens: everything that does not fit in the header, in one menu
function mobMenu(anchor){
  closePops();
  const el=document.createElement('div'); el.className='menu'; const n=S.edits.size+S.pending.length;
  el.innerHTML=`<button data-mob="wb">Workbook…<small>${esc(S.fileName)}</small></button><button data-mob="chg">Changes (${n})</button><button data-mob="check">Check…</button>${S.diff?`<button data-mob="ver">What changed (${S.diff.total})</button>`:''}<button data-mob="exp">Save &amp; share…</button>${RO?'':'<button data-mob="build">Build solution…</button>'}<button data-mob="help">How it works</button><div class="mh" style="text-transform:none;letter-spacing:0">Changes ${esc($('#saveState').textContent)} · ${esc($('#saveState').title)}</div>`;
  if(RO) el.querySelectorAll('[data-mob="open"],[data-mob="chg"],[data-mob="tmpl"]').forEach(b=>b.remove());
  el.addEventListener('click',e=>{const b=e.target.closest('[data-mob]'); if(!b) return; const a=b.dataset.mob; closePops();
    if(a==='exp'){setTimeout(()=>exportMenu($('#btnMob')),0);return}
    if(a==='check'){setTimeout(()=>checkMenu($('#btnMob')),0);return}
    if(a==='wb'){setTimeout(()=>wbMenu($('#btnMob')),0);return}
    if(a==='build'){doExport('solution');return}
    const t={open:'#btnOpen',ver:'#btnVer',chg:'#btnChanges',dv:'#btnDv',tmpl:'#btnTmpl',help:'#btnHelp'}[a]; if(t) $(t).click()});
  placePop(el,anchor); el.style.left=Math.max(8,anchor.getBoundingClientRect().right-el.offsetWidth)+'px';
}
function moreMenu(anchor){
  closePops();
  const el=document.createElement('div'); el.className='menu'; const tn=+$('#tmplCount').textContent||0;
  el.innerHTML=`<button data-more="dv">${LIVE?'This environment':'Dataverse check'}<small>${S.dv?'Checked against '+esc(S.dv.org||'imported metadata'):'Compare with a Dataverse environment'}</small></button><button data-more="tmpl"><span>Template</span><small>${tn?tn+' table'+(tn===1?' differs':'s differ')+' from the template':'Layout used for reading and exporting'}</small></button><hr><button data-more="help">How it works</button>`;
  if(RO) el.querySelectorAll('[data-more="tmpl"]').forEach(b=>b.remove());
  el.addEventListener('click',e=>{const b=e.target.closest('[data-more]'); if(!b) return; closePops(); ({dv:'#btnDv',tmpl:'#btnTmpl',help:'#btnHelp'})[b.dataset.more]&&$(({dv:'#btnDv',tmpl:'#btnTmpl',help:'#btnHelp'})[b.dataset.more]).click()});
  placePop(el,anchor); el.style.left=Math.max(8,anchor.getBoundingClientRect().right-el.offsetWidth)+'px';
}
function checkMenu(anchor){
  closePops();
  const el=document.createElement('div'); el.className='menu'; el.style.minWidth='300px'; const c=issueCounts(), tn=+$('#tmplCount').textContent||0;
  el.innerHTML=`<button data-ck="issues">Checks<small>${c.error} error${c.error===1?'':'s'} · ${c.warn} warning${c.warn===1?'':'s'} · ${c.info} info</small></button>`+
    `<button data-ck="dv">${LIVE?'This environment':'Compare with a solution…'}<small>${LIVE?'Load a solution, or check this workbook against the environment':S.dv?'Checked against '+esc(S.dv.zip?S.dv.sol.name:S.dv.org||'imported metadata'):'Fields, types and relationships against an environment'}</small></button>`+
    (S.diff?`<button data-ck="ver">What changed<small>${S.diff.total} difference${S.diff.total===1?'':'s'} from ${esc(S.diff.pl||'the previous version')}</small></button>`:'')+
    (RO?'':`<button data-ck="pubs">Publishers and prefixes<small>${myPubs().length?myPubs().map(p=>esc(p.prefix)+'_').join(', '):'Your customisation prefixes, and Microsoft\'s'}</small></button>`)+
    (RO?'':`<button data-ck="tmpl">Template<small>${tn?tn+' table'+(tn===1?' differs':'s differ')+' from the template':'Layout used for reading and exporting'}</small></button>`);
  el.addEventListener('click',e=>{const b=e.target.closest('[data-ck]'); if(!b) return; closePops(); const a=b.dataset.ck;
    if(a==='issues') go('__issues'); else if(a==='dv') $('#btnDv').click(); else if(a==='ver') $('#btnVer').click(); else if(a==='tmpl') $('#btnTmpl').click(); else if(a==='pubs') pubsDialog()});
  placePop(el,anchor); el.style.left=Math.max(8,Math.min(innerWidth-el.offsetWidth-8,anchor.getBoundingClientRect().left))+'px';
}
function exportMenu(anchor){
  closePops();
  const el=document.createElement('div'); el.className='menu';
  const n=changeTotal(), picker=!!window.showSaveFilePicker;
  // Save writes to the file the page is linked to; with none yet, it asks where (or downloads, where the browser can't ask)
  const save=`<button data-x="save">Save<kbd>Ctrl+S</kbd><small>${S.handle?(n?'Writes '+n+' change'+(n===1?'':'s')+' into '+esc(S.fileName):'No changes to save · linked to '+esc(S.fileName)):picker?'Choose where to save it: the page saves there from then on':'Downloads the workbook with your edits written in'}</small></button>`+
    `<button data-x="xlsx-orig">Save as…<small>${picker?'A new file, same formatting, your edits written in':'Download a copy, same formatting, your edits written in'}</small></button>`;
  // one CSV item; the tick box adds the hidden columns
  const csvItem=`<button data-x="csv">This view as CSV<small>The rows you can see${S.view?' in '+esc(S.view.label):''}</small></button><label class="mchk"><input type="checkbox" id="csvAll"> include hidden columns</label>`;
  el.innerHTML=RO?
    `<div class="mh">This workbook</div><button data-x="ro-xlsx">Download the workbook (.xlsx)<small>${esc(EMBEDDED_NAME)}, formatting kept</small></button><button data-x="xlsx-plain">Values only, no formatting (.xlsx)<small>Every sheet's values, no styling</small></button><hr><div class="mh">What you see</div>${csvItem}`:
    `<div class="mh">Save</div>${save}`+
    `<hr><div class="mh">Other formats</div><button data-x="xlsx">Rebuilt in the current template (.xlsx)<small>The whole workbook laid out afresh in the template</small></button><button data-x="xlsx-plain">Values only, no formatting (.xlsx)<small>Every sheet's values, no styling</small></button>`+
    `<hr><div class="mh">Share</div><button data-x="ro-copy">Read-only copy (.html)…<small>For a client or support team: this workbook, with your edits, to view but not change</small></button>${csvItem}`+
    `<hr><div class="mh">Build</div><button data-x="solution">Dataverse solution (.zip)…<small>Same as Build solution</small></button><button data-x="ps1">Import script (import.ps1)<small>Imports a solution zip with pac: installs pac if needed and signs you in</small></button><button data-x="manual">Calculated and rollup fields (.xlsx)<small>Per table, to create by hand after import</small></button>`+
    `<hr><div class="mh">Logs</div><button data-x="log">Change log (CSV)<small>Every edit, original against new</small></button>${S.diff?'<button data-x="diff">Version differences (CSV)</button>':''}`;
  el.addEventListener('click',e=>{const b=e.target.closest('[data-x]');let x=b&&b.dataset.x;if(!x)return; if(x==='csv'&&el.querySelector('#csvAll').checked) x='csv-all'; closePops();doExport(x)});
  placePop(el,anchor); el.style.left=Math.max(8,anchor.getBoundingClientRect().right-el.offsetWidth)+'px';
}

/* ---------- export ---------- */
function download(name,blob){const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500)}
// a cell starting with = + - @ (or a tab / carriage return) would run as a formula when the CSV is opened in Excel:
// prefix it with an apostrophe so it stays text
const csvCell=v=>{v=String(v??'');if(/^[=+\-@\t\r]/.test(v))v="'"+v;return /[",\n\r]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v};
const csv=rows=>'\ufeff'+rows.map(r=>r.map(csvCell).join(',')).join('\r\n');
const editLabel=e=>e.meta?'table details':getVal(e.sh,e.row,'Logical Name')||getVal(e.sh,e.row,'Table Name')||rowNo(e.row);
// the hand-build list: Summary, one block per table, and a flat filterable sheet
async function exportManual(){
  const buf=await manualWorkbook(); if(!buf) return toast('There are no calculated or rollup fields of your own to list');
  download(S.fileName.replace(/\.[^.]+$/,'')+' - calculated and rollup fields.xlsx',new Blob([buf],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}));
  const list=manualFields(); toast(list.length+' field'+(list.length===1?'':'s')+' in '+new Set(list.map(m=>m.sh)).size+' table'+(new Set(list.map(m=>m.sh)).size===1?'':'s')+' listed');
}
async function manualWorkbook(){
  const list=manualFields(); if(!list.length) return null;
  const v=(m,c)=>getVal(m.sh,m.row,c);
  const COLS=[['Display Name',28],['Logical Name',32],['Schema Name',30],['Kind',12],['Data type',16],['Description',48],['Details',36],['Required level',16],['Formula / definition (fill in)',48],['Created?',10]];
  const fieldVals=m=>[v(m,'Display Name'),m.ln,v(m,'Schema Name'),m.kind,v(m,'Attribute Type'),v(m,'Description'),v(m,'Additional data'),v(m,'Required Level'),'',''];
  const byTable=new Map(); list.forEach(m=>{(byTable.get(m.sh)||byTable.set(m.sh,[]).get(m.sh)).push(m)});
  const tables=[...byTable.keys()].sort((a,b)=>a.label.localeCompare(b.label));
  const NAVY='FF0A4873', GREY='FFECF1F5', head=r=>{r.font={bold:true};r.eachCell(c=>{c.fill={type:'pattern',pattern:'solid',fgColor:{argb:GREY}}})};
  const wb=new ExcelJS.Workbook();
  const sm=wb.addWorksheet('Summary');
  sm.addRow(['Calculated and rollup fields to create by hand']).font={bold:true,size:14};
  sm.addRow([S.fileName+' · '+new Date().toLocaleDateString()]).font={color:{argb:'FF4D6A82'}};
  sm.addRow([]); sm.addRow(['These fields are not in the generated solution. After importing it, create each one in Power Apps using the details on the "By table" sheet, and record the formula and progress there.']);
  sm.addRow([]); head(sm.addRow(['Table','Logical name','Area','Calculated','Rollup','Formula','Total']));
  tables.forEach(t=>{const ms=byTable.get(t), n=k=>ms.filter(m=>m.kind===k).length; sm.addRow([t.label,t.logical,areaOf(t),n('Calculated'),n('Rollup'),n('Formula'),ms.length])});
  const tot=k=>list.filter(m=>m.kind===k).length; sm.addRow(['Total','','',tot('Calculated'),tot('Rollup'),tot('Formula'),list.length]).font={bold:true};
  [34,32,18,12,10,10,10].forEach((w,i)=>sm.getColumn(i+1).width=w); sm.getRow(4).alignment={wrapText:true}; sm.mergeCells(4,1,4,7); sm.getRow(4).height=32;
  const bt=wb.addWorksheet('By table'); COLS.forEach(([,w],i)=>bt.getColumn(i+1).width=w);
  tables.forEach(t=>{
    const tr=bt.addRow([t.label+'  ('+t.logical+')'+(t.area?'  ·  '+t.area:'')+'  ·  '+byTable.get(t).length+' field'+(byTable.get(t).length===1?'':'s')]);
    bt.mergeCells(tr.number,1,tr.number,COLS.length); tr.font={bold:true,color:{argb:'FFFFFFFF'}}; tr.getCell(1).fill={type:'pattern',pattern:'solid',fgColor:{argb:NAVY}};
    head(bt.addRow(COLS.map(c=>c[0])));
    byTable.get(t).forEach(m=>{const r=bt.addRow(fieldVals(m)); r.alignment={wrapText:true,vertical:'top'}});
    bt.addRow([]);
  });
  const al=wb.addWorksheet('All fields'); const ah=['Table','Table logical name','Area',...COLS.map(c=>c[0])];
  [26,26,16,...COLS.map(c=>c[1])].forEach((w,i)=>al.getColumn(i+1).width=w); head(al.addRow(ah));
  tables.forEach(t=>byTable.get(t).forEach(m=>{const r=al.addRow([t.label,t.logical,areaOf(t),...fieldVals(m)]); r.alignment={wrapText:true,vertical:'top'}}));
  al.autoFilter={from:{row:1,column:1},to:{row:1,column:ah.length}}; al.views=[{state:'frozen',ySplit:1}];
  cutReport(fitExcelJS(wb),'Calculated and rollup fields');
  return await wb.xlsx.writeBuffer();
}
function changeRows(){
  const rows=[['Table','Row key','Column','Original','New']];
  S.edits.forEach(e=>rows.push([e.sh.label,editLabel(e),e.col,e.old,e.nw]));
  S.metaEd.forEach(e=>rows.push([e.sh.label,'(table details)',e.k,e.old,e.nw]));
  return rows;
}
async function buildOriginal(){
  if(!hasWrites()){toast('No edits to apply to the original');return null}
  if(!/\.xlsx$/i.test(S.fileName)){toast('Updating the original needs an .xlsx file. Use the template export instead.');return null}
  // Patch only the edited cells inside the original file's XML, so everything else (line breaks, styles,
  // validations, widths) is carried over byte for byte.
  const zip=await JSZip.loadAsync(b64ToU8(S.curB64));
  const parse=s=>new DOMParser().parseFromString(s,'application/xml');
  const wbx=parse(await zip.file('xl/workbook.xml').async('string')), rels=parse(await zip.file('xl/_rels/workbook.xml.rels').async('string'));
  const relT={}; [...rels.getElementsByTagName('Relationship')].forEach(r=>{relT[r.getAttribute('Id')]=r.getAttribute('Target')});
  const pathOf={}; [...wbx.getElementsByTagName('sheet')].forEach(s=>{
    const id=s.getAttribute('r:id')||s.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id'); let tg=relT[id]||''; tg=tg.replace(/^\/?(xl\/)?/,''); pathOf[s.getAttribute('name')]='xl/'+tg});
  // every edit ends up either placed (and checked below) or in `missed` with a reason. Callers refuse to save while anything is missed.
  const bySheet={}, missed=[], placed=[]; let n=0;
  // rows added in the page go in the empty rows straight after the field list. Rows are never inserted, so nothing
  // below (Forms, Views, validations) moves; if a section follows with too few empty rows, the save is refused.
  const slot=new Map(), styleRow=new Map();
  S.sheets.forEach(sh=>{
    const add=sh.rows.filter(r=>r.added&&r.vals.some(v=>v!=='')); if(!add.length) return;
    const real=sh.rows.filter(r=>!r.added&&r.r!=null).map(r=>r.r);
    let next=Math.max(sh.hi==null?-1:sh.hi,...real)+1; const lim=sh.fieldEnd==null?Infinity:sh.fieldEnd;
    add.forEach(r=>{if(next<lim){slot.set(r,next++);if(real.length)styleRow.set(r,Math.max(...real)+1+(sh.r0||0))}});
  });
  S.edits.forEach(e=>{
    const sh=e.sh, ci=sh.colIdx[e.col];
    if(!pathOf[sh.name]||!zip.file(pathOf[sh.name])){missed.push({e,why:'the sheet was not found in the file'});return}
    const rr=e.row.added?slot.get(e.row):e.row.r;
    if(e.row.added&&rr==null){missed.push({e,why:'there is no empty row for this new row above the Forms and Views section'});return}
    if(ci===undefined||rr==null||!sh.pos){missed.push({e,why:'the cell position is unknown'});return}
    (bySheet[sh.name]=bySheet[sh.name]||[]).push({e,row:rr+1+(sh.r0||0),col:sh.pos[ci],v:e.nw,sr:styleRow.get(e.row)});
  });
  // table details: written beside their label; a detail the sheet lacks goes in an empty row above the field list,
  // or, when there is none, in a row inserted just below the last detail (everything underneath moves down)
  const freeUsed=new Map(), needRow=new Map(), insertAt={};
  S.metaEd.forEach(me=>{
    const sh=me.sh, c0=sh.c0||0, e={sh,row:{vals:[],orig:[],r:null,key:'__meta'},col:me.k,nw:me.nw,meta:true};
    if(!pathOf[sh.name]||!zip.file(pathOf[sh.name])){missed.push({e,why:'the sheet was not found in the file'});return}
    const rs=Object.values(sh.metaR), ref=rs.length?Math.max(...rs):null;
    let r=sh.metaR[me.k.toLowerCase()], newRow=false;
    if(r==null){const used=freeUsed.get(sh)||[]; const free=(sh.metaFree||[]).filter(x=>!used.includes(x));
      if(!free.length){(needRow.get(sh)||needRow.set(sh,[]).get(sh)).push({me,e,ref}); return}
      r=free[0]; used.push(r); freeUsed.set(sh,used); newRow=true}
    const L=bySheet[sh.name]=bySheet[sh.name]||[];
    if(newRow) L.push({e:Object.assign({},e,{nw:me.k}),row:r,col:1+c0,v:me.k,sr:ref,sc:1+c0});
    L.push({e,row:r,col:2+c0,v:me.nw,sr:ref,sc:2+c0});
  });
  needRow.forEach((list,sh)=>{
    // below the last detail, or, with no details at all, above the hint and header rows
    const at=list[0].ref!=null?list[0].ref+1:(Object.keys(sh.hints||{}).length&&sh.hdrRow>1?sh.hdrRow-1:sh.hdrRow), L=bySheet[sh.name]=bySheet[sh.name]||[]; insertAt[sh.name]={at,K:list.length};
    list.forEach(({me,e,ref},i)=>{const r=at+i;
      L.push({e:Object.assign({},e,{nw:me.k}),row:r,col:1+(sh.c0||0),v:me.k,sr:ref,sc:1+(sh.c0||0),ins:true,lbl:true});
      L.push({e,row:r,col:2+(sh.c0||0),v:me.nw,sr:ref,sc:2+(sh.c0||0),ins:true})});
  });
  // a column added from the template gets its header (and hint) written with the first value saved in it,
  // styled like the sheet's last original column
  Object.keys(bySheet).forEach(name=>{
    const sh=S.sheets.find(x=>x.name===name); if(!sh||!sh.tmplAdded||!sh.tmplAdded.length) return;
    const lastPos=sh.pos[sh.cols.length-sh.tmplAdded.length-1], list=bySheet[name];
    const used=new Set(list.filter(ed=>sh.tmplAdded.includes(ed.e.col)).map(ed=>ed.e.col));
    list.forEach(ed=>{if(sh.tmplAdded.includes(ed.e.col)){ed.sc=lastPos; if(!ed.sr) ed.sr=ed.row}});
    used.forEach(c=>{const pos=sh.pos[sh.colIdx[c]], hrow={vals:[],orig:[],r:null,key:'header'};
      list.push({e:{sh,row:hrow,col:c,nw:c},row:sh.hdrRow,col:pos,v:c,sr:sh.hdrRow,sc:lastPos});
      if(sh.kind==='entity'&&sh.hints[c]&&sh.hdrRow>1) list.push({e:{sh,row:hrow,col:c,nw:sh.hints[c]},row:sh.hdrRow-1,col:pos,v:sh.hints[c],sr:sh.hdrRow-1,sc:lastPos});
    });
  });
  const esc2=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g,'').replace(/\r/g,'_x000D_');
  const colNum=a=>{let n=0;for(const ch of a.replace(/\d+/g,''))n=n*26+ch.charCodeAt(0)-64;return n};
  const moved=[];   // sheets with rows inserted: references to them elsewhere move too
  for(const name of Object.keys(bySheet)){
    const pth=pathOf[name]; let xml=await zip.file(pth).async('string');
    // the patcher understands plain sheet XML as Excel writes it. Anything else (for example namespace-prefixed
    // <x:row> tags from some generators) is refused rather than risk writing a broken file.
    if(xml.indexOf('<sheetData')<0||xml.indexOf('</sheetData>')<0){bySheet[name].forEach(ed=>missed.push({e:ed.e,why:'the sheet uses an XML layout this tool cannot safely edit'}));continue}
    if(insertAt[name]){const {at,K}=insertAt[name];
      const why=await insertRowsBlocked(zip,wbx,pathOf,name,xml);
      if(why){bySheet[name]=bySheet[name].filter(ed=>{if(ed.ins){if(!ed.lbl) missed.push({e:ed.e,why:'the table details have no empty row, and a row cannot be added because '+why}); return false} return true})}
      else{xml=shiftRows(xml,at,K); moved.push({name,at,K}); bySheet[name].forEach(ed=>{if(!ed.ins){if(ed.row>=at) ed.row+=K} if(ed.sr&&ed.sr>=at) ed.sr+=K})}
    }
    for(const ed of bySheet[name]){
      const addr=XLSX.utils.encode_cell({r:ed.row-1,c:ed.col-1});
      const rowRe=new RegExp('<row\\b[^>]*?\\br="'+ed.row+'"[^>]*?(\\/>|>)','');
      let rm=rowRe.exec(xml);
      if(!rm){ // row does not exist: insert in order
        let pos=xml.indexOf('</sheetData>'); const all=[...xml.matchAll(/<row\b[^>]*?\br="(\d+)"/g)];
        const nx=all.find(m=>+m[1]>ed.row); if(nx) pos=nx.index;
        xml=xml.slice(0,pos)+'<row r="'+ed.row+'"></row>'+xml.slice(pos); rm=rowRe.exec(xml)}
      let rs=rm.index, tag=rm[0];
      if(rm[1]==='/>'){ const nt=tag.slice(0,-2)+'></row>'; xml=xml.slice(0,rs)+nt+xml.slice(rs+tag.length); tag=nt.slice(0,nt.length-6) }
      const re=xml.indexOf('</row>',rs), body=xml.slice(rs+tag.length,re);
      const cellRe=new RegExp('<c\\b[^>]*?\\br="'+addr+'"[^>]*?(?:\\/>|>[\\s\\S]*?<\\/c>)');
      const cm=cellRe.exec(body); const old=cm?cm[0]:''; const sm=/\bs="(\d+)"/.exec(old.slice(0,old.indexOf('>')+1));
      let sa=sm?' s="'+sm[1]+'"':'';
      if(!sm&&ed.sr){const sAddr=XLSX.utils.encode_cell({r:ed.sr-1,c:(ed.sc||ed.col)-1}); const st=new RegExp('<c\\b[^>]*?\\br="'+sAddr+'"[^>]*?\\bs="(\\d+)"').exec(xml)||new RegExp('<c\\b[^>]*?\\bs="(\\d+)"[^>]*?\\br="'+sAddr+'"').exec(xml); if(st) sa=' s="'+st[1]+'"'}   /* a new cell borrows the look of a neighbouring one */ const wasNum=old&&!/\bt="/.test(old.slice(0,old.indexOf('>')+1))&&/<v>/.test(old);
      const v=ed.v.length>XL_MAX?cutText(ed.v):ed.v; let nc;   // Excel's limit for a cell
      if(v==='') nc='<c r="'+addr+'"'+sa+'/>';
      else if(wasNum&&/^-?\d+(\.\d+)?$/.test(v.trim())) nc='<c r="'+addr+'"'+sa+'><v>'+v.trim()+'</v></c>';
      else nc='<c r="'+addr+'"'+sa+' t="inlineStr"><is><t xml:space="preserve">'+esc2(v)+'</t></is></c>';
      let nb;
      if(cm) nb=body.slice(0,cm.index)+nc+body.slice(cm.index+old.length);
      else{ const cells=[...body.matchAll(/<c\b[^>]*?\br="([A-Z]+)\d+"/g)]; const nx=cells.find(m=>colNum(m[1])>ed.col); nb=nx?body.slice(0,nx.index)+nc+body.slice(nx.index):body+nc }
      xml=xml.slice(0,rs+tag.length)+nb+xml.slice(re); n++; placed.push({e:ed.e,sheet:name,addr});
    }
    zip.file(pth,xml);
  }
  await moveSheetRefs(zip,moved);
  const out=await zip.generateAsync({type:'uint8array',compression:'DEFLATE'});
  // read the result back and check that every edited cell now holds its new value
  try{
    const chk=XLSX.read(out,XLSX_OPTS);
    placed.forEach(p=>{const ws=chk.Sheets[p.sheet], c=ws&&ws[p.addr]; const got=clean(c?c.v:'');
      const want=clean(p.e.nw), num=typeof (c&&c.v)==='number'&&want!==''&&+want===c.v;
      if(got!==want&&!num) missed.push({e:p.e,why:'the new value did not read back from the saved file'})});
  }catch(err){placed.forEach(p=>missed.push({e:p.e,why:'the updated file could not be read back ('+err.message+')'}))}
  return {bytes:out,n,missed};
}
// Inserting rows into a sheet's XML. Moved with the rows: every row and cell below, the sheet's size, merged cells,
// drop-down lists, conditional formatting, filters, hyperlinks, page breaks, the frozen pane and the selection, and
// references to this sheet's cells in its own formulas, lists and rules; and (moveSheetRefs) named ranges, filters and
// print titles, other sheets' formulas and charts that point at it. Not attempted (the reason is returned) when something
// cannot be moved safely: an Excel table, drawings or comments on the sheet, or a pivot table reading from it.
async function insertRowsBlocked(zip,wbx,pathOf,name,xml){
  if(/<tableParts\b[^>]*count="[1-9]/.test(xml)||/<tablePart\b/.test(xml)) return 'the sheet holds an Excel table';
  if(/<(drawing|legacyDrawing|legacyDrawingHF)\b/.test(xml)) return 'the sheet holds drawings or comments';
  // named ranges, other sheets' formulas and charts that point at the sheet are moved with it (moveSheetRefs); a pivot
  // table's source is not, so a sheet a pivot table reads from is left alone
  const xa=s=>s.replace(/&/g,'&amp;').replace(/"/g,'&quot;');
  for(const f of Object.keys(zip.files).filter(f=>/^xl\/pivotCache\/pivotCacheDefinition\d*\.xml$/.test(f))){
    const px=await zip.file(f).async('string'); if(px.includes('sheet="'+xa(name)+'"')) return 'a pivot table reads from it'}
  return '';
}
// references to a sheet from anywhere ('Sheet name'!A10, Sheet!$A$10:$C$40, 'Sheet'!$10:$12) move down K rows from row
// "at": in named ranges, in every sheet's formulas, drop-down lists and rules, and in charts. Text in quotes is left alone.
function shiftSheetRefs(text,name,at,K){
  const rx=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  const quoted="'"+name.replace(/'/g,"''")+"'", bare=/^[A-Za-z_][A-Za-z0-9_.]*$/.test(name)?name:null;
  const re=new RegExp("(^|[^A-Za-z0-9_.'])("+rx(quoted)+(bare?'|'+rx(bare):'')+")!(\\$?[A-Z]{0,3}\\$?\\d*)(?::(\\$?[A-Z]{0,3}\\$?\\d*))?",'gi');
  const one=s=>s&&s.replace(/^(\$?[A-Z]{0,3}\$?)(\d+)$/i,(m,c,r)=>+r>=at?c+(+r+K):m);
  return text.split(/("[^"]*")/).map((part,i)=>i%2?part:part.replace(re,(m,pre,sh,a,b)=>pre+sh+'!'+one(a)+(b!=null?':'+one(b):''))).join('');
}
async function moveSheetRefs(zip,moved){
  if(!moved.length) return;
  const dec=s=>s.replace(/&apos;/g,"'").replace(/&quot;/g,'"');   // both may stand unescaped in element text
  const fix=s=>{moved.forEach(({name,at,K})=>{s=shiftSheetRefs(s,name,at,K)}); return s};
  const files=Object.keys(zip.files).filter(f=>f==='xl/workbook.xml'||/^xl\/(worksheets|charts)\/[^/]+\.xml$/.test(f));
  for(const f of files){
    const x=await zip.file(f).async('string');
    const y=x.replace(/<(definedName|f|formula|formula1|formula2|xm:f|c:f)\b([^>]*)>([^<]*)<\/\1>/g,(m,tg,a,v)=>{const d=dec(v); if(d.indexOf('!')<0) return m; const n=fix(d); return n===d?m:'<'+tg+a+'>'+n+'</'+tg+'>'});
    if(y!==x) zip.file(f,y);
  }
  // Excel's list of formula cells in calculation order names cells by address: drop it, and Excel rebuilds it on opening
  if(zip.file('xl/calcChain.xml')){
    zip.remove('xl/calcChain.xml');
    const ct=await zip.file('[Content_Types].xml').async('string'); zip.file('[Content_Types].xml',ct.replace(/<Override\b[^>]*PartName="\/xl\/calcChain\.xml"[^>]*\/>/,''));
    const rl=await zip.file('xl/_rels/workbook.xml.rels').async('string'); zip.file('xl/_rels/workbook.xml.rels',rl.replace(/<Relationship\b[^>]*Target="(?:\/xl\/)?calcChain\.xml"[^>]*\/>/,''));
  }
}
function shiftRows(xml,at,K){
  const state=tag=>/\bstate="(frozen|frozenSplit)"/.test(tag);   // a frozen pane's ySplit counts rows (a plain split is measured in points)
  const cell=t=>t.replace(/(\$?)([A-Z]{1,3})(\$?)(\d+)/g,(m,d1,c,d2,r)=>(+r>=at?d1+c+d2+(+r+K):m));
  // refs inside formulas: only this sheet's (no "Sheet!" before them), and not inside quoted text
  const fx=t=>t.split(/("[^"]*")/).map((part,i)=>i%2?part:part.replace(/(^|[^A-Za-z0-9_!'.$])(\$?)([A-Z]{1,3})(\$?)(\d+)(?![\d(A-Za-z_])/g,(m,pre,d1,c,d2,r)=>pre+(+r>=at?d1+c+d2+(+r+K):d1+c+d2+r))).join('');
  xml=xml.replace(/<row\b[^>]*>/g,tag=>tag.replace(/\br="(\d+)"/,(m,r)=>+r>=at?'r="'+(+r+K)+'"':m));
  xml=xml.replace(/<c\b[^>]*>/g,tag=>tag.replace(/\br="([A-Z]+)(\d+)"/,(m,c,r)=>+r>=at?'r="'+c+(+r+K)+'"':m));
  xml=xml.replace(/(<(?:dimension|mergeCell|hyperlink|autoFilter|conditionalFormatting|dataValidation|selection|pane|protectedRange|ignoredError|x14:conditionalFormatting|x14:dataValidation)\b[^>]*>)/g,tag=>tag.replace(/\b(ref|sqref|activeCell|topLeftCell)="([^"]*)"/g,(m,k,v)=>k+'="'+cell(v)+'"'));
  xml=xml.replace(/<pane\b[^>]*>/g,tag=>tag.replace(/\bySplit="(\d+(?:\.\d+)?)"/,(m,y)=>state(tag)&&+y>=at?'ySplit="'+(+y+K)+'"':m));
  xml=xml.replace(/<xm:sqref>([^<]*)<\/xm:sqref>/g,(m,v)=>'<xm:sqref>'+cell(v)+'</xm:sqref>');
  xml=xml.replace(/<(f|formula|formula1|formula2|xm:f)\b([^>]*)>([^<]*)<\/\1>/g,(m,t,a,v)=>'<'+t+a.replace(/\bref="([^"]*)"/,(mm,rv)=>'ref="'+cell(rv)+'"')+'>'+fx(v)+'</'+t+'>');
  xml=xml.replace(/<brk\b([^>]*)\bid="(\d+)"/g,(m,a,id)=>'<brk'+a+'id="'+(+id>=at?+id+K:id)+'"');
  return xml;
}
// tells the person which edits could not be written; nothing is saved or cleared while this list is not empty
function reportMissed(r,what){
  const items=r.missed.slice(0,12).map(m=>'<li><b>'+esc(m.e.sh.label)+'</b> · <span class="mono">'+esc(editLabel(m.e))+'</span> · '+esc(m.e.col)+' <span class="dim">('+esc(m.why)+')</span></li>').join('');
  return dlg({title:what+' was stopped',body:r.missed.length+' of your changes could not be written into '+esc(S.fileName)+', so nothing was saved and all your edits are kept.<ul style="margin:8px 0 0;padding-left:18px">'+items+(r.missed.length>12?'<li>… and '+(r.missed.length-12)+' more</li>':'')+'</ul><br>Use <b>Save &amp; share → Rebuilt in the current template</b> to export everything instead.',ok:'OK',cancel:null});
}
// the suggested name for a new copy: a version number in the name goes up by one (v1.2 -> v1.3), otherwise a suffix is added
function nextName(name,suffix){
  const base=String(name||'workbook').replace(/\.[^.]+$/,'');
  const m=base.match(/^(.*(?:^|[^a-z])v)(\d+(?:\.\d+)*)(.*)$/i)||base.match(/^(.*\D|)(\d+(?:\.\d+)+)(\D*)$/);
  if(m){const parts=m[2].split('.'); parts[parts.length-1]=String(+parts[parts.length-1]+1); return m[1]+parts.join('.')+m[3]+'.xlsx'}
  return base+suffix+'.xlsx';
}
// asks for the file name before a workbook is downloaded; resolves to the name (ending .xlsx) or null when cancelled
function nameDialog(def,what,ext='.xlsx'){
  const extRe=new RegExp(ext.replace('.','\\.')+'$','i');
  return new Promise(res=>{
    const m=document.createElement('div'); m.className='convmask'; m.setAttribute('role','dialog'); m.setAttribute('aria-modal','true'); m.setAttribute('aria-label','Name the file');
    m.innerHTML=`<div class="convbox dlgbox namebox"><h3>Name the file</h3><p class="dim" style="margin:4px 0 10px">${esc(what)}</p>
      <label class="solf"><span>File name</span><input data-k="name" value="${esc(def)}" spellcheck="false" autocomplete="off"><small id="nameerr"></small></label>
      <div class="convbtns"><button class="btn" data-n="0">Cancel</button><button class="btn primary" data-n="1">Download</button></div></div>`;
    const inp=m.querySelector('input');
    const done=ok=>{
      if(ok){let v=inp.value.replace(/[\\/:*?"<>|\u0000-\u001f]/g,'').trim(); if(!v.replace(extRe,'').trim()){m.querySelector('#nameerr').textContent='Give the file a name.';return} if(!extRe.test(v)) v+=ext; ok=v}
      document.removeEventListener('keydown',key,true); m.remove(); res(ok||null)};
    const key=e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();done(false)}else if(e.key==='Enter'){e.preventDefault();e.stopPropagation();done(true)}};
    m.addEventListener('click',e=>{const b=e.target.closest('[data-n]'); if(b) done(b.dataset.n==='1'); else if(e.target===m) done(false)});
    document.addEventListener('keydown',key,true); document.body.appendChild(m);
    inp.focus(); inp.setSelectionRange(0,inp.value.replace(extRe,'').length);   // the name is selected, ready to type over
  });
}
const XLSX_MIME='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
// Excel holds at most 32,767 characters in a cell (a long list of choice options can run past it). Longer text is cut to
// fit, with a note at its end, so the workbook can still be written; cutReport says which cells were cut.
const XL_MAX=32767;
const cutText=s=>{const note=' … [cut: Excel holds 32,767 characters in a cell; this had '+s.length.toLocaleString('en-GB')+']'; return s.slice(0,XL_MAX-note.length)+note};
function fitSheetJS(wb){const cut=[]; wb.SheetNames.forEach(n=>{const ws=wb.Sheets[n]; Object.keys(ws).forEach(k=>{const c=ws[k]; if(k[0]!=='!'&&c&&typeof c.v==='string'&&c.v.length>XL_MAX){c.v=cutText(c.v); c.t='s'; delete c.w; delete c.h; delete c.r; cut.push(n+'!'+k)}})}); return cut}
function fitExcelJS(wb){const cut=[]; wb.eachSheet(ws=>ws.eachRow(row=>row.eachCell(c=>{if(typeof c.value==='string'&&c.value.length>XL_MAX){c.value=cutText(c.value); cut.push(ws.name+'!'+c.address)}}))); return cut}
function cutReport(cut,what){
  if(!cut.length) return;
  const list=cut.slice(0,8).map(a=>'<li class="mono">'+esc(a)+'</li>').join('')+(cut.length>8?'<li>… and '+(cut.length-8)+' more</li>':'');
  dlg({title:'Some text was too long for Excel',body:what+': '+cut.length+' cell'+(cut.length===1?'':'s')+' held more than the 32,767 characters Excel allows in a cell, so '+(cut.length===1?'it was':'they were')+' shortened. The end of each says <span class="mono">[cut: …]</span> and how long it was.<ul style="margin:8px 0 0;padding-left:18px">'+list+'</ul>',ok:'OK',cancel:null});
}
// true while the page shows its built-in empty starter template rather than a workbook someone opened
const isStarter=()=>S.curB64===EMBEDDED_B64&&EMBEDDED_B64===TEMPLATE_B64;
// a copy of this page that opens straight onto this workbook (your edits written in) and cannot change it
async function exportReadOnly(){
  if(!PAGE_SRC) return toast('A read-only copy can only be made from the full version of the page');
  let u8;
  if(hasWrites()||addedRows().length){ const r=await buildOriginal(); if(!r) return; if(r.missed.length) return reportMissed(r,'The read-only copy'); u8=r.bytes }
  else u8=b64ToU8(S.curB64);
  const fn=await nameDialog(S.fileName.replace(/\.[^.]+$/,'')+' (read-only).html','Read-only copy: opens straight onto this workbook'+(hasWrites()||addedRows().length?', with your edits written in':'')+'. It can be searched, checked and diagrammed, but not edited.','.html'); if(!fn) return;
  const js=v=>JSON.stringify(v).replace(/<\//g,'<\\/');
  // the libraries and this code may be separate files (as web resources in Dataverse): a copy has them written in
  let body=PAGE_SRC.body;
  const srcs=[...body.matchAll(/<script src="([^"]+)"><\/script>/g)];
  for(const m of srcs){
    let code; try{const r=await fetch(new URL(m[1],location.href)); if(!r.ok) throw new Error(r.status); code=await r.text()}catch(e){return toast('Could not make the read-only copy: '+m[1].split('?')[0]+' could not be read')}
    body=body.replace(m[0],()=>'<script>'+code.replace(/<\/script/gi,'<\\/script')+'<\/script>');
  }
  const data='<script>\nconst DME_MODE = "readonly";\nconst EMBEDDED_B64 = '+js(u8ToB64(u8))+';\nconst TEMPLATE_B64 = '+js(TEMPLATE_B64)+';\nconst TEMPLATE_NAME = '+js(TEMPLATE_NAME)+';\nconst EMBEDDED_NAME = '+js(S.fileName)+';\nconst DME_BUILD = '+js(APP_BUILD)+';\n<\/script>';
  const i=body.indexOf('const DME_MODE = '); const a=body.lastIndexOf('<script>',i), b=body.indexOf('<\/script>',i)+9;
  if(i<0||a<0||b<9) return toast('Could not make the read-only copy from this page');
  body=body.slice(0,a)+data+body.slice(b);
  download(fn,new Blob(['<!DOCTYPE html>\n<html lang="'+PAGE_SRC.lang+'">'+PAGE_SRC.head+'<body>'+body+'</body></html>'],{type:'text/html'}));
  toast('Read-only copy saved as '+fn);
}
async function exportOriginal(){
  const r=await buildOriginal(); if(!r) return;
  if(r.missed.length) return reportMissed(r,'The download');
  const fn=await nameDialog(nextName(S.fileName,' (updated)'),'Updated copy of the workbook'); if(!fn) return;
  download(fn,new Blob([r.bytes],{type:XLSX_MIME}));
  toast('Updated '+r.n+' cell'+(r.n===1?'':'s')+' in '+fn);
}
async function saveToOriginal(){
  const h=S.handle; if(!h) return toast('Open the file with Workbook ▾ in Chrome or Edge to link it first');
  if(!hasWrites()) return toast('No changes to save');
  // Save saves: only the changed cells (and any rows added for new table details) change, and the file on disk is
  // checked below so another program's changes are never overwritten without asking
  try{
    let perm=await h.queryPermission({mode:'readwrite'}); if(perm!=='granted') perm=await h.requestPermission({mode:'readwrite'});
    if(perm!=='granted') return toast('Permission to write to the file was not given');
    const cur=await h.getFile(); const curB=u8ToB64(new Uint8Array(await cur.arrayBuffer()));
    if(curB!==S.curB64&&!await dlg({title:'The file changed on disk',body:'Another program saved this file since you opened it. Overwriting now will lose those changes.',ok:'Overwrite anyway',danger:true})) return;
    const r=await buildOriginal(); if(!r) return;
    if(r.missed.length) return reportMissed(r,'Saving');
    await writeSaved(h,r);
  }catch(err){
    console.error(err);
    // the linked file has gone (moved, renamed or deleted since it was opened), or the browser lost its link to it
    if(err&&/NotFound|NotReadable|InvalidState/.test(err.name||'')&&window.showSaveFilePicker){
      if(await dlg({title:'The original file could not be found',body:'<b>'+esc(S.fileName)+'</b> has been moved, renamed or deleted since it was opened, or the browser lost its link to it. Choose where to save the updated workbook, and the page links to that file from now on. Your edits are kept until it is saved.',ok:'Save as…'})) return saveAsNew();
      return;
    }
    toast('Could not write to the file ('+(err&&err.message||err)+'). Your edits are kept. Use Save as… to save a copy instead.')
  }
}
// save the updated workbook to a file you choose, and link the page to it
async function saveAsNew(){
  try{
    const r=await buildOriginal(); if(!r) return;
    if(r.missed.length) return reportMissed(r,'Saving');
    let h; try{h=await showSaveFilePicker({suggestedName:S.fileName,types:[{description:'Excel workbook',accept:{[XLSX_MIME]:['.xlsx']}}]})}catch(e){return}
    await writeSaved(h,r);
  }catch(err){console.error(err);toast('Could not write to the file ('+(err&&err.message||err)+'). Your edits are kept. Use Save as… to save a copy instead.')}
}
// write, read back, and only then let go of the edits that are now in the file
async function writeSaved(h,r){
  const w=await h.createWritable(); await w.write(new Blob([r.bytes],{type:XLSX_MIME})); await w.close();
  const back=new Uint8Array(await (await h.getFile()).arrayBuffer());
  const nb=u8ToB64(r.bytes), old=S.curB64;
  if(u8ToB64(back)!==nb){toast('The file on disk does not match what was written. Your edits are kept.');return}
  if(h!==S.handle){S.handle=h; const nm=h.name||S.fileName; if(nm!==S.fileName){S.fileName=nm}}
  const rec=S.lib.find(x=>x.b64===old); if(rec){rec.b64=nb;rec.size=r.bytes.length;if(rec.name!==S.fileName)rec.name=S.fileName;rec.handle=h;try{await idb.put(rec)}catch(e){}}
  try{await idb.put({id:'__cur',name:S.fileName,b64:nb,proj:S.proj,handle:h})}catch(e){}
  // the saved edits are now part of the file. Edits still waiting for a decision (Needs your attention) are kept.
  S.edits.clear(); S.metaEd.clear(); S.sheets.forEach(sh=>{sh.rows=sh.rows.filter(x=>!x.added)}); persist(); S.curB64=nb;
  init(XLSX.read(r.bytes,XLSX_OPTS),S.fileName,{});
  toast('Saved '+r.n+' change'+(r.n===1?'':'s')+' to '+S.fileName);
}
async function pickFile(){
  if(window.showOpenFilePicker){
    try{
      const [h]=await showOpenFilePicker({types:[{description:'Excel workbook',accept:{[XLSX_MIME]:['.xlsx'],'application/vnd.ms-excel.sheet.macroEnabled.12':['.xlsm'],'application/vnd.ms-excel':['.xls']}}],multiple:false});
      const f=await h.getFile(); loadFile(f,h); return;
    }catch(e){ if(e&&e.name==='AbortError') return }
  }
  $('#file').click();
}
function doExport(kind){
  const base=S.fileName.replace(/\.[^.]+$/,'');
  if(kind==='csv'){
    if(!S.view) return toast('Open a table view to export it as CSV');
    const v=S.view; const cols=visibleCols(v);
    const rows=[cols].concat(S.filtered.map(it=>cols.map(c=>cellVal(v,it,c))));
    download(base+' - '+v.label+'.csv',new Blob([csv(rows)],{type:'text/csv'}));
  } else if(kind==='csv-all'){
    if(!S.view) return toast('Open a table view to export it as CSV');
    const v=S.view; const cols=v.cols;
    const rows=[cols].concat(S.filtered.map(it=>cols.map(c=>cellVal(v,it,c))));
    download(base+' - '+v.label+' (all columns).csv',new Blob([csv(rows)],{type:'text/csv'}));
  } else if(kind==='log'){
    if(!S.edits.size) return toast('No changes to export');
    download(base+' - change log.csv',new Blob([csv(changeRows())],{type:'text/csv'}));
  } else if(kind==='save'){
    if(S.handle) saveToOriginal(); else if(window.showSaveFilePicker) saveAsNew(); else doExport('xlsx-orig');
  } else if(kind==='save-orig'){
    saveToOriginal();
  } else if(kind==='ro-xlsx'){
    download(EMBEDDED_NAME,new Blob([b64ToU8(S.curB64)],{type:XLSX_MIME})); toast('Downloaded '+EMBEDDED_NAME);
  } else if(kind==='ro-copy'){
    exportReadOnly().catch(err=>{console.error(err);toast('Could not make the read-only copy ('+err.message+')')});
  } else if(kind==='xlsx-orig'&&window.showSaveFilePicker){
    saveAsNew();
  } else if(kind==='xlsx-orig'){
    exportOriginal().catch(err=>{console.error(err);toast('Could not update the original ('+err.message+'). Use the template export instead.')});
  } else if(kind==='xlsx'){
    exportTemplated().catch(err=>{console.error(err);toast('Template export failed ('+err.message+') — exporting plain values instead');doExport('xlsx-plain')});
  } else if(kind==='xlsx-plain'){
    const wb=XLSX.utils.book_new();
    S.sheets.forEach(sh=>{
      const aoa=[];
      sh.meta.forEach(([k,v])=>aoa.push([k,v]));
      if(sh.meta.length) aoa.push([]);
      sh.notes.forEach(n=>aoa.push([n]));
      const hdrAt=aoa.length;
      aoa.push(sh.cols);
      sh.rows.forEach(r=>aoa.push(r.vals));
      const ws=XLSX.utils.aoa_to_sheet(aoa);
      ws['!cols']=sh.cols.map(c=>({wch:Math.min(60,Math.max(12,(WIDTHS[c]||160)/7))}));
      ws['!freeze']={xSplit:0,ySplit:hdrAt+1};
      ws['!autofilter']={ref:XLSX.utils.encode_range({s:{r:hdrAt,c:0},e:{r:aoa.length-1,c:sh.cols.length-1}})};
      XLSX.utils.book_append_sheet(wb,ws,sh.name.slice(0,31));
    });
    if(hasWrites()) XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet(changeRows()),'Change log');
    nameDialog(nextName(S.fileName,' (edited)'),'Values only, no formatting').then(fn=>{if(!fn) return; const cut=fitSheetJS(wb); XLSX.writeFile(wb,fn); toast('Exported '+fn+'. Values only: cell styling is not carried over'); cutReport(cut,fn)});
  } else if(kind==='solution'){
    solDialog();
  } else if(kind==='ps1'){
    download('import.ps1',new Blob([importScript().replace(/\r?\n/g,'\r\n')],{type:'text/plain'}));
    toast('import.ps1 downloaded. Put it next to the solution zip and run it in PowerShell.');
  } else if(kind==='manual'){
    exportManual().catch(err=>{console.error(err);toast('Could not create the list ('+err.message+')')});
  } else if(kind==='diff'){
    download(base+' - differences '+S.diff.pl+' to '+S.diff.cl+'.csv',new Blob([csv(diffRows())],{type:'text/csv'}));
  } else if(kind==='bundled'){
    dlg({title:'Go back to the bundled workbook?',body:'The loaded versions are forgotten. Your edits are kept.',ok:'Go back'}).then(ok=>{if(ok){store.set('dme.cur',null);store.set('dme.prev',null);Promise.all([idb.del('__cur'),idb.del('__prev')]).catch(()=>{}).then(()=>location.reload())}});
  } else if(kind==='reset'){
    if(!changeTotal()) return toast('Nothing to discard');
    dlg({title:'Discard all edits?',body:'All '+S.edits.size+' edit'+(S.edits.size===1?'':'s')+' will be reverted to the original values'+(addedRows().length?', and the '+addedRows().length+' row'+(addedRows().length===1?'':'s')+' you added removed':'')+'.',ok:'Discard edits',danger:true}).then(ok=>{if(ok)revertAll()});
  }
}
function revertAll(){
  if(RO) return; // read-only copy
  S.issues=null;
  [...S.edits.values()].forEach(e=>{const i=e.sh.colIdx[e.col];e.row.vals[i]=e.row.orig[i]});
  S.edits.clear(); S.pending=[];
  addedRows().forEach(({sh,row})=>removeRow(sh,row));
  [...S.metaEd.values()].forEach(e=>setMeta(e.sh,e.k,e.old,true)); S.metaEd.clear(); persist(); updateCounts(); applyAndRender(); if($('#changes').classList.contains('open')) renderChanges(); if(S.selIt) renderDetail();
}

/* ---------- navigation ---------- */
function renderReadme(){
  const main=$('#main');
  const sec=(n,title,body)=>`<h2 id="rd-${n}"><span class="n">${n}</span>${title}</h2>${body}`;
  main.innerHTML=`<div class="readme"><article class="rwrap">
  <h1>How it works <span class="dim" style="font-size:13px;font-weight:500">version ${esc(DME_VERSION)}</span></h1>
  <p class="lead">This page turns a multi-tab Excel data model document into something you can search, filter, check and edit, writes it back out in the same layout, and builds it in Dataverse as a solution, so tables, fields and relationships don't have to be created by hand. Everything runs inside this one file in your browser. Nothing is uploaded anywhere.</p>

  <div class="flow">
    <div class="step"><b>1. Read</b>Workbook is parsed tab by tab. Layout is detected, not hard-coded.</div><div class="arrow">→</div>
    <div class="step"><b>2. Review</b>Search, filter, expand, and edit cells or comments.</div><div class="arrow">→</div>
    <div class="step"><b>3. Update</b>Load a newer version. Differences are shown and your edits carry over.</div><div class="arrow">→</div>
    <div class="step"><b>4. Export</b>Data is written into the template, so formatting matches.</div><div class="arrow">→</div>
    <div class="step"><b>5. Build</b>Build solution creates the tables, fields and relationships, imported with one script.</div>
  </div>
  <nav class="toc" aria-label="Contents"></nav>

  ${sec(1,'Reading the workbook',`
  <p>When the file opens, each tab is read and classified:</p>
  <ul>
    <li><b>Table definition tabs</b> (one per Dataverse table) are recognised by a header row that starts <span class="mono">Logical Name</span>, <span class="mono">Schema Name</span>. Everything above that row is treated as table details (name, schema, ownership, audit and so on). One line above the header holds the hint text for each column.</li>
    <li><b>Other tabs</b>, such as the Table Dictionary, are read as plain tables. The first row with three or more filled cells is taken as the header.</li>
    <li><b>Extra columns</b> are never discarded. Any column found under the header is shown, filterable and exportable, even if the template doesn't have it. Columns not in the template carry a pink <span class="xtag">new</span> tag.</li>
    <li><b>Messy values</b> are tidied for display and comparison only (Excel line-break codes, stray spaces, True/False written in different ways, and variants such as <span class="mono">BusinessRequired</span> and <span class="mono">Business required</span> are grouped together in filters).</li>
  </ul>
  <p>The <b>Table Dictionary</b> also does a second job. Its <i>Area</i> column is matched to the table tabs by name, which is how the sidebar groups tables by area.</p>`)}

  ${sec(2,'Finding and reading things',`
  <div class="rgrid">
    <div class="rcard"><h3>Sidebar</h3>One entry per tab, with its row count. <b>All fields</b> combines every table into one list, which is the fastest way to answer questions like "which fields are on the RAF form?" Group headings expand and collapse, and the sidebar edge can be dragged to resize it. The tiles above each table count fields by attribute type.</div>
    <div class="rcard"><h3>Search</h3>The box at the top searches the current view across every column. Several words must all match. Matches are highlighted.</div>
    <div class="rcard"><h3>Filters</h3>Each column header has a filter button listing its distinct values with counts. The tiles under the title (custom, required, lookups, on RAF form, with comments) are one-click filters. Active filters show as removable chips.</div>
    <div class="rcard"><h3>Rows and columns</h3>Click a header to sort. <b>Columns</b> shows or hides columns. <b>Collapse all rows</b> clamps rows to two lines, and the arrow on each row opens just that one.</div>
    <div class="rcard"><h3>Row detail</h3>Click a row to open every field of that record. Lookup targets are links that jump to the target table. Use <kbd>j</kbd> / <kbd>k</kbd> to step through rows.</div>
  </div>`)}

  ${sec(3,'Editing and reviewing',`
  <ul>
    <li><b>Double-click</b> any cell to edit it, or click a value in the row detail panel. <kbd>Enter</kbd> saves, <kbd>Esc</kbd> cancels, and <kbd>Shift</kbd>+<kbd>Enter</kbd> adds a new line in long text.</li>
    <li>Columns that hold a fixed set of options (attribute type, required level, custom attribute and similar) edit as a <b>dropdown</b>. The options come from the template's validation lists plus any values found in the data, so a new value in a loaded workbook appears as an option automatically.</li>
    <li><b>＋ Add field</b> (on a table) adds a field, a lookup or an N:N relationship at the end of the field list: give it a display name and type, and the logical and schema names are suggested with your prefix. A lookup or N:N asks for the related table, and is marked N:1 or N:N. The new row opens on the right to fill in the rest. On other sheets, such as the Table Dictionary, <b>＋ Add row</b> adds a blank row. Added rows are tagged <b>ADDED</b>, are checked, drawn and built like any other row, and can be removed from their panel or from Changes.</li>
    <li>The <b>primary key</b> and <b>primary name</b> fields are tagged in the field list and shown in the table header. <b>Set as primary key</b> / <b>Set as primary name</b> on a field's panel records it, and <b>✎ Table details</b> edits every detail row of the table. Dataverse primary keys are always unique identifiers: to keep another field unique, use an alternate key.</li>
    <li>Downloading a new copy of the workbook asks for the file name first, suggesting the next version number.</li>
    <li>Columns the template has but the workbook lacks (for example Relationship Type in an older workbook) are <b>added</b> and marked, so you can fill them in. Their header is written into the file with the first value you save in them.</li>
    <li>Edited cells are highlighted. The original value is kept, so every edit can be reverted individually or all at once.</li>
    <li>The <b>Changes</b> panel lists every edit as original against new, with links to jump to the row, and exports the list as a CSV change log.</li>
    <li>Edits are <b>saved automatically in this browser</b>, so they survive closing the tab. Each edit is remembered against the table, the field's Logical Name and the column, along with the value it replaced. That is what makes the next section possible.</li>
  </ul>`)}

  ${sec(4,'Loading an updated version',`
  <p>Click <b>Workbook ▾ → Load a newer version of this workbook…</b> (or drag a file onto the page). The new file is read the same way, then compared with the one you had open:</p>
  <ul>
    <li><b>Matching:</b> tabs are matched by tab name (then logical name), and fields by <span class="mono">Logical Name</span>. Row order doesn't matter.</li>
    <li><b>What changed</b> lists new and removed tables, new and removed fields, every changed value as before and after, columns added or removed, changed table details (ownership, description, audit and so on), Forms and Views added or removed, and lookups that now point at a different table. In the grid, new fields are tagged NEW, changed cells are shaded (hover to see the old value), and a filter shows only changed rows.</li>
    <li>If you have edits open, you are asked whether the new file is a <b>newer version of the same data model</b> or a <b>different workbook</b>. Edits are only carried over to a newer version; a different workbook keeps its own edits, so two client models never mix.</li>
    <li><b>Your edits are re-applied</b> if the new version still has the original value you edited. If the new version changed that same value, or the field no longer exists, the edit is listed under <b>Needs your attention</b> with <i>Keep mine</i> / <i>Use new version</i>. Nothing is overwritten silently.</li>
    <li>The latest two versions are remembered in this browser, so reopening the page picks up where you left off, still comparing against the previous one.</li>
    <li><b>Metadata Document Generator exports</b> (an <span class="mono">Entities list</span> tab plus one tab per table) are detected automatically when loaded. They are converted to the template layout: a Table Dictionary (Custom or OOTB from <span class="mono">Is Custom Entity</span>, Area and Purpose left blank for you), then each table with its details and fields. The result opens under the export's own name; use <b>Save &amp; share</b> to save it. It is not linked to the original, so the generator file is never overwritten.</li>
  </ul>`)}

  ${sec(5,'Saving and the template',`
  <p>The <b>template</b> is your workbook with the data removed: the same tabs, label cells, header styling, column widths, filters and frozen headers, but no rows. It is built into this file, and <b>Check ▾ → Template</b> lets you download it, swap it for a different one, or see how the loaded file compares (new tables, extra columns, missing columns).</p>
  <table>
    <tr><th>Save &amp; share option</th><th>What you get</th></tr>
    <tr><td><b>Save</b> (<kbd>Ctrl</kbd>+<kbd>S</kbd>)</td><td>Writes your edits straight into your workbook, keeping its own formatting: only the changed cells change. The first time, if the page isn't linked to a file yet, it asks where to save (Chrome and Edge; other browsers download the workbook). If another program changed the file since you opened it, it asks before overwriting.</td></tr>
    <tr><td><b>Save as…</b></td><td>The same, into a new file you choose, which the page then saves to.</td></tr>
    <tr><td><b>Rebuilt in the current template</b></td><td>Every tab rebuilt with the template's formatting, including your edits. Extra columns get the template header style. New tables are styled like the template's table tabs. A Change log tab is added if you made edits.</td></tr>
    <tr><td>Values only, no formatting</td><td>Same data without template styling. Used as a fallback.</td></tr>
    <tr><td>This view as CSV</td><td>Exactly the rows and columns you currently see (after filters and sorting). Tick <b>include hidden columns</b> for the hidden ones too. Values that Excel would run as a formula are written as text.</td></tr>
    <tr><td>Change log / Version differences</td><td>CSVs of your edits, or of what changed between versions.</td></tr>
  </table>
  <p>Exported files can be loaded straight back in, which makes a round trip possible: <i>load, review and edit, export, reload</i>.</p>`)}

  ${sec(6,'ERD diagram',`
  <p>The side panel has the <b>Tables</b> to draw at the top (tick them, or use Custom only, All, None, Area ▾ and the filter box), <b>Show</b> (names only, keys and lookups, or all fields) at the bottom, and the rest folded under <b>Layout and options</b>. The eye at the end of each lookup or N:N row in a table box hides or shows that relationship. <b>Export ▾</b> above the diagram has draw.io, SVG, PNG and Mermaid.</p>
  <p>The <b>ERD</b> page draws an entity-relationship diagram from the lookup columns. It opens with the custom tables when there are 30 or fewer, otherwise with nothing selected so you can pick a readable set; you are asked before drawing more than 80 tables. Pick the tables and the detail level, and system tables such as users and teams are shown as light stubs. Tables are laid out automatically so related tables sit together. The diagram opens at the size of your screen, so a large model is readable straight away even where part of it runs past the panel: drag or scroll to move around, or click <b>Fit</b> to see all of it in the panel. If the Table Dictionary has areas, <b>Area ▾</b> picks one or more areas: the list narrows to them and their tables are drawn; <b>Colour by area</b> gives each area its own border colour (also in the draw.io file). Click the <b>★</b> next to one or more tables to make them <b>core tables</b>: they are placed in the middle, glow gold, and everything else is arranged around them by how closely it is linked. Each line has a small arrow pointing at the table being looked up. A line only shows relationship ends (one, many) when the relationship is recorded, for now by importing Dataverse metadata; otherwise it is a plain grey line, counted above the diagram and listed per table in Checks under <b>Relationship type not recorded</b> for review. Lines between the same two tables are merged into one (untick <b>Merge lines</b> to see them separately), and relationship names show when you hover a table (or choose Always / Hidden). Drag any table to move it (the lines follow) and drag the background to pan. Your arrangement is remembered in this browser for that selection of tables and options, and <b>Auto layout</b> discards it and lays the tables out again. Scroll the mouse wheel over the canvas to zoom in or out at the pointer, and drag empty space to move around. The <b>draw.io</b> button downloads the diagram, with your layout and the attributes currently shown, as a draw.io file to keep editing; re-exporting later does not keep edits made in draw.io. The diagram can be zoomed, copied as Mermaid source, or saved as .mmd, SVG or PNG from <b>Export ▾</b>; SVG and PNG use your arrangement.</p>`)}

  ${sec(7,'Overview and checks',`
  <p>The page opens on the <b>Overview</b>: how many tables, fields and lookups the model has, how complete the documentation is (fields and tables with a description, dictionary entries with an area and purpose), the least-described tables, a summary by area, and the latest changes and edits. Click a tile to jump to the detail.</p>
  <p><b>Checks</b> lists problems found in the model itself, and updates as you edit:</p>
  <ul>
    <li><b>Errors:</b> a table or field without a logical name, a field listed twice in one table, the same table on two tabs.</li>
    <li><b>Warnings:</b> fields without an attribute type; lookups with no targets; lookups to a table with your own prefix that has no tab (one finding per missing table); dictionary entries with no tab, and tabs missing from the dictionary.</li>
    <li><b>To build by hand:</b> calculated, rollup and formula fields of your own. Their definitions aren't in the workbook, so they can't go in a generated solution; <b>Save &amp; share → Calculated and rollup fields</b> lists them per table, with a column for the formula and a Created? column to track progress.</li>
    <li><b>Info:</b> lookups to standard or Microsoft tables that have no tab (user, team and similar system tables are left out entirely); logical names that are not lower-case letters, digits and underscores; custom fields without a publisher prefix; tables whose primary key field is not listed. In a full Dataverse export these are usually Microsoft's own and fine.</li>
    <li>For the solution build: a new table with no primary name column, or one that isn't in its field list or isn't single-line text (errors); a Relationship Type that isn't N:1 or N:N, or N:1 on a field that isn't a lookup; a Cascade Delete value that isn't recognised; an N:N row without exactly one other table; and a relationship name used twice.</li>
    <li>The empty starter template built into the page is not checked.</li>
  </ul>
  <p>Filter by severity, by kind of check, by area or with the search box, click a finding to go to the row, or export the list as CSV.</p>`)}

  ${sec(8,'Dataverse: checking and building',`
  <p><b>Inside Dynamics 365 or XrmToolBox</b>, <b>Check ▾ → This environment</b> reads the environment directly: load a solution as the model, or check this workbook against it for undocumented, not built and unmanaged changes.</p>
  <p>Opened as a file, <b>Check ▾ → Compare with a solution…</b> (also on the Overview) compares the workbook with a solution exported from Power Apps (Solutions, select it, Export): add the .zip, or drop it onto the page. Only your own tables are expected in the solution, and a table included as a shell is compared only on the columns added to it.</p>
  <ul>
    <li>Fields that don't exist in Dataverse, or custom Dataverse fields that aren't documented.</li>
    <li>Attribute types and required levels that differ (Business Required is ApplicationRequired in the metadata).</li>
    <li>Lookups whose Targets don't match Dataverse's relationships, in either direction.</li>
    <li>Each table page gains a <b>From Dataverse</b> section: primary key and name, every N:1, 1:N and N:N relationship with its cascade settings, and the alternate keys. The ERD can show the N:N relationships as dashed lines.</li>
  </ul>
  <p>What was read is kept in this browser with this workbook and its newer versions. Compare with another solution at any time, or remove it from the Dataverse panel.</p>
  <h3 style="margin:18px 0 6px;font-size:14px">Building a solution</h3>
  <p><b>Build solution</b> in the header turns the model into an unmanaged solution you import with the Power Platform CLI. Set the solution name, version and publisher (the prefix and choice value prefix are suggested from the workbook); the dialog shows what will be built and what won't. The download holds:</p>
  <ul>
    <li>the <b>solution</b>: every new table with your prefix (with its primary name column, primary key, ownership, notes and activities settings) and its fields; your new fields on existing tables, which are included as shells so nothing else about them changes; a relationship for every lookup and customer lookup; and every N:N row.</li>
    <li><b>import.ps1</b> (also on its own from <b>Save &amp; share → Import script</b>, for a solution zip you already have): checks for pac and installs it if needed, signs you in through the browser, and imports the solution. Run <span class="mono">.\import.ps1 -EnvironmentUrl https://yourorg.crm11.dynamics.com</span>, into a development environment first.</li>
    <li><b>build-report.csv</b>: every table, field and relationship, and whether it is included, left out (and why), or to build by hand.</li>
    <li>the <b>hand-build list</b> of calculated and rollup fields.</li>
  </ul>
  <p>What the workbook needs: a <b>Primary Name Column</b> (and <b>Primary Key</b>) row in each new table's details; and on the field list, <b>Relationship Type</b> (N:1 on a lookup, N:N on a row describing a many-to-many relationship, with the other table in <span class="mono">Targets:</span>), an optional <b>Relationship Name</b> (generated if blank) and <b>Cascade Delete</b> (Remove Link, Restrict or Cascade; Remove Link if blank). Converted Metadata Document Generator exports fill in the table details automatically.</p>
  <p>Not built, and listed in the report instead: calculated and rollup fields, activity tables, lookups to several tables, image and file fields, and choice fields with no options. Fields Dataverse creates itself (name and helper fields, currency base fields, primary keys) are skipped.</p>`)}

  ${sec(9,'Your workbooks',`
  <p><b>Workbook ▾</b> switches between the workbooks kept in this browser, and <b>Manage files…</b> in it lists every one, with the one in use marked. Open, compare against, download or remove any of them. Files opened through the picker show a <i>Linked to file</i> tag. Removing one only forgets it here and never touches the file on your computer.</p>`)}

  ${sec(10,'Keyboard shortcuts',`
  <table>
    <tr><td><kbd>/</kbd></td><td>Jump to search</td></tr>
    <tr><td><kbd>j</kbd> <kbd>k</kbd></td><td>Next / previous row while the detail panel is open</td></tr>
    <tr><td><kbd>Enter</kbd> / <kbd>Esc</kbd></td><td>Save / cancel a cell edit</td></tr>
    <tr><td><kbd>Esc</kbd></td><td>Close panels and menus</td></tr>
  </table>`)}

  ${sec(11,'Where your data lives',`
  <ul>
    <li>The workbook, the template and the viewer code are all inside this one HTML file. It works offline.</li>
    <li>Your edits and column choices are kept in this browser's local storage, and the workbooks you load (including the last two versions) in its IndexedDB. Edits are kept separately for each workbook. Everything stays on this device, is not synced, and is lost if you clear site data or open the page in a different browser.</li>
    <li>The <b>kept in browser</b> label beside Changes shows that your edits are safely stored. If it turns red and says <b>not saved: export now</b>, the browser refused to store them: export the change log or the workbook before closing the page.</li>
    <li><b>Export the change log or the workbook regularly.</b> That is your real backup.</li>
  </ul>`)}

  ${sec(12,'Limits worth knowing',`
  <ul>
    <li>Only Excel files (.xlsx / .xlsm) can be loaded. Saving back to the original needs an .xlsx and a Chromium browser; elsewhere use the download.</li>
    <li>Saving to the original changes only the cells you edited. Everything else in the file, including Excel's stored line breaks, formatting and validations, is left exactly as it was.</li>
    <li>If a field is <b>renamed</b> in a new version it appears as one removed field and one new field, because fields are matched on Logical Name.</li>
    <li>The <b>Forms</b> and <b>Views</b> lists at the bottom of each table tab are read separately from the fields. They are shown below the grid and exported, but are read-only and not part of search or filters. Version comparison lists forms and views added or removed.</li>
    <li>The <b>template export</b> and the plain-values export write values as text, do not recreate Excel Table objects, comments, validations or macros, and take cell styling from the template rather than the loaded file. <b>Save</b> and <b>Save as…</b> do not have these limits: they leave everything except your edited cells exactly as it was.</li>
    <li>If the template export fails for any reason, the tool falls back to the plain-values export and tells you.</li>
  </ul>
  <div class="note2"><b>Tip:</b> <b>Check ▾ → Template</b> shows how many tables differ from the template. It is a quick check that a new workbook really is in the expected layout before you export.</div>`)}
  </article></div>`;
  // contents, from the section headings
  main.querySelector('.toc').innerHTML=[...main.querySelectorAll('.rwrap h2[id]')].map(h=>`<a href="#" data-rjump="${h.id.slice(3)}">${h.id.slice(3)}. ${esc(h.lastChild.textContent.trim())}</a>`).join('');
  main.querySelector('.toc').addEventListener('click',e=>{const a=e.target.closest('[data-rjump]'); if(!a) return; e.preventDefault(); const h=main.querySelector('#rd-'+a.dataset.rjump); if(h) h.scrollIntoView({behavior:'smooth',block:'start'})});
}

/* ---------- data-model checks ---------- */
const SEV={error:{label:'Error',plural:'Errors',cls:'sev-err',rank:0},warn:{label:'Warning',plural:'Warnings',cls:'sev-warn',rank:1},info:{label:'Info',plural:'Info',cls:'sev-info',rank:2}};
// rule id -> [severity, short name shown in the Checks list]
const RULES={
  'table-no-ln':['error','Table without a logical name'],
  'table-dup':['error','Same table on more than one tab'],
  'field-no-ln':['error','Field without a logical name'],
  'field-dup':['error','Duplicate field'],
  'ln-format':['info','Logical name format'],
  'type-missing':['warn','No attribute type'],
  'custom-prefix':['info','Custom field without a publisher prefix'],
  'system-twin':['warn','Copy of a system field'],
  'prefix-unknown':['info','Prefix not one of yours'],
  'lookup-no-target':['warn','Lookup without targets'],
  'lookup-unknown':['warn','Lookup to a table not in the workbook'],
  'dict-unlinked':['warn','Dictionary entry with no table tab'],
  'tab-not-in-dict':['warn','Table missing from the dictionary'],
  'pk-missing':['info','No primary key field listed'],
  'dv-table-missing':['warn','Table not in the Dataverse metadata'],
  'dv-field-missing':['error','Field not in Dataverse'],
  'dv-rel-extra':['error','Relationship not in Dataverse'],
  'dv-type':['warn','Attribute type differs from Dataverse'],
  'dv-required':['warn','Required level differs from Dataverse'],
  'dv-rel-missing':['warn','Dataverse relationship not documented'],
  'dv-field-undocumented':['warn','Custom Dataverse field not documented'],
  'dv-table-undocumented':['warn','Table in the solution but not documented'],
  'dv-nn-undocumented':['warn','Dataverse N:N relationship not documented'],
  'dv-unmanaged':['warn','Created directly in a managed environment'],
  'dv-active-layer':['warn','Changed directly in a managed environment'],
  'dv-custom':['info','Custom flag differs from Dataverse'],
  'dv-ownership':['info','Ownership differs from Dataverse'],
  'dv-std-undocumented':['info','Standard Dataverse fields not listed'],
  'manual-build':['info','Calculated or rollup field to create by hand'],
  'rel-review':['info','Relationship type not recorded'],
  'pname-missing':['error','No primary name column'],
  'pk-type':['error','Primary key is not a unique identifier'],
  'pname-notfound':['error','Primary name column not in the field list'],
  'pname-type':['error','Primary name column is not single-line text'],
  'rel-type-bad':['warn','Relationship type not valid here'],
  'cascade-bad':['warn','Cascade Delete not recognised'],
  'nn-target':['warn','N:N relationship with an unknown table'],
  'rel-name-dup':['error','Relationship name used twice']
};
const isLookupType=t=>/lookup|customer|owner/i.test(t||'');
// workbook wording ("Whole Number", "Two Options") and Dataverse AttributeType ("Integer", "Boolean") put in the same buckets
function typeClass(t){
  const l=String(t||'').toLowerCase().replace(/[^a-z]/g,''); if(!l) return '';
  if(/lookup|customer|owner|regarding/.test(l)) return 'lookup';
  if(/uniqueidentifier|^guid/.test(l)) return 'id';
  if(/multiselect|multichoice/.test(l)) return 'multichoice';
  if(/picklist|choice|optionset|^state$|^status|statusreason/.test(l)) return 'choice';
  if(/twooptions|boolean|yesno/.test(l)) return 'bool';
  if(/date/.test(l)) return 'date';
  if(/money|currency/.test(l)) return 'money';
  if(/decimal|double|float/.test(l)) return 'decimal';
  if(/integer|wholenumber|bigint|^int/.test(l)) return 'int';
  if(/string|memo|text|multipleline|singleline|email|phone|url|ticker/.test(l)) return 'text';
  return ''; // Virtual, EntityName, PartyList, images and files: not compared
}
// "Business Required" in the maker portal is ApplicationRequired in the metadata
function reqClass(v){
  const k=String(v||'').toLowerCase().replace(/[^a-z]/g,'');
  if(k==='systemrequired') return 'system';
  if(k==='applicationrequired'||k==='businessrequired') return 'business';
  if(k==='recommended'||k==='businessrecommended') return 'recommended';
  if(k==='none'||k==='optional') return 'none';
  return '';
}
// your own publisher prefixes: those of the custom tables in the workbook, leaving out Microsoft's (ms…, adx)
// a lookup's relationship is only "known" when something records it: today, imported Dataverse metadata
// (an N:1 from this field to that table). Unknown ones are drawn as plain lines and flagged for review.
function relKnown(sh,row,target){if(relTypeOf(sh,row)==='N:1') return true; const ln=getVal(sh,row,'Logical Name').trim(); const de=S.dv&&sh&&S.dv.ents[sh.logical];return !!(de&&de.m1.some(r=>r.attr===String(ln).toLowerCase()&&(r.target===target||(r.target==='owner'&&(target==='systemuser'||target==='team')))))}
/* ---------- publishers and prefixes ---------- */
// Your publishers (prefix, unique name, display name, choice value prefix), and the prefixes that are Microsoft's or
// another vendor's (out of the box). Kept in this browser for every workbook. An entry ending in * matches any prefix
// starting with it (ms* covers msdyn, mspp, msdynce…). With no publishers saved, yours are guessed from the custom tables.
const MS_PREFIXES_DEFAULT=['ms*','adx'];
const myPubs=()=>{const v=store.get('dme.pubs'); return Array.isArray(v)?v.filter(p=>p&&/^[a-z][a-z0-9]{1,7}$/.test(p.prefix)):[]};
const msPrefixes=()=>{const v=store.get('dme.msprefixes'); return Array.isArray(v)?v:MS_PREFIXES_DEFAULT};
function isMsPrefix(p){p=String(p||'').toLowerCase(); return msPrefixes().some(x=>{x=String(x).trim().toLowerCase(); return x.endsWith('*')?!!x.slice(0,-1)&&p.startsWith(x.slice(0,-1)):p===x})}
const prefixOf=ln=>{const m=/^([a-z][a-z0-9]{1,7})_/.exec(String(ln||'').trim().toLowerCase()); return m?m[1]:''};
function guessedPrefixes(ents){return new Set((ents||S.sheets.filter(s=>s.kind==='entity')).filter(s=>s.custom&&s.logical.includes('_')).map(s=>s.logical.split('_')[0]).filter(p=>!isMsPrefix(p)))}
function ownPrefixes(ents){const p=myPubs(); return p.length?new Set(p.map(x=>x.prefix)):guessedPrefixes(ents)}
// every prefix used in the workbook's logical names, with how many tables and fields use it
function prefixUse(){
  const m=new Map(), add=(p,k)=>{if(!p) return; const o=m.get(p)||{p,tables:0,fields:0}; o[k]++; m.set(p,o)};
  S.sheets.filter(s=>s.kind==='entity').forEach(sh=>{add(prefixOf(sh.logical),'tables'); sh.rows.forEach(r=>add(prefixOf(getVal(sh,r,'Logical Name')),'fields'))});
  return [...m.values()].sort((a,b)=>b.fields+b.tables-a.fields-a.tables);
}
function pubsDialog(after){
  if(RO) return;
  const use=prefixUse(), mine=myPubs(), known=new Set(mine.map(p=>p.prefix));
  const rows=mine.length?mine:[...guessedPrefixes()].map(p=>({prefix:p,pubName:p,pubDisplay:p.toUpperCase(),optPrefix:''}));
  const m=document.createElement('div'); m.className='convmask'; m.setAttribute('role','dialog'); m.setAttribute('aria-modal','true'); m.setAttribute('aria-label','Publishers and prefixes');
  const row=p=>`<div class="pubrow"><input data-pk="prefix" value="${esc(p.prefix||'')}" placeholder="prefix" spellcheck="false" autocomplete="off"><input data-pk="pubName" value="${esc(p.pubName||'')}" placeholder="publisher unique name" spellcheck="false" autocomplete="off"><input data-pk="pubDisplay" value="${esc(p.pubDisplay||'')}" placeholder="display name" autocomplete="off"><input data-pk="optPrefix" value="${esc(p.optPrefix||'')}" placeholder="10000-99999" inputmode="numeric" autocomplete="off"><button class="btn ghost" data-pubdel title="Remove">✕</button></div>`;
  const other=use.filter(u=>!known.has(u.p)&&!isMsPrefix(u.p));
  m.innerHTML=`<div class="convbox solbox" style="max-width:760px"><h3>Publishers and prefixes</h3><p class="dim" style="margin:4px 0 12px">Your customisation prefixes, and the publisher each one belongs to. They decide what counts as yours in Checks, the prefix new fields get, and the publisher <b>Build solution</b> fills in. Kept in this browser for every workbook.</p>
    <div class="pubhead"><span>Prefix</span><span>Publisher unique name</span><span>Display name</span><span>Choice value prefix</span><span></span></div>
    <div id="pubrows">${rows.map(row).join('')}</div>
    <div style="margin:6px 0 4px"><button class="btn" data-pubadd>＋ Add a publisher</button></div>
    ${other.length?`<div class="dim" style="font-size:12.5px;margin:8px 0 0">Also used in this workbook: ${other.slice(0,12).map(u=>`<button class="chipbtn" data-pubuse="${esc(u.p)}" title="${u.tables} table${u.tables===1?'':'s'}, ${u.fields} field${u.fields===1?'':'s'}. Click to add it as yours.">${esc(u.p)}_ <span>${u.tables+u.fields}</span></button>`).join(' ')}</div>`:''}
    <label class="solf" style="margin-top:14px"><span>Microsoft and other vendors' prefixes (treated as out of the box)</span><input data-msp value="${esc(msPrefixes().join(', '))}" spellcheck="false" autocomplete="off"><small>Separated by commas. An entry ending in * matches every prefix starting with it: ms* covers msdyn, mspp, msdynce and the rest. Add others you use, such as a partner's.</small></label>
    <div class="solerr" id="puberr"></div>
    <div class="convbtns"><button class="btn ghost" data-pubreset style="margin-right:auto" title="Forget the saved publishers and go back to guessing from the workbook">Reset</button><button class="btn" data-pubx="cancel">Cancel</button> <button class="btn primary" data-pubx="save">Save</button></div></div>`;
  document.body.appendChild(m);
  const list=m.querySelector('#pubrows');
  const read=()=>{const out=[],err=[],seen=new Set();
    list.querySelectorAll('.pubrow').forEach(r=>{const o={}; r.querySelectorAll('[data-pk]').forEach(i=>o[i.dataset.pk]=i.value.trim()); o.prefix=o.prefix.toLowerCase().replace(/_+$/,'');
      if(!o.prefix&&!o.pubName&&!o.pubDisplay&&!o.optPrefix) return;
      if(!/^[a-z][a-z0-9]{1,7}$/.test(o.prefix)) err.push('"'+(o.prefix||'(blank)')+'": a prefix is 2 to 8 lower-case letters or digits, starting with a letter.');
      else if(seen.has(o.prefix)) err.push('"'+o.prefix+'" is listed twice.');
      else if(isMsPrefix(o.prefix)) err.push('"'+o.prefix+'" matches a Microsoft prefix below.');
      if(o.pubName&&!/^[A-Za-z_][A-Za-z0-9_]{0,63}$/.test(o.pubName)) err.push('"'+o.pubName+'": a publisher unique name is letters, digits and underscores.');
      if(o.optPrefix&&!(Number.isInteger(+o.optPrefix)&&+o.optPrefix>=10000&&+o.optPrefix<=99999)) err.push('"'+o.optPrefix+'": a choice value prefix is a whole number from 10000 to 99999.');
      seen.add(o.prefix); out.push({prefix:o.prefix,pubName:o.pubName||o.prefix,pubDisplay:o.pubDisplay||o.prefix.toUpperCase(),optPrefix:o.optPrefix?+o.optPrefix:''})});
    const ms=m.querySelector('[data-msp]').value.split(/[\s,;]+/).map(x=>x.trim().toLowerCase().replace(/_$/,'')).filter(Boolean);
    if(ms.some(x=>!/^[a-z][a-z0-9]*\*?$/.test(x))) err.push('Microsoft prefixes: letters and digits, optionally ending in *.');
    m.querySelector('#puberr').innerHTML=err.map(x=>`<div>${esc(x)}</div>`).join(''); return err.length?null:{pubs:out,ms}};
  const close=()=>{document.removeEventListener('keydown',key,true);m.remove()};
  const save=()=>{const v=read(); if(!v) return; store.set('dme.pubs',v.pubs); store.set('dme.msprefixes',v.ms); S.issues=null; close(); updateCounts(); refreshSpecial(true); toast(v.pubs.length?'Saved '+v.pubs.length+' publisher'+(v.pubs.length===1?'':'s')+': '+v.pubs.map(p=>p.prefix+'_').join(', '):'Saved. With no publishers, your prefixes are guessed from the custom tables.'); if(after) after()};
  const key=e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();close()}else if(e.key==='Enter'&&e.target.tagName==='INPUT'){e.preventDefault();e.stopPropagation();save()}};
  document.addEventListener('keydown',key,true);
  m.addEventListener('click',e=>{
    if(e.target===m) return close();
    const t=e.target.closest('button'); if(!t) return;
    if(t.dataset.pubx==='cancel') close(); else if(t.dataset.pubx==='save') save();
    else if(t.hasAttribute('data-pubadd')){list.insertAdjacentHTML('beforeend',row({})); list.lastElementChild.querySelector('input').focus()}
    else if(t.hasAttribute('data-pubdel')) t.closest('.pubrow').remove();
    else if(t.dataset.pubuse){const p=t.dataset.pubuse; list.insertAdjacentHTML('beforeend',row({prefix:p,pubName:p,pubDisplay:p.toUpperCase()})); t.remove()}
    else if(t.hasAttribute('data-pubreset')){store.del?store.del('dme.pubs'):store.set('dme.pubs',[]); store.set('dme.msprefixes',MS_PREFIXES_DEFAULT); S.issues=null; close(); updateCounts(); refreshSpecial(true); toast('Publishers reset: your prefixes are guessed from the custom tables again'); if(after) after()}
  });
  const first=list.querySelector('input'); if(first) first.focus();
}
// calculated, rollup and formula fields can't go in a generated solution (their definitions aren't in the workbook),
// so they are listed to be created by hand after import. Only your own fields: Microsoft's come with their solutions.
const MANUAL_RE=/calculated|rollup|formula/i;
// columns Dataverse creates on every table. A field named prefix_createdon would be a second, custom copy of one of them.
const SYSTEM_COLS=new Set(['createdon','createdby','createdonbehalfby','modifiedon','modifiedby','modifiedonbehalfby','ownerid','owneridtype','owninguser','owningteam','owningbusinessunit','statecode','statuscode','versionnumber','importsequencenumber','overriddencreatedon','timezoneruleversionnumber','utcconversiontimezonecode','transactioncurrencyid','exchangerate','processid','stageid','traversedpath']);
const systemTwin=ln=>{const p=prefixOf(ln); return p&&!isMsPrefix(p)&&SYSTEM_COLS.has(String(ln).toLowerCase().slice(p.length+1))?String(ln).toLowerCase().slice(p.length+1):''};
function manualFields(){
  const ents=S.sheets.filter(s=>s.kind==='entity'), own=ownPrefixes(ents), out=[];
  const mine=ln=>own.size?(ln.includes('_')&&own.has(ln.split('_')[0])):true;
  ents.forEach(sh=>{ if(sh.colIdx['Type']===undefined) return;
    sh.rows.forEach(row=>{const k=getVal(sh,row,'Type'), ln=getVal(sh,row,'Logical Name').trim();
      if(!ln||!MANUAL_RE.test(k)) return;
      const cust=sh.colIdx['Custom Attribute']===undefined||facet('Custom Attribute',getVal(sh,row,'Custom Attribute'))==='True';
      if(cust&&mine(ln.toLowerCase())) out.push({sh,row,ln,kind:/rollup/i.test(k)?'Rollup':/formula/i.test(k)?'Formula':'Calculated'})})});
  return out;
}
function issues(){
  if(S.issues) return S.issues;
  if(isStarter()) return S.issues=[];   // the built-in starter template is not a data model to check
  const out=[]; const add=(rule,sh,row,field,msg,sev,where)=>out.push({rule,sev:sev||RULES[rule][0],sh,row:row||null,field:field||'',msg,where:where||''});
  const missing={};   // lookup target -> the fields that point at it
  const own=ownPrefixes();
  const ents=S.sheets.filter(s=>s.kind==='entity');
  const byLog={};
  ents.forEach(sh=>{if(!sh.logical) add('table-no-ln',sh,null,'','This tab has no Logical Name in its table details.'); else (byLog[sh.logical]=byLog[sh.logical]||[]).push(sh)});
  Object.values(byLog).forEach(a=>{if(a.length>1) a.forEach(sh=>add('table-dup',sh,null,'','"'+sh.logical+'" is also documented on '+a.filter(x=>x!==sh).map(x=>x.name).join(', ')+'.'))});
  const LN=/^[a-z][a-z0-9_]*$/, relNames={};
  ents.forEach(sh=>{
    if(sh.colIdx['Logical Name']===undefined) return;
    const seen={};
    sh.rows.forEach(row=>{
      const ln=getVal(sh,row,'Logical Name').trim(), at=getVal(sh,row,'Attribute Type');
      if(isSubgridRow(sh,row)) return;   // a form sub-grid, not a column
      if(!ln){add('field-no-ln',sh,row,getVal(sh,row,'Display Name')||rowNo(row),'This field has no Logical Name.');return}
      // relationship columns
      const rt=relTypeOf(sh,row), rawRt=getVal(sh,row,'Relationship Type').trim();
      if(rt==='N:N'){ // a many-to-many row: not a field
        const tg=lookupTargetsOf(sh,row), nm=ln.toLowerCase(); (relNames[nm]=relNames[nm]||[]).push(sh);
        if(tg.length!==1) add('nn-target',sh,row,ln,'An N:N row needs exactly one table in "Targets:" in Additional data; it has '+tg.length+'.','error');
        else if(S.byLogical[tg[0]]===undefined&&!SYS_TABLES.has(tg[0])) add('nn-target',sh,row,ln,'Its other table, "'+tg[0]+'", has no tab in this workbook.','info');
        return;
      }
      if(rt==='?') add('rel-type-bad',sh,row,ln,'"'+rawRt+'" is not a relationship type. Use N:1 on a lookup, or N:N on a row that describes a many-to-many relationship.');
      else if(rt==='N:1'&&!isLookupType(at)) add('rel-type-bad',sh,row,ln,'N:1 is set on a field that is not a lookup.');
      if(getVal(sh,row,'Cascade Delete').trim()&&!cascadeOf(sh,row)) add('cascade-bad',sh,row,ln,'"'+getVal(sh,row,'Cascade Delete').trim()+'" is not a cascade setting. Use Remove Link, Restrict or Cascade.');
      {const rn=getVal(sh,row,'Relationship Name').trim().toLowerCase(); if(rn) (relNames[rn]=relNames[rn]||[]).push(sh)}
      const k=ln.toLowerCase(); (seen[k]=seen[k]||[]).push(row);
      if(!LN.test(ln)) add('ln-format',sh,row,ln,'Dataverse logical names are lower-case letters, digits and underscores, starting with a letter.');
      if(sh.colIdx['Attribute Type']!==undefined&&!at) add('type-missing',sh,row,ln,'No attribute type is recorded.');
      {const twin=systemTwin(ln); if(twin) add('system-twin',sh,row,ln,'Dataverse creates '+twin+' on every table. "'+ln+'" would be a second, custom copy, so it is left out of a generated solution. Use '+twin+' (and remove this row), unless you really need a separate field.')}
      if(facet('Custom Attribute',getVal(sh,row,'Custom Attribute'))==='True'&&!ln.includes('_')) add('custom-prefix',sh,row,ln,'Custom fields normally start with the publisher prefix, such as new_ or fp_.');
      else if(myPubs().length&&facet('Custom Attribute',getVal(sh,row,'Custom Attribute'))==='True'){const px=prefixOf(ln); if(px&&!isMsPrefix(px)&&!ownPrefixes().has(px)) add('prefix-unknown',sh,row,ln,'"'+px+'_" is not one of your prefixes or a Microsoft one. Add it in Publishers and prefixes if it is yours, or check the name.')}
      if(isLookupType(at)){
        const tg=lookupTargetsOf(sh,row);
        if(!tg.length) add('lookup-no-target',sh,row,ln,'The lookup has no "Targets:" in Additional data, so its relationship is unknown.');
        tg.forEach(t=>{if(S.byLogical[t]===undefined&&!SYS_TABLES.has(t)){const m=missing[t]||(missing[t]={sh,row,fields:[],tables:new Set()}); m.fields.push(sh.label+'.'+ln); m.tables.add(sh.idx)}});
      }
    });
    Object.entries(seen).forEach(([k,rows])=>{if(rows.length>1) rows.forEach(row=>add('field-dup',sh,row,k,'"'+k+'" is listed '+rows.length+' times in this table.'))});
    const de=S.dv&&S.dv.ents[sh.logical], pk=sh.mo['primary key']?pkOf(sh):de&&de.pid?de.pid:sh.logical+'id';
    // a table that will be created needs a single-line text primary name column
    if(sh.logical&&own.has(sh.logical.split('_')[0])&&sh.logical.includes('_')){
      const pn=pnameOf(sh), prow=pn&&sh.rows.find(r=>getVal(sh,r,'Logical Name').trim().toLowerCase()===pn);
      if(!pn) add('pname-missing',sh,null,'','No Primary Name Column in the table details. Dataverse cannot create the table without one.');
      else if(!prow) add('pname-notfound',sh,null,pn,'The primary name column "'+pn+'" is not in the field list.');
      else if(!/^(text|string|single ?line)/i.test(getVal(sh,prow,'Attribute Type').trim())) add('pname-type',sh,prow,pn,'The primary name column must be single-line text; it is "'+getVal(sh,prow,'Attribute Type')+'".');
    }
    if(sh.rows.length&&sh.logical&&!seen[pk]) add('pk-missing',sh,null,'','The primary key field ('+pk+') is not listed.');
    {const krow=sh.mo['primary key']&&sh.rows.find(r=>getVal(sh,r,'Logical Name').trim().toLowerCase()===pkOf(sh)), kt=krow&&getVal(sh,krow,'Attribute Type').trim();
      if(kt&&!isGuidType(kt)) add('pk-type',sh,krow,pkOf(sh),'Dataverse primary keys are always unique identifiers (GUIDs), created with the table; "'+pkOf(sh)+'" is '+kt+'. To keep its values unique, give the table an alternate key on it instead, and leave Primary Key as the table name followed by id.',sh.logical&&own.has(sh.logical.split('_')[0])&&sh.logical.includes('_')?'error':'warn')}
  });
  // your own publisher prefixes: those of the custom tables in the workbook, leaving out Microsoft's (ms…, adx)
  Object.keys(missing).sort().forEach(t=>{
    const m=missing[t], n=m.fields.length, nt=m.tables.size, mine=t.includes('_')&&own.has(t.split('_')[0]);
    add('lookup-unknown',m.sh,m.row,t,'"'+t+'" has no tab in this workbook'+(S.dv&&S.dv.ents[t]?' (it does exist in Dataverse)':'')+'. Looked up by '+n+' field'+(n===1?'':'s')+': '+m.fields.slice(0,4).join(', ')+(n>4?', …':'')+'.'+(mine?'':' It looks like a standard or Microsoft table, which is often fine to leave out.'),mine?'warn':'info',nt>1?nt+' tables':'');
  });
  const dict=S.sheets.find(s=>s.isDict);
  if(dict&&dict.colIdx['Table Name']!==undefined){
    const linked=new Set();
    dict.rows.forEach(row=>{const n=getVal(dict,row,'Table Name'); if(!n) return; if(row.link!=null) linked.add(row.link); else add('dict-unlinked',dict,row,n,'No table tab matches this dictionary entry.')});
    ents.forEach(sh=>{if(!linked.has(sh.idx)) add('tab-not-in-dict',sh,null,'','This table is not listed in the Table Dictionary.')});
  }
  ents.forEach(sh=>{ // lookups whose relationship isn't recorded anywhere: one finding per table
    const list=[]; sh.rows.forEach(row=>{if(!isLookupType(getVal(sh,row,'Attribute Type'))) return; const ln=getVal(sh,row,'Logical Name').trim(); lookupTargetsOf(sh,row).forEach(t=>{if(!relKnown(sh,row,t)) list.push(ln+' → '+t)})});
    if(list.length) add('rel-review',sh,null,'',list.length+' relationship'+(list.length===1?' has':'s have')+' no recorded type, so the ERD shows '+(list.length===1?'it as a plain line':'them as plain lines')+': '+list.slice(0,6).join(', ')+(list.length>6?', …':'')+'. Confirm '+(list.length===1?'it':'them')+' by setting Relationship Type to N:1 on the lookup, or by importing Dataverse metadata.');
  });
  Object.entries(relNames).forEach(([n,shs])=>{if(shs.length>1) shs.forEach(sh=>add('rel-name-dup',sh,null,n,'The relationship name "'+n+'" is used '+shs.length+' times. Each relationship needs its own name.'))});
  manualFields().forEach(m=>add('manual-build',m.sh,m.row,m.ln,m.kind+' field. It can\'t be included in a generated solution, so create it by hand after import. Listed in Save & share → Calculated and rollup fields.'));
  if(S.dv) dvChecks(add,ents);
  out.forEach((x,i)=>x.i=i); out.sort((a,b)=>SEV[a.sev].rank-SEV[b.sev].rank||a.i-b.i);
  return S.issues=out;
}
function dvChecks(add,ents){
  const D=S.dv.ents;
  // N:N rows anywhere in the workbook (a relationship is documented once, on either of its tables)
  const nnDoc=new Set(); ents.forEach(sh=>sh.rows.forEach(row=>{if(isNNRow(sh,row)) nnDoc.add(getVal(sh,row,'Logical Name').trim().toLowerCase())}));
  // tables in the chosen solution that the workbook doesn't have
  if(S.dv.sol&&S.dv.sol.tables){const have=new Set(ents.map(s=>s.logical)), at=S.sheets.find(s=>s.isDict)||ents[0];
    if(at) S.dv.sol.tables.filter(t=>!have.has(t)).forEach(t=>{const de=D[t]; add('dv-table-undocumented',at,null,t,'Table "'+t+'"'+(de&&de.label?' ('+de.label+')':'')+' is in the solution '+S.dv.sol.name+' but not in this workbook.'+(S.dv.managed&&de&&de.managed===false?' It was created directly in this environment (unmanaged).':''))})}
  // compared with an exported solution: only your own tables are expected in it, and a table it holds as a shell
  // carries only the columns added to it, so the table's other standard columns are not missing
  const Z=S.dv.zip, own=Z?ownPrefixes(ents):null, yours=ln=>!!own&&own.has(prefixOf(ln)), partial=new Set(Z&&S.dv.sol&&S.dv.sol.partial||[]);
  ents.forEach(sh=>{
    if(!sh.logical) return;
    const de=D[sh.logical];
    if(!de){ if(Z){ if(yours(sh.logical)) add('dv-table-missing',sh,null,'','"'+sh.logical+'" is not in the solution '+S.dv.sol.name+'.'); return }
      add('dv-table-missing',sh,null,'','"'+sh.logical+'" is not in the imported Dataverse metadata. Either it does not exist, or its file was not imported.');return}
    const own=sh.mo['ownership type'];
    if(own&&de.own&&own.toLowerCase().replace(/\s/g,'')!==String(de.own).toLowerCase()) add('dv-ownership',sh,null,'','Workbook says '+own+', Dataverse says '+de.own+'.');
    const doc={};
    sh.rows.forEach(row=>{
      const ln=getVal(sh,row,'Logical Name').trim().toLowerCase(); if(!ln||isNNRow(sh,row)||isSubgridRow(sh,row)) return; doc[ln]=row;   // N:N rows are relationships, sub-grids are forms: neither is a field
      const da=de.attrs[ln];
      if(!da){ if(Z&&partial.has(sh.logical)&&!yours(ln)) return;
        add('dv-field-missing',sh,row,ln,Z?'This field is not on '+sh.logical+' in the solution '+S.dv.sol.name+'.':'This field does not exist on '+sh.logical+' in Dataverse.');return}
      const wt=getVal(sh,row,'Attribute Type'), a=typeClass(wt), b=typeClass(da.type);
      if(a&&b&&a!==b) add('dv-type',sh,row,ln,'Workbook says '+wt+', Dataverse says '+da.type+'.');
      if(sh.colIdx['Required Level']!==undefined){const wr=getVal(sh,row,'Required Level'), x=reqClass(wr), y=reqClass(da.req); if(x&&y&&x!==y) add('dv-required',sh,row,ln,'Workbook says '+wr+', Dataverse says '+da.req+'.')}
      const wc=getVal(sh,row,'Custom Attribute');
      if(wc!==''&&da.custom!=null&&(facet('Custom Attribute',wc)==='True')!==da.custom) add('dv-custom',sh,row,ln,'Workbook says '+(facet('Custom Attribute',wc)==='True'?'custom':'standard')+', Dataverse says '+(da.custom?'custom':'standard')+'.');
      // lookups: the workbook's Targets against Dataverse's N:1 relationships on the same field
      const dvT=[...new Set(de.m1.filter(r=>r.attr===ln).map(r=>r.target))];
      if(dvT.length||isLookupType(wt)){
        const wbT=lookupTargetsOf(sh,row);
        const viaOwner=t=>dvT.includes('owner')&&(t==='systemuser'||t==='team'); // owner fields relate to "owner", documented as user and team
        wbT.filter(t=>!dvT.includes(t)&&!viaOwner(t)).forEach(t=>add('dv-rel-extra',sh,row,ln,'Targets "'+t+'", but Dataverse has no relationship from this field to '+t+'.'));
        if(wbT.length||isLookupType(wt)) dvT.filter(t=>!wbT.includes(t)&&!(t==='owner'&&wbT.some(x=>x==='systemuser'||x==='team'))).forEach(t=>add('dv-rel-missing',sh,row,ln,'Dataverse has a relationship from this field to "'+t+'", which is not in its Targets.'));
      }
    });
    const undoc=Object.values(de.attrs).filter(a=>!a.of&&!doc[a.ln]);
    undoc.filter(a=>a.custom).forEach(a=>add('dv-field-undocumented',sh,null,a.ln,'Custom field "'+a.ln+'"'+(a.label?' ('+a.label+')':'')+(a.type?', '+a.type:'')+', exists in Dataverse but is not documented.'+(S.dv.managed&&a.managed===false?' It was created directly in this environment (unmanaged).':'')));
    de.nn.filter(r=>r.custom&&!nnDoc.has(String(r.schema).toLowerCase())).forEach(r=>add('dv-nn-undocumented',sh,null,r.schema,'N:N relationship "'+r.schema+'" with '+r.other+' exists in Dataverse but is not documented.'+(S.dv.managed&&r.managed===false?' It was created directly in this environment (unmanaged).':'')));
    if(S.dv.managed){
      // managed environment: what is documented but was made or changed here rather than by a managed solution
      if(de.managed===false&&de.custom) add('dv-unmanaged',sh,null,'','This table was created directly in this environment (unmanaged), not by a managed solution.');
      sh.rows.forEach(row=>{const ln=getVal(sh,row,'Logical Name').trim().toLowerCase(), da=de.attrs[ln]; if(da&&da.custom&&da.managed===false) add('dv-unmanaged',sh,row,ln,'Created directly in this environment (unmanaged), not by a managed solution.')});
      const L=S.dv.layers&&S.dv.layers[sh.logical], why=v=>' Unmanaged changes sit on top of '+(v.over||'the managed solution')+(v.changed.length?' (changed: '+v.changed.join(', ')+')':'')+'.';
      if(L&&L.table) add('dv-active-layer',sh,null,'','This table was changed directly in this environment.'+why(L.table));
      if(L) Object.entries(L.attrs).forEach(([ln,v])=>add('dv-active-layer',sh,doc[ln]||null,ln,'Changed directly in this environment.'+why(v)));
    }
    const std=partial.has(sh.logical)?0:undoc.filter(a=>!a.custom).length;
    if(std) add('dv-std-undocumented',sh,null,'',std+' standard field'+(std===1?'':'s')+' in Dataverse '+(std===1?'is':'are')+' not listed. This is often on purpose.');
  });
}
function issueCounts(){const c={error:0,warn:0,info:0};issues().forEach(i=>c[i.sev]++);return c}

/* ---------- Dataverse metadata import ---------- */
// Table definitions in the Web API's shape (from the environment, from saved JSON, or from an exported solution)
function parseDv(texts,base){
  const ents=base||{};
  const lab=x=>(x&&x.UserLocalizedLabel&&x.UserLocalizedLabel.Label)||'';
  const val=x=>x==null?'':typeof x==='object'?(x.Value??''):x;
  const lc=s=>String(s||'').toLowerCase();
  const cas=c=>c?{del:c.Delete||'',assign:c.Assign||'',share:c.Share||'',reparent:c.Reparent||''}:null;
  const pushU=(arr,x)=>{if(!arr.some(y=>y.schema===x.schema))arr.push(x)};
  let org='', n=0;
  const take=e=>{
    if(!e||!e.LogicalName) return; n++;
    const ln=lc(e.LogicalName), t=ents[ln]||(ents[ln]={ln,attrs:{},m1:[],n1:[],nn:[],keys:[]});
    t.schema=e.SchemaName||t.schema||''; t.pid=lc(e.PrimaryIdAttribute)||t.pid||''; t.pname=lc(e.PrimaryNameAttribute)||t.pname||'';
    t.own=val(e.OwnershipType)||t.own||''; if(e.IsCustomEntity!=null) t.custom=!!val(e.IsCustomEntity); t.label=lab(e.DisplayName)||t.label||'';
    if(e.IsManaged!=null) t.managed=!!val(e.IsManaged); if(e.MetadataId) t.mid=e.MetadataId;
    (e.Attributes||[]).forEach(a=>{if(!a.LogicalName) return; const k=lc(a.LogicalName);
      t.attrs[k]={ln:k,type:a.AttributeType||'',req:val(a.RequiredLevel),custom:a.IsCustomAttribute==null?null:!!val(a.IsCustomAttribute),of:a.AttributeOf||'',label:lab(a.DisplayName),managed:a.IsManaged==null?null:!!val(a.IsManaged),mid:a.MetadataId||''}});
    (e.ManyToOneRelationships||[]).forEach(r=>{if(lc(r.ReferencingEntity)===ln) pushU(t.m1,{schema:r.SchemaName,attr:lc(r.ReferencingAttribute),target:lc(r.ReferencedEntity),cascade:cas(r.CascadeConfiguration)})});
    (e.OneToManyRelationships||[]).forEach(r=>{if(lc(r.ReferencedEntity)===ln) pushU(t.n1,{schema:r.SchemaName,child:lc(r.ReferencingEntity),attr:lc(r.ReferencingAttribute),cascade:cas(r.CascadeConfiguration)})});
    (e.ManyToManyRelationships||[]).forEach(r=>{const a=lc(r.Entity1LogicalName),b=lc(r.Entity2LogicalName); pushU(t.nn,{schema:r.SchemaName,other:a===ln?b:a,intersect:r.IntersectEntityName||'',custom:r.IsCustomRelationship==null?null:!!val(r.IsCustomRelationship),managed:r.IsManaged==null?null:!!val(r.IsManaged)})});
    (e.Keys||[]).forEach(k=>{const name=k.LogicalName||k.SchemaName||''; if(!t.keys.some(x=>x.name===name)) t.keys.push({name,attrs:(k.KeyAttributes||[]).map(lc)})});
  };
  texts.forEach(({name,text})=>{
    let j; try{j=JSON.parse(String(text).replace(/^﻿/,''))}catch(e){throw new Error(name+' is not valid JSON')}
    if(j&&j.error) throw new Error(name+' holds a Dataverse error: '+((j.error&&j.error.message)||'unknown'));
    const m=/^(https:\/\/[^/]+)\//.exec((j&&j['@odata.context'])||''); if(m) org=m[1];
    const list=Array.isArray(j)?j:j&&Array.isArray(j.value)?j.value:[j];
    const before=n; list.forEach(take);
    if(n===before) throw new Error(name+' does not contain any table definitions (EntityDefinitions)');
  });
  return {ents,org,n};
}
// An exported solution (.zip): its customizations.xml holds the tables, columns and relationships, in the layout
// Power Apps exports and Build solution writes. Turned into the same definitions the Web API gives, so every check works.
const SOL_TYPES={nvarchar:'String',ntext:'Memo',int:'Integer',bigint:'BigInt',decimal:'Decimal',float:'Double',money:'Money',datetime:'DateTime',bit:'Boolean',picklist:'Picklist',multiselectpicklist:'Virtual',lookup:'Lookup',customer:'Customer',owner:'Owner',primarykey:'Uniqueidentifier',uniqueidentifier:'Uniqueidentifier',state:'State',status:'Status',virtual:'Virtual',image:'Virtual',file:'Virtual',partylist:'PartyList',entityname:'EntityName',managedproperty:'ManagedProperty'};
const SOL_REQ={none:'None',recommended:'Recommended',required:'ApplicationRequired',applicationrequired:'ApplicationRequired',systemrequired:'SystemRequired'};
async function parseSolutionZip(file){
  let z; try{z=await JSZip.loadAsync(await file.arrayBuffer())}catch(e){throw new Error(file.name+' is not a zip file.')}
  const cx=z.file(/(^|\/)customizations\.xml$/i)[0], sx=z.file(/(^|\/)solution\.xml$/i)[0];
  if(!cx) throw new Error(file.name+' is not a Dataverse solution: it has no customizations.xml. Export the solution from Power Apps (Solutions, select it, Export) and add that zip.');
  const xml=async f=>{const d=new DOMParser().parseFromString((await f.async('string')).replace(/^\uFEFF/,''),'application/xml'); if(d.getElementsByTagName('parsererror').length) throw new Error(f.name+' in '+file.name+' could not be read.'); return d};
  const doc=await xml(cx), sdoc=sx?await xml(sx):null;
  const kid=(el,n)=>{if(el) for(const c of el.children) if(c.tagName.toLowerCase()===n.toLowerCase()) return c; return null};
  const txt=(el,n)=>{const c=kid(el,n); return c?c.textContent.trim():''};
  const lbl=(el,wrap,item)=>{const w=kid(el,wrap); if(!w) return ''; const all=[...w.children].filter(c=>c.tagName.toLowerCase()===item.toLowerCase()); const one=all.find(c=>c.getAttribute('languagecode')==='1033')||all[0]; return one?one.getAttribute('description')||'':''};
  const man=sdoc?txt(sdoc.querySelector('SolutionManifest'),'Managed')==='1':false;
  const mf=sdoc&&sdoc.querySelector('SolutionManifest'), sol={unique:txt(mf,'UniqueName')||file.name.replace(/\.zip$/i,''),name:(mf&&lbl(mf,'LocalizedNames','LocalizedName'))||txt(mf,'UniqueName')||file.name,version:txt(mf,'Version'),managed:man,tables:[],partial:[]};
  const roots={}; if(mf) mf.querySelectorAll('RootComponents > RootComponent').forEach(r=>{if(r.getAttribute('type')==='1') roots[String(r.getAttribute('schemaName')||'').toLowerCase()]=+r.getAttribute('behavior')||0});
  const defs={}, Y=v=>/^(1|true)$/i.test(v);
  doc.querySelectorAll('ImportExportXml > Entities > Entity').forEach(E=>{
    const ent=kid(kid(E,'EntityInfo'),'entity'); const schema=(ent&&ent.getAttribute('Name'))||txt(E,'Name'); if(!schema) return;
    const ln=schema.toLowerCase(), attrs=[]; let pid='',pname='';
    (kid(ent,'attributes')?[...kid(ent,'attributes').children]:[]).forEach(a=>{
      const al=(txt(a,'LogicalName')||txt(a,'Name')).toLowerCase(); if(!al) return; const t=txt(a,'Type').toLowerCase();
      if(t==='primarykey') pid=al; if(/(^|\|)PrimaryName(\||$)/.test(txt(a,'DisplayMask'))) pname=al;
      attrs.push({LogicalName:al,AttributeType:SOL_TYPES[t]||t,RequiredLevel:{Value:SOL_REQ[txt(a,'RequiredLevel').toLowerCase()]||txt(a,'RequiredLevel')},IsCustomAttribute:{Value:Y(txt(a,'IsCustomField'))},DisplayName:{UserLocalizedLabel:{Label:lbl(a,'displaynames','displayname')}},IsManaged:man});
    });
    const own=txt(ent,'OwnershipTypeMask'), keys=[...(kid(ent,'EntityKeys')?kid(ent,'EntityKeys').children:[])].map(k=>({LogicalName:txt(k,'LogicalName'),KeyAttributes:[...(kid(k,'EntityKeyAttributes')?kid(k,'EntityKeyAttributes').children:[])].map(x=>x.textContent.trim())}));
    defs[ln]={LogicalName:ln,SchemaName:schema,PrimaryIdAttribute:pid||undefined,PrimaryNameAttribute:pname||undefined,OwnershipType:own?(/org/i.test(own)?'OrganizationOwned':own==='None'?'None':'UserOwned'):undefined,DisplayName:{UserLocalizedLabel:{Label:(ent&&lbl(ent,'LocalizedNames','LocalizedName'))||E.querySelector(':scope > Name')?.getAttribute('LocalizedName')||''}},IsManaged:man,Attributes:attrs,ManyToOneRelationships:[],OneToManyRelationships:[],ManyToManyRelationships:[],Keys:keys};
    sol.tables.push(ln); if((roots[ln]??0)!==0||ent&&ent.getAttribute('unmodified')==='1') sol.partial.push(ln);
  });
  const L=s=>String(s||'').toLowerCase();
  doc.querySelectorAll('ImportExportXml > EntityRelationships > EntityRelationship').forEach(R=>{
    const kind=txt(R,'EntityRelationshipType'), name=R.getAttribute('Name')||'';
    if(/ManyToMany/i.test(kind)){const a=L(txt(R,'FirstEntityName')),b=L(txt(R,'SecondEntityName')), r={SchemaName:name,Entity1LogicalName:a,Entity2LogicalName:b,IntersectEntityName:txt(R,'IntersectEntityName'),IsCustomRelationship:{Value:Y(txt(R,'IsCustomRelationship')||'1')},IsManaged:man}; [a,b].forEach(t=>{if(defs[t]) defs[t].ManyToManyRelationships.push(r)}); return}
    const ing=L(txt(R,'ReferencingEntityName')), ed=L(txt(R,'ReferencedEntityName')), r={SchemaName:name,ReferencingEntity:ing,ReferencedEntity:ed,ReferencingAttribute:L(txt(R,'ReferencingAttributeName')),CascadeConfiguration:{Delete:txt(R,'CascadeDelete'),Assign:txt(R,'CascadeAssign'),Share:txt(R,'CascadeShare'),Reparent:txt(R,'CascadeReparent')}};
    if(defs[ing]) defs[ing].ManyToOneRelationships.push(r); if(defs[ed]) defs[ed].OneToManyRelationships.push(r);
  });
  if(!sol.tables.length) throw new Error('The solution '+sol.name+' in '+file.name+' has no tables to compare with.');
  return {defs:Object.values(defs),sol};
}
async function importDv(files){
  const zips=files.filter(f=>/\.zip$/i.test(f.name)); if(zips.length) return importSolutions(zips);
  try{
    const texts=await Promise.all(files.map(f=>f.text().then(text=>({name:f.name,text}))));
    const prev=S.dv&&S.dv.ents?JSON.parse(JSON.stringify(S.dv.ents)):{};
    const r=parseDv(texts,prev);
    const rec={id:'__dv:'+S.proj,org:r.org||(S.dv&&S.dv.org)||'',at:Date.now(),files:[...new Set([...((S.dv&&S.dv.files)||[]),...files.map(f=>f.name)])],ents:r.ents};
    S.dv=rec; S.issues=null; S.adj=null; if(S.erd) S.erd.nn=S.erd.nn!==false;
    try{await idb.put(rec)}catch(e){saveState(false,'This browser could not store the Dataverse metadata. It will be gone after a reload.')}
    const c=dvSummary(); updateCounts(); refreshSpecial(); if($('#dvpanel').classList.contains('open')) renderDv();
    toast('Imported '+r.n+' table definition'+(r.n===1?'':'s')+'. '+c.matched+' of '+c.tables+' workbook tables found, '+c.diffs+' difference'+(c.diffs===1?'':'s')+' with Dataverse.');
  }catch(err){dlg({title:'Could not import that Dataverse file',body:esc(err.message)+'<br><br>Use the links in the Dataverse panel, and save each page as a .json file.',ok:'OK',cancel:null,danger:true})}
}
// add one or more exported solutions: the workbook is compared with their tables (replacing anything added before)
async function importSolutions(files){
  try{
    const parts=[]; for(const f of files) parts.push(await parseSolutionZip(f));
    const r=parseDv([{name:'solution',text:JSON.stringify({value:parts.flatMap(p=>p.defs)})}]);
    const tables=[...new Set(parts.flatMap(p=>p.sol.tables))], partial=[...new Set(parts.flatMap(p=>p.sol.partial))].filter(t=>!parts.some(p=>p.sol.tables.includes(t)&&!p.sol.partial.includes(t)));
    const name=parts.map(p=>p.sol.name+(p.sol.version?' '+p.sol.version:'')+(p.sol.managed?' (managed)':'')).join(', ');
    const rec={id:'__dv:'+S.proj,org:'',at:Date.now(),files:files.map(f=>f.name),ents:r.ents,zip:true,sol:{name:parts.map(p=>p.sol.name).join(', '),unique:parts.map(p=>p.sol.unique).join(', '),tables,partial,label:name}};
    S.dv=rec; S.issues=null; S.adj=null; if(S.erd) S.erd.nn=S.erd.nn!==false;
    try{await idb.put(rec)}catch(e){saveState(false,'This browser could not store the solution. It will be gone after a reload.')}
    const c=dvSummary(); updateCounts(); refreshSpecial(true); if($('#dvpanel').classList.contains('open')) renderDv();
    toast('Compared with '+name+': '+c.matched+' of '+c.tables+' workbook tables are in it, '+c.diffs+' difference'+(c.diffs===1?'':'s')+'.');
  }catch(err){console.error(err); dlg({title:'Could not read that solution',body:esc(err.message),ok:'OK',cancel:null,danger:true})}
}
function dvSummary(){
  const ents=S.sheets.filter(s=>s.kind==='entity'&&s.logical);
  return {tables:ents.length,matched:S.dv?ents.filter(s=>S.dv.ents[s.logical]).length:0,diffs:issues().filter(i=>i.rule.startsWith('dv-')&&i.sev!=='info').length};
}
function loadDv(){
  const my=S.proj; S.dv=null;
  idb.get('__dv:'+my).then(r=>{if(S.proj!==my||!r) return; S.dv=r; S.issues=null; S.adj=null; updateCounts(); refreshSpecial(true)}).catch(()=>{});
}
// re-draw whatever is on screen after the checks or the Dataverse data change
function refreshSpecial(all){
  if(S.cur==='__overview') renderOverview();
  else if(S.cur==='__issues') renderIssues();
  else if(S.cur==='__erd') erdRefresh(true);
  else if(all&&S.view&&S.view.sh&&S.view.sh.kind==='entity') renderGrid(true);
}
function renderDv(){
  if(LIVE) return renderLive();
  // opened as a file: compare with an exported solution. Inside Dynamics 365 or XrmToolBox the panel reads the environment instead.
  const d=$('#dvpanel'), st=S.dv?dvSummary():null;
  const src=!S.dv?'nothing added yet':S.dv.zip?(S.dv.sol.label||S.dv.sol.name)+' · '+new Date(S.dv.at).toLocaleString():(S.dv.org||'imported table definitions')+' · '+new Date(S.dv.at).toLocaleString();
  let h=`<header><div style="flex:1;min-width:0"><h3>Dataverse</h3><div class="mono dim" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(src)}</div></div><button class="btn ghost" data-dvclose>✕</button></header><div class="body">`;
  h+=`<p class="dim" style="margin-top:0">Compare this workbook with a solution: what is in the solution but not documented, what is documented but not built, and where types, required levels and relationships differ.</p>`;
  if(S.dv){
    h+=dvStatsHTML()+`<div style="display:flex;gap:8px;flex-wrap:wrap;margin:4px 0 16px"><button class="btn primary" data-ov="issues:dv">See the differences</button><button class="btn" data-dv="pick">${S.dv.zip?'Compare with another solution…':'Add a solution (.zip)…'}</button><button class="btn ghost" data-dv="remove">Remove</button></div>`;
  } else h+=`<div style="margin:6px 0 14px"><button class="btn primary" data-dv="pick">Add a solution (.zip)…</button> <span class="dim">or drop it onto the page</span></div>`;
  h+=`<div class="fld"><div class="k">Getting the solution</div><ol class="dim" style="margin:4px 0 0;padding-left:18px"><li>In Power Apps, open <b>Solutions</b>, select the solution and choose <b>Export</b> (managed or unmanaged).</li><li>Add the downloaded .zip here. Several can be added at once.</li></ol>
    <p class="dim" style="margin:8px 0 0">Nothing is uploaded: the file is read in this browser and kept with this workbook. A solution built with <b>Build solution</b> works too. Opened inside Dynamics 365 or in XrmToolBox, this panel picks a solution straight from the environment instead.</p></div></div>`;
  d.innerHTML=h; d.classList.add('open');
}
// the counts at the top of the Dataverse panel, from the current Checks
function dvStatsHTML(extra){
  const st=dvSummary(), iss=issues().filter(i=>i.rule.startsWith('dv-')), n=r=>iss.filter(i=>i.rule===r).length;
  const und=n('dv-table-undocumented')+n('dv-field-undocumented')+n('dv-nn-undocumented'), nb=n('dv-field-missing')+n('dv-table-missing'), dif=n('dv-type')+n('dv-required')+n('dv-rel-extra')+n('dv-rel-missing')+n('dv-ownership')+n('dv-custom');
  const t=(v,l)=>`<div class="stat" style="cursor:default"><b>${v}</b><span>${l}</span></div>`;
  return `<div class="stats" style="margin:4px 0 10px">${t(st.matched+' / '+st.tables,S.dv&&S.dv.zip?'tables in the solution':'tables found')}${t(und,'undocumented')}${t(nb,'not built')}${t(dif,'differences')}${extra||''}</div>`;
}
function dvHTML(sh){
  const de=S.dv&&sh&&sh.logical&&S.dv.ents[sh.logical]; if(!de) return '';
  const tl=t=>S.byLogical[t]!=null?`<span class="tchip" data-golog="${esc(t)}">${esc(t)}</span>`:`<span class="tchip dead">${esc(t)}</span>`;
  const cas=c=>c?esc((c.del||'–')+' / '+(c.assign||'–')):'';
  const rels=[...de.m1.map(r=>['N:1',r.schema,tl(r.target),r.attr,cas(r.cascade)]),...de.n1.map(r=>['1:N',r.schema,tl(r.child),r.attr,cas(r.cascade)]),...de.nn.map(r=>['N:N',r.schema,tl(r.other),esc(r.intersect),''])];
  const tbl=(cols,rows)=>`<table class="subtbl"><thead><tr>${cols.map(c=>`<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map((v,i)=>`<td>${i===2||i===4?v:esc(v)}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
  return `<div class="subs"><div class="subsec"><h4>From Dataverse <span class="dim">· primary key ${esc(de.pid||'?')} · primary name ${esc(de.pname||'?')} · ${esc(de.own||'')}</span></h4></div>
    <div class="subsec"><h4>Relationships <span class="dim">· ${rels.length}</span></h4>${rels.length?tbl(['Type','Relationship','Related table','Field / intersect table','Cascade (delete / assign)'],rels):'<div class="dim">None.</div>'}</div>
    <div class="subsec"><h4>Alternate keys <span class="dim">· ${de.keys.length}</span></h4>${de.keys.length?de.keys.map(k=>`<div><b>${esc(k.name)}</b> <span class="mono">${esc(k.attrs.join(', '))}</span></div>`).join(''):'<div class="dim">None.</div>'}</div></div>`;
}

/* ---------- live: the page running inside a Dataverse (Dynamics 365) environment ----------
   Uploaded as a web resource, the page reads the environment's table definitions through the Web API, as the signed-in
   user (no app registration, nothing stored outside the browser). Two jobs:
   - load a solution as the data model (a workbook in the template layout, built from what is really there)
   - check the open workbook against the environment: undocumented tables, fields and N:N; differences; and, in a
     managed environment, anything created or changed directly there (unmanaged). */
const LIVE=!RO&&location.protocol==='https:'&&(/\/webresources\//i.test(location.pathname)||(()=>{try{return !!(window.parent&&window.parent!==window&&window.parent.Xrm)}catch(e){return false}})());
const LIVE_API=location.origin+'/api/data/v9.2/';
async function dvGet(path){
  const url=/^https:/.test(path)?path:LIVE_API+path;
  let r;
  try{ r=await fetch(url,{credentials:'same-origin',headers:{'Accept':'application/json','OData-MaxVersion':'4.0','OData-Version':'4.0'}}) }
  catch(e){ throw new Error('The environment could not be reached ('+e.message+')') }
  if(!r.ok){ let m=''; try{const j=await r.json(); m=(j&&j.error&&j.error.message)||''}catch(e){}
    const err=new Error((r.status===401||r.status===403?'Not allowed (HTTP '+r.status+')':'Dataverse answered HTTP '+r.status)+(m?': '+m:'')); err.status=r.status; throw err }
  return r.json();
}
async function dvAll(path){ let j=await dvGet(path), out=(j.value||[]).slice(); while(j['@odata.nextLink']){ j=await dvGet(j['@odata.nextLink']); out.push(...(j.value||[])) } return out }
async function pool(items,n,fn){ let i=0; const res=new Array(items.length); await Promise.all(Array.from({length:Math.min(n,items.length)},async()=>{ while(i<items.length){ const k=i++; res[k]=await fn(items[k],k) } })); return res }
const lbl=x=>(x&&x.UserLocalizedLabel&&x.UserLocalizedLabel.Label)||'';
const vOf=x=>x==null?'':typeof x==='object'?(x.Value??''):x;
const guidOk=g=>/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(g));

async function liveSolutions(){
  const all=await dvAll("solutions?$select=solutionid,uniquename,friendlyname,version,ismanaged&$filter=isvisible eq true&$orderby=friendlyname asc");
  return all.filter(s=>!/^(active|default|basic)$/i.test(s.uniquename));
}
// the tables in a solution: tables added whole bring every column; tables added as a shell bring only the columns listed
async function liveSolutionTables(sol){
  if(!guidOk(sol.solutionid)) throw new Error('Not a solution id');
  const comps=await dvAll('solutioncomponents?$select=objectid,componenttype,rootcomponentbehavior&$filter=_solutionid_value eq '+sol.solutionid+' and (componenttype eq 1 or componenttype eq 2)');
  const tables=comps.filter(c=>c.componenttype===1&&guidOk(c.objectid)), attrIds=new Set(comps.filter(c=>c.componenttype===2).map(c=>String(c.objectid).toLowerCase()));
  const out=(await pool(tables,6,async c=>{try{const e=await dvGet('EntityDefinitions('+c.objectid+')?$select=LogicalName'); return {ln:String(e.LogicalName).toLowerCase(),all:!c.rootcomponentbehavior}}catch(e){return null}})).filter(Boolean);
  return {tables:out,attrIds};
}
const LIVE_SEL='MetadataId,LogicalName,SchemaName,DisplayName,DisplayCollectionName,Description,ObjectTypeCode,IsCustomEntity,IsManaged,OwnershipType,IsAuditEnabled,PrimaryIdAttribute,PrimaryNameAttribute,IsActivity,HasNotes,HasActivities';
const LIVE_EXP='Attributes($select=MetadataId,LogicalName,SchemaName,AttributeType,AttributeTypeName,RequiredLevel,IsCustomAttribute,IsManaged,DisplayName,Description,AttributeOf,SourceType),'+
  'ManyToOneRelationships($select=SchemaName,ReferencedEntity,ReferencingEntity,ReferencingAttribute,CascadeConfiguration,IsCustomRelationship,IsManaged),'+
  'OneToManyRelationships($select=SchemaName,ReferencedEntity,ReferencingEntity,ReferencingAttribute,CascadeConfiguration),'+
  'ManyToManyRelationships($select=SchemaName,Entity1LogicalName,Entity2LogicalName,IntersectEntityName,IsCustomRelationship,IsManaged),'+
  'Keys($select=LogicalName,KeyAttributes)';
// type details live on the type-specific attribute classes, so each is its own request
const LIVE_CASTS=[['StringAttributeMetadata','LogicalName,MaxLength,FormatName'],['MemoAttributeMetadata','LogicalName,MaxLength'],['IntegerAttributeMetadata','LogicalName,MinValue,MaxValue'],
  ['DecimalAttributeMetadata','LogicalName,MinValue,MaxValue,Precision'],['DoubleAttributeMetadata','LogicalName,MinValue,MaxValue,Precision'],['MoneyAttributeMetadata','LogicalName,MinValue,MaxValue,Precision'],
  ['DateTimeAttributeMetadata','LogicalName,Format'],['BooleanAttributeMetadata','LogicalName,DefaultValue','OptionSet($select=TrueOption,FalseOption)'],
  ['PicklistAttributeMetadata','LogicalName,DefaultFormValue','OptionSet($select=Options)'],['MultiSelectPicklistAttributeMetadata','LogicalName,DefaultFormValue','OptionSet($select=Options)'],
  ['LookupAttributeMetadata','LogicalName,Targets']];
// the definitions of the named tables (and, with details, every column's type settings). Tables that aren't there are listed in `missing`.
async function liveDefs(names,details,prog){
  const jobs=[]; names.forEach(ln=>{ jobs.push({ln,k:'main'}); if(details) LIVE_CASTS.forEach(c=>jobs.push({ln,k:c})) });
  let done=0; const main={}, det={}, missing=new Set();
  await pool(jobs,8,async j=>{
    const base="EntityDefinitions(LogicalName='"+j.ln+"')";
    try{
      if(j.k==='main') main[j.ln]=await dvGet(base+'?$select='+LIVE_SEL+'&$expand='+LIVE_EXP);
      else{ const [cls,sel,exp]=j.k; const list=await dvAll(base+'/Attributes/Microsoft.Dynamics.CRM.'+cls+'?$select='+sel+(exp?'&$expand='+exp:''));
        const d=det[j.ln]||(det[j.ln]={}); list.forEach(a=>{d[String(a.LogicalName).toLowerCase()]=a}) }
    }catch(e){ if(e.status===404) missing.add(j.ln); else if(j.k==='main') throw e }
    done++; if(prog&&(done%4===0||done===jobs.length)) prog(done,jobs.length);
  });
  return {main:names.filter(n=>main[n]).map(n=>main[n]),det,missing:[...missing]};
}
const LIVE_TYPES={StringType:'Text',MemoType:'Multiline Text',IntegerType:'Whole Number',BigIntType:'BigInt',DecimalType:'Decimal',DoubleType:'Double',MoneyType:'Currency',DateTimeType:'DateTime',BooleanType:'Two options',
  PicklistType:'Choice',MultiSelectPicklistType:'Choices',LookupType:'Lookup',CustomerType:'Customer',OwnerType:'Owner',UniqueidentifierType:'Uniqueidentifier',StateType:'Status',StatusType:'Status Reason',
  EntityNameType:'EntityName',ImageType:'Image',FileType:'File',PartyListType:'PartyList',ManagedPropertyType:'ManagedProperty',VirtualType:'Virtual'};
// one column's settings, written as the Additional data cell the rest of the page reads
function liveAddl(a,d,m1){
  const tn=vOf(a.AttributeTypeName)||'', L=[], num=(k,v)=>{if(v!=null&&v!=='') L.push(k+': '+v)};
  if(tn==='StringType'){L.push('Format: '+(vOf(d&&d.FormatName)||'Text')); num('Max length',d&&d.MaxLength)}
  else if(tn==='MemoType'){L.push('Format: TextArea'); num('Max length',d&&d.MaxLength)}
  else if(tn==='IntegerType'){num('Minimum value',d&&d.MinValue); num('Maximum value',d&&d.MaxValue)}
  else if(/^(DecimalType|DoubleType|MoneyType)$/.test(tn)){num('Minimum value',d&&d.MinValue); num('Maximum value',d&&d.MaxValue); num('Precision',d&&d.Precision)}
  else if(tn==='DateTimeType'){if(d&&d.Format) L.push('Format: '+d.Format)}
  else if(tn==='BooleanType'&&d&&d.OptionSet){L.push('True: '+lbl(d.OptionSet.TrueOption&&d.OptionSet.TrueOption.Label),'False: '+lbl(d.OptionSet.FalseOption&&d.OptionSet.FalseOption.Label),'Default Value: '+(d.DefaultValue?'True':'False'))}
  else if(/^(PicklistType|MultiSelectPicklistType)$/.test(tn)&&d&&d.OptionSet){L.push('Options:'); (d.OptionSet.Options||[]).forEach(o=>L.push(o.Value+': '+lbl(o.Label))); if(d.DefaultFormValue!=null&&d.DefaultFormValue!==-1) L.push('Default: '+d.DefaultFormValue)}
  else if(/^(LookupType|CustomerType|OwnerType)$/.test(tn)){const t=(d&&d.Targets)||[...new Set(m1.map(r=>r.ReferencedEntity))]; if(t.length) L.push('Targets:',...t)}
  return L.join('\n');
}
const LIVE_CASCADE={RemoveLink:'Remove Link',Restrict:'Restrict',Cascade:'Cascade'};
// the tables read from the environment, as a workbook in the template layout (Table Dictionary + a tab per table)
function liveWorkbook(defs,st,title){
  const AH=['Logical Name','Schema Name','Display Name','Attribute Type','Description','Custom Attribute','Type','Required Level','Additional data','Add to RAF Form?','Comment','Relationship Type','Relationship Name','Cascade Delete'];
  const out=XLSX.utils.book_new(), area=title||'', dict=[[],['','','Read from '+location.host+' on '+new Date().toLocaleDateString()+(title?': solution '+title:'')],['','Area','Table Name','Out of the box/custom table?','Static Data?','Purpose','FormusPro Comments','Added to ERD?','Defined in data model?']];
  const inModel=new Set(defs.main.map(e=>String(e.LogicalName).toLowerCase())), nnDone=new Set(), sheets=[], whole={}; let nAttr=0;
  (st&&st.tables||[]).forEach(t=>{whole[t.ln]=t.all});
  defs.main.forEach(e=>{
    const ln=String(e.LogicalName).toLowerCase(), disp=lbl(e.DisplayName)||e.SchemaName, custom=!!vOf(e.IsCustomEntity), d=defs.det[ln]||{}, pk=String(e.PrimaryIdAttribute||'').toLowerCase(), pn=String(e.PrimaryNameAttribute||'').toLowerCase();
    dict.push(['',area,disp,custom?'Custom':'OOTB','',lbl(e.Description),'','Yes','Yes']);
    const tf=b=>b==null||b===''?'':vOf(b)?'True':'False';
    const rows=[['Entity',disp],['Plural Display Name',lbl(e.DisplayCollectionName)],['Description',lbl(e.Description)],['Schema Name',e.SchemaName],['Logical Name',ln],['Object Type Code',e.ObjectTypeCode??''],
      ['Is Custom Entity',tf(e.IsCustomEntity)],['Ownership Type',vOf(e.OwnershipType)],['Audit Tracking',tf(e.IsAuditEnabled)],['Primary Name Column',pn],['Primary Key',pk],['Is Activity',tf(e.IsActivity)],['Has Notes',tf(e.HasNotes)],['Has Activities',tf(e.HasActivities)]];
    const hint=[]; hint[10]='e.g. business logic or related automation'; hint[11]='N:1 on a lookup row; N:N on a many-to-many row'; hint[12]='Optional: generated if blank'; hint[13]='Remove Link (default), Restrict or Cascade';
    rows.push(hint, AH.slice());
    const all=whole[ln]!==false, pick=a=>all||(st&&st.attrIds.has(String(a.MetadataId).toLowerCase()))||String(a.LogicalName).toLowerCase()===pk||String(a.LogicalName).toLowerCase()===pn;
    const attrs=(e.Attributes||[]).filter(a=>a.LogicalName&&!a.AttributeOf&&vOf(a.AttributeTypeName)!=='VirtualType'&&pick(a)); // virtual helper columns are left out
    const rank=a=>{const l=String(a.LogicalName).toLowerCase(); return l===pk?0:l===pn?1:a.IsCustomAttribute?2:3};
    attrs.sort((a,b)=>rank(a)-rank(b)||String(a.LogicalName).localeCompare(String(b.LogicalName)));
    attrs.forEach(a=>{
      const al=String(a.LogicalName).toLowerCase(), tn=vOf(a.AttributeTypeName)||'', m1=(e.ManyToOneRelationships||[]).filter(r=>String(r.ReferencingAttribute).toLowerCase()===al&&String(r.ReferencingEntity).toLowerCase()===ln);
      const lookup=/^(LookupType|CustomerType|OwnerType)$/.test(tn)&&m1.length>0;
      nAttr++;
      rows.push([al,a.SchemaName||'',lbl(a.DisplayName),LIVE_TYPES[tn]||a.AttributeType||'',lbl(a.Description),a.IsCustomAttribute?'True':'False',['Simple','Calculated','Rollup'][a.SourceType]||'Simple',vOf(a.RequiredLevel)||'None',liveAddl(a,d[al],m1),'','',
        lookup?'N:1':'',lookup?m1.map(r=>r.SchemaName).join('\n'):'',lookup?(LIVE_CASCADE[vOf(m1[0].CascadeConfiguration&&m1[0].CascadeConfiguration.Delete)]||''):'']);
    });
    // custom N:N relationships: one row, on the first of their tables in the model
    (e.ManyToManyRelationships||[]).forEach(r=>{
      if(!vOf(r.IsCustomRelationship)||nnDone.has(String(r.SchemaName).toLowerCase())) return;
      const a=String(r.Entity1LogicalName).toLowerCase(), b=String(r.Entity2LogicalName).toLowerCase(), other=a===ln?b:a;
      if(inModel.has(other)&&a!==ln&&defs.main.findIndex(x=>String(x.LogicalName).toLowerCase()===other)>defs.main.indexOf(e)) return; // the other table, later in the list, carries it
      nnDone.add(String(r.SchemaName).toLowerCase());
      rows.push([String(r.SchemaName).toLowerCase(),r.SchemaName,r.SchemaName,'','',vOf(r.IsCustomRelationship)?'True':'False','','','Targets:\n'+other,'','','N:N','','']);
    });
    rows.push([],[],[],['Forms:'],['','Form Name','Formus Comments'],[],[],['Views:'],['','View Name','Columns','Filter']);
    let name=(disp+' ('+e.SchemaName+')').replace(/[\\\/\?\*\[\]:]/g,' ').slice(0,31);
    while(sheets.some(s=>s.name.toLowerCase()===name.toLowerCase())) name=name.slice(0,28)+'~'+(sheets.length%100);
    const ws=XLSX.utils.aoa_to_sheet(rows); ws['!cols']=[{wch:34},{wch:26},{wch:30},{wch:18},{wch:50},{wch:14},{wch:10},{wch:16},{wch:44},{wch:16},{wch:30},{wch:18},{wch:34},{wch:18}];
    sheets.push({name,ws});
  });
  const wd=XLSX.utils.aoa_to_sheet(dict); wd['!cols']=[{wch:3},{wch:18},{wch:36},{wch:26},{wch:12},{wch:50},{wch:40},{wch:14},{wch:20}];
  XLSX.utils.book_append_sheet(out,wd,'Table Dictionary'); sheets.forEach(s=>XLSX.utils.book_append_sheet(out,s.ws,s.name));
  return {wb:out,tables:sheets.length,attrs:nAttr};
}
// what an unmanaged layer changed, from its msdyn_changes JSON (property names only; housekeeping left out)
function liveChanged(s){
  try{ const j=typeof s==='string'?JSON.parse(s):s, list=(j&&(j.Attributes||j.attributes))||[];
    return [...new Set(list.map(x=>String(x.Key||x.key||'')).filter(k=>k&&!/^(componentstate|overwritetime|solutionid|supportingsolutionid|ismanaged|introducedversion|modifiedon|modifiedby|createdon|versionnumber|metadataid|.*id)$/i.test(k)))].slice(0,8) }
  catch(e){ return [] }
}
// managed environment: managed tables and custom fields that carry an unmanaged ("Active") layer
async function liveLayers(ents,names,prog){
  const jobs=[]; names.forEach(ln=>{ const de=ents[ln]; if(!de) return;
    if(de.managed&&guidOk(de.mid)) jobs.push({ln,kind:'Entity',id:de.mid});
    Object.values(de.attrs).forEach(a=>{ if(a.managed&&a.custom&&!a.of&&guidOk(a.mid)) jobs.push({ln,kind:'Attribute',id:a.mid,attr:a.ln}) }) });
  const layers={}; let done=0, failed=null;
  await pool(jobs,8,async j=>{
    if(failed) return;
    try{
      const r=await dvAll("msdyn_componentlayers?$filter=msdyn_componentid eq '"+j.id+"' and msdyn_solutioncomponentname eq '"+j.kind+"'&$select=msdyn_solutionname,msdyn_order,msdyn_changes,msdyn_publishername");
      const act=r.find(x=>String(x.msdyn_solutionname).toLowerCase()==='active');
      if(act){ const below=r.filter(x=>x!==act).sort((a,b)=>(b.msdyn_order||0)-(a.msdyn_order||0))[0]; const t=layers[j.ln]||(layers[j.ln]={table:null,attrs:{}});
        const v={over:below?below.msdyn_solutionname:'',changed:liveChanged(act.msdyn_changes)}; if(j.kind==='Entity') t.table=v; else t.attrs[j.attr]=v }
    }catch(e){ failed=e }
    done++; if(prog&&(done%5===0||done===jobs.length)) prog(done,jobs.length);
  });
  return {layers,checked:jobs.length,failed:failed?failed.message:''};
}
// keep what was read as the workbook's Dataverse metadata, so Checks and each table page show it
async function liveSetDv(main,extra){
  const r=parseDv([{name:'live',text:JSON.stringify({value:main})}]);
  const rec=Object.assign({id:'__dv:'+S.proj,org:location.origin,at:Date.now(),files:[],ents:r.ents,live:true},extra||{});
  S.dv=rec; S.issues=null; S.adj=null; if(S.erd) S.erd.nn=S.erd.nn!==false;
  try{await idb.put(rec)}catch(e){}
  updateCounts(); refreshSpecial(true);
}
const LV={sols:null,user:'',busy:false,msg:'',err:'',sol1:'',managed:false,last:null};   // sol1: the solution picked ('' = the Default solution)
function liveProg(m){LV.msg=m; const el=$('#liveprog'); if(el) el.textContent=m}
async function liveStart(){
  if(LV.sols||LV.busy) return; LV.busy=true; LV.err='';
  try{
    const who=await dvGet('WhoAmI'); try{const u=await dvGet('systemusers('+who.UserId+')?$select=fullname'); LV.user=u.fullname||''}catch(e){}
    LV.sols=await liveSolutions();
  }catch(e){LV.err=e.message}
  LV.busy=false; if($('#dvpanel').classList.contains('open')) renderLive();
}
async function liveLoad(){
  const sol=(LV.sols||[]).find(s=>s.solutionid===LV.sol1); if(!sol) return toast('Choose a solution first');
  LV.busy=true; LV.err=''; renderLive();
  try{
    liveProg('Reading the tables in '+sol.friendlyname+'…');
    const st=await liveSolutionTables(sol); if(!st.tables.length) throw new Error('The solution '+sol.friendlyname+' has no tables');
    const names=st.tables.map(t=>t.ln);
    const defs=await liveDefs(names,true,(d,n)=>liveProg('Reading '+names.length+' table definition'+(names.length===1?'':'s')+': '+Math.round(d/n*100)+'%'));
    liveProg('Building the model…');
    const lw=liveWorkbook(defs,st,sol.friendlyname);
    const name=sol.uniquename+' (live '+new Date().toISOString().slice(0,10)+').xlsx';
    const cut=fitSheetJS(lw.wb);
    const ok=await loadFile(new File([XLSX.write(lw.wb,{type:'array',bookType:'xlsx'})],name,{type:XLSX_MIME}));
    if(ok) cutReport(cut,'The model of '+esc(sol.friendlyname));
    if(ok){ await liveSetDv(defs.main,{files:['Live: solution '+sol.friendlyname],sol:{name:sol.friendlyname,unique:sol.uniquename,tables:names}}); LV.last={kind:'load',sol:sol.friendlyname,tables:lw.tables,attrs:lw.attrs}; toast('Loaded '+lw.tables+' tables and '+lw.attrs+' columns from '+sol.friendlyname) }
    liveProg('');
  }catch(e){LV.err=e.message; liveProg('')}
  LV.busy=false; renderLive();
}
async function liveCheck(){
  if(isStarter()) return toast('Open the data-model workbook first');
  const sol=LV.sol1?(LV.sols||[]).find(s=>s.solutionid===LV.sol1):null;
  LV.busy=true; LV.err=''; renderLive();
  try{
    let solTables=null;
    if(sol){ liveProg('Reading the tables in '+sol.friendlyname+'…'); solTables=(await liveSolutionTables(sol)).tables.map(t=>t.ln) }
    const wbTables=[...new Set(S.sheets.filter(s=>s.kind==='entity'&&/^[a-z0-9_]+$/.test(s.logical)).map(s=>s.logical))];
    const names=[...new Set([...wbTables,...(solTables||[])])];
    const defs=await liveDefs(names,false,(d,n)=>liveProg('Reading '+names.length+' table definitions: '+Math.round(d/n*100)+'%'));
    await liveSetDv(defs.main,{files:['Live: '+(sol?'solution '+sol.friendlyname:'the Default solution, this workbook\'s tables')],sol:sol?{name:sol.friendlyname,unique:sol.uniquename,tables:solTables}:null,managed:LV.managed});
    let lay=null;
    if(LV.managed){
      lay=await liveLayers(S.dv.ents,wbTables,(d,n)=>liveProg('Looking for unmanaged changes: '+d+' of '+n+' tables and fields'));
      S.dv.layers=lay.layers; S.dv.layerInfo={checked:lay.checked,failed:lay.failed}; S.issues=null; try{await idb.put(S.dv)}catch(e){} updateCounts(); refreshSpecial(true);
    }
    const c=dvSummary(); LV.last={kind:'check',sol:sol?sol.friendlyname:'',found:c.matched,tables:c.tables,diffs:c.diffs,missing:defs.missing.length,layers:lay};
    liveProg('');
  }catch(e){LV.err=e.message; liveProg('')}
  LV.busy=false; renderLive();
}
function renderLive(){
  const d=$('#dvpanel'); if(!LV.sols&&!LV.busy&&!LV.err) liveStart();
  const dis=LV.busy||!LV.sols?'disabled':'';
  let h=`<header><div style="flex:1;min-width:0"><h3>This environment</h3><div class="mono dim">${esc(location.host)}${LV.user?' · '+esc(LV.user):''}</div></div><button class="btn ghost" data-dvclose>✕</button></header><div class="body">`;
  if(LV.err) h+=`<div class="err" style="white-space:pre-wrap;color:var(--edit);background:var(--edit-bg);border-radius:10px;padding:10px;margin-bottom:12px">${esc(LV.err)}</div>`;
  if(!LV.sols) h+=`<p class="dim">${LV.busy?'Reading the solutions in this environment…':'The solutions could not be read.'}</p>`;
  // one list of solutions, with a search; what to do with the one picked is underneath
  h+=`<div class="fld"><div class="k">Solution</div>
    ${solPick(1,dis)}</div>
    <div class="fld"><div class="k">Load it as the data model</div>
    <p class="dim" style="margin:2px 0 8px">Builds the model from what is in the environment: the solution's tables, columns, choices, lookups and N:N, in the template layout. Save it with Save &amp; share to keep it as a workbook.</p>
    <button class="btn primary" data-live="load" ${dis||!LV.sol1?'disabled':''}>${liveLoadLabel()}</button></div>
    <div class="fld"><div class="k">Check this workbook against it</div>
    <p class="dim" style="margin:2px 0 8px">${isStarter()?'Open the data-model workbook first.':'Compares <b>'+esc(S.fileName)+'</b> with what is really there: undocumented tables, fields and N:N, fields not built yet, and differences in types, required levels and relationships.'}</p>
    <label style="display:flex;gap:8px;align-items:flex-start;margin-top:8px"><input type="checkbox" id="livemanaged" style="width:auto;height:auto;flex:none;margin-top:3px" ${LV.managed?'checked':''} ${dis}><span>Managed environment (test or production): also find anything created or changed directly here, as unmanaged. <span class="dim">Slower: one check per custom field.</span></span></label>
    <div style="margin-top:8px"><button class="btn primary" data-live="check" ${dis||isStarter()?'disabled':''}>${liveCheckLabel()}</button></div></div>`;
  h+=`<div id="liveprog" class="dim" style="min-height:20px">${esc(LV.msg)}</div>`;
  const L=LV.last;
  if(L&&L.kind==='check'&&S.dv&&S.dv.live){
    const iss=issues().filter(i=>i.rule.startsWith('dv-')), n=r=>iss.filter(i=>i.rule===r).length;
    const und=n('dv-table-undocumented')+n('dv-field-undocumented')+n('dv-nn-undocumented'), unm=iss.filter(i=>i.rule==='dv-unmanaged'||i.rule==='dv-active-layer'||/\(unmanaged\)/.test(i.msg)).length;
    h+=`<div class="stats" style="margin:4px 0 10px"><div class="stat" style="cursor:default"><b>${L.found} / ${L.tables}</b><span>tables found</span></div><div class="stat" style="cursor:default"><b>${und}</b><span>undocumented</span></div><div class="stat" style="cursor:default"><b>${n('dv-field-missing')+n('dv-table-missing')}</b><span>not built</span></div><div class="stat" style="cursor:default"><b>${n('dv-type')+n('dv-required')+n('dv-rel-extra')+n('dv-rel-missing')+n('dv-ownership')+n('dv-custom')}</b><span>differences</span></div>${S.dv.managed?`<div class="stat" style="cursor:default"><b>${unm}</b><span>unmanaged changes</span></div>`:''}</div>
      ${L.layers&&L.layers.failed?`<p class="dim" style="color:var(--pink)">Solution layers could not be read (${esc(L.layers.failed)}), so changes to managed fields are not shown. Unmanaged tables and fields still are.</p>`:''}
      <button class="btn primary" data-ov="issues:dv">See the differences</button>`;
  }
  h+=`<p class="dim" style="margin-top:14px">Everything is read as you (${esc(LV.user||'the signed-in user')}), and nothing is changed in the environment.</p></div>`;
  d.innerHTML=h; d.classList.add('open');
  const mg=$('#livemanaged'); if(mg) mg.onchange=()=>{LV.managed=mg.checked};
  d.querySelectorAll('.solpick').forEach(p=>{
    const w=p.dataset.sp, list=p.querySelector('.splist');
    p.querySelector('.spq').oninput=e=>{LV['q'+w]=e.target.value; list.innerHTML=solRows(w)};
    list.onclick=e=>{
      const g=e.target.closest('[data-spgrp]'); if(g){LV['mg'+w]=!LV['mg'+w]; list.innerHTML=solRows(w); return}
      const r=e.target.closest('[data-sid]'); if(!r) return;
      LV['sol'+w]=r.dataset.sid; list.innerHTML=solRows(w);
      const lb=d.querySelector('[data-live="load"]'), cb=d.querySelector('[data-live="check"]');
      if(lb){lb.disabled=!!LV.busy||!LV.sol1; lb.textContent=liveLoadLabel()} if(cb) cb.textContent=liveCheckLabel();
    };
    const on=list.querySelector('.sprow.on'); if(on) list.scrollTop=on.offsetTop-list.offsetTop-60;
  });
}
const liveLoadLabel=()=>LV.sol1?'Load '+solName(LV.sol1)+' as the model':'Pick a solution to load it';
const liveCheckLabel=()=>'Check against '+(LV.sol1?solName(LV.sol1):'the Default solution');
// A searchable solution list: your unmanaged solutions first, managed ones folded underneath (opened by searching or clicking)
function solName(id){const s=(LV.sols||[]).find(x=>x.solutionid===id); return s?s.friendlyname:''}
function solPick(w,dis){
  return `<div class="solpick" data-sp="${w}"><input type="search" class="spq" placeholder="Search solutions by name or unique name" value="${esc(LV['q'+w]||'')}" ${dis}><div class="splist" role="listbox">${solRows(String(w))}</div></div>`;
}
function solRows(w){
  const q=(LV['q'+w]||'').trim().toLowerCase(), sel=LV['sol'+w]||'', all=LV.sols||[];
  const hit=s=>!q||q.split(/\s+/).every(t=>(s.friendlyname+' '+s.uniquename).toLowerCase().includes(t));
  const row=s=>`<button type="button" class="sprow ${s.solutionid===sel?'on':''}" data-sid="${esc(s.solutionid)}" role="option" aria-selected="${s.solutionid===sel}"><b>${esc(s.friendlyname)}</b><span>${esc(s.uniquename)} · ${esc(s.version||'')}</span></button>`;
  const um=all.filter(s=>!s.ismanaged&&hit(s)), mm=all.filter(s=>s.ismanaged&&hit(s));
  const open=LV['mg'+w]||!!q||mm.some(s=>s.solutionid===sel);
  let h=!q?`<button type="button" class="sprow ${sel===''?'on':''}" data-sid="" role="option"><b>Default solution: the tables in this workbook</b><span>For a check, wherever they came from (nothing to load)</span></button>`:'';
  h+=`<div class="spgh">Unmanaged · ${um.length}</div>`+(um.length?um.map(row).join(''):'<div class="spnone">None'+(q?' match':'')+'</div>');
  if(mm.length) h+=`<button type="button" class="spgh spgrp" data-spgrp>${open?'▾':'▸'} Managed · ${mm.length}</button>`+(open?mm.map(row).join(''):'');
  return h;
}

/* ---------- overview (landing page) ---------- */
function pct(a,b){return b?Math.round(a/b*100):0}
function renderOverview(){
  const main=$('#main'); const ents=S.sheets.filter(s=>s.kind==='entity'); const dict=S.sheets.find(s=>s.isDict);
  let fields=0,desc=0,lookups=0; const pairs=new Set();
  ents.forEach(sh=>sh.rows.forEach(row=>{if(isSubgridRow(sh,row)) return; fields++; if(getVal(sh,row,'Description')) desc++;
    if(isLookupType(getVal(sh,row,'Attribute Type'))){lookups++; lookupTargetsOf(sh,row).forEach(t=>{if(S.byLogical[t]!=null&&t!==sh.logical) pairs.add([sh.logical,t].sort().join('|'))})}}));
  const iss=issues(), c=issueCounts();
  // unresolved lookups that need attention (warnings and errors); lookups to standard tables are counted separately
  const lk=iss.filter(i=>i.rule==='lookup-unknown'||i.rule==='lookup-no-target'), unresolved=lk.filter(i=>i.sev!=='info').length, lkInfo=lk.length-unresolved;
  const custom=ents.filter(s=>s.custom).length;
  const tile=(v,l,act,tone,note)=>`<${act?'button':'div'} class="ovtile ${tone||''}" ${act?`data-ov="${act}"`:''}><b>${v}</b><span>${l}</span>${note?`<em>${note}</em>`:''}</${act?'button':'div'}>`;
  if(isStarter()){
    main.innerHTML=`<div class="ov"><h1>Overview</h1><div class="sub">No workbook open</div>
      <div class="ovcard" style="max-width:760px;margin-top:16px;border-color:var(--pink)"><h3>Start here</h3>
      <div class="startgrid">
        <div class="startopt"><b>Open a data-model workbook</b><span class="dim">An .xlsx in the FormusPro template, or a Metadata Document Generator export (converted automatically). Or drag it onto the page.</span><button class="btn primary" data-ov="open">Open workbook…</button></div>
        ${LIVE?'<div class="startopt"><b>Load from this environment</b><span class="dim">Build the model from a solution in '+esc(location.host)+'.</span><button class="btn" data-wb="__live">This environment…</button></div>':''}
        <div class="startopt"><b>Start a new model</b><span class="dim">The blank FormusPro template: add tables and fields here, then save it as a workbook.</span><button class="btn" data-ov="blank">Download blank template</button></div>
      </div>
      ${S.lib.length?`<div class="wblist"><b>Or reopen one kept in this browser</b>${S.lib.map(r=>`<div class="vline"><span style="flex:1;min-width:0;overflow-wrap:anywhere">${esc(r.name)} <span class="dim">· ${r.tables??'?'} tables · added ${esc(new Date(r.added).toLocaleDateString())}</span></span><button class="btn" data-wb="${esc(r.id)}">Open</button></div>`).join('')}</div>`:''}</div></div>`;
    return;
  }
  const others=S.lib.filter(r=>r.b64!==S.curB64).length;
  let h=`<div class="ov"><h1>Overview</h1><div class="sub">${esc(S.fileName)}${S.diff?' · compared with '+esc(S.diff.pl):''}${S.dv?' · checked against '+esc(S.dv.org||'Dataverse'):''}</div>
  ${S.restored?`<div class="note2 ovnote"><span>Reopened <b>${esc(S.fileName)}</b>, kept in this browser from last time.${others?` ${others} other workbook${others===1?' is':'s are'} kept here too.`:''} <a href="#" data-wb="__menu">Switch workbook</a> · <a href="#" data-wb="__open">Open another</a></span><button class="x" data-ovx title="Dismiss">×</button></div>`:''}
  <div class="ovtiles">${tile(ents.length,'tables · '+custom+' custom, '+(ents.length-custom)+' standard')}${tile(fields.toLocaleString(),'fields')}${tile(lookups,'lookups')}${tile(pairs.size,'related table pairs','go:__erd')}
    ${tile(unresolved,'unresolved lookups',lk.length?'issues:rule:lookup-*':'',unresolved?'warn':'',lkInfo?lkInfo.toLocaleString()+' to standard tables (info)':'')}${tile(c.error,'errors',c.error?'issues:error':'',c.error?'err':'')}${tile(c.warn,'warnings',c.warn?'issues:warn':'',c.warn?'warn':'')}
    ${RO?'':tile(S.edits.size,'your edits',S.edits.size?'changes':'')}${S.diff?tile(S.diff.total,'changes since '+esc(S.diff.pl),'versions'):''}</div><div class="ovgrid">`;
  // documentation completeness
  const bar=(label,a,b)=>{const p=pct(a,b);return `<div class="ovrow"><span>${label}</span><span class="dim">${a.toLocaleString()} of ${b.toLocaleString()} · ${p}%</span></div><div class="bar ${p<50?'lo':''}"><i style="width:${p}%"></i></div>`};
  const tDesc=ents.filter(s=>s.mo['description']).length;
  let comp=bar('Fields with a description',desc,fields)+bar('Tables with a description',tDesc,ents.length);
  if(dict){const n=dict.rows.filter(r=>getVal(dict,r,'Table Name')).length; ['Area','Purpose'].forEach(col=>{if(dict.colIdx[col]!==undefined) comp+=bar('Dictionary entries with '+col.toLowerCase(),dict.rows.filter(r=>getVal(dict,r,'Table Name')&&getVal(dict,r,col)).length,n)})}
  const worst=ents.filter(s=>s.rows.length>=3).map(s=>({s,p:pct(s.rows.filter(r=>getVal(s,r,'Description')).length,s.rows.length)})).sort((a,b)=>a.p-b.p||b.s.rows.length-a.s.rows.length).slice(0,8);
  if(worst.length) comp+=`<table class="ovtbl" style="margin-top:6px"><tr><th>Least described tables</th><th>Fields</th><th>Described</th></tr>${worst.map(w=>`<tr><td><a href="#" data-ov="go:${w.s.idx}">${esc(w.s.label)}</a></td><td>${w.s.rows.length}</td><td>${w.p}%</td></tr>`).join('')}</table>`;
  h+=`<div class="ovcard"><h3>Documentation completeness</h3>${comp}</div>`;
  // by area
  const areas={}; ents.forEach(s=>{const a=s.area||'Other tables',x=areas[a]||(areas[a]={t:0,f:0,d:0,i:0}); x.t++; x.f+=s.rows.length; x.d+=s.rows.filter(r=>getVal(s,r,'Description')).length});
  iss.forEach(i=>{if(i.sh.kind==='entity'&&i.sev!=='info') areas[i.sh.area||'Other tables'].i++});
  h+=`<div class="ovcard"><h3>By area</h3><table class="ovtbl"><tr><th>Area</th><th>Tables</th><th>Fields</th><th>Described</th><th>Issues</th></tr>${Object.keys(areas).sort((a,b)=>(a==='Other tables')-(b==='Other tables')||a.localeCompare(b)).map(a=>{const x=areas[a];return `<tr><td>${esc(a)}</td><td>${x.t}</td><td>${x.f}</td><td>${pct(x.d,x.f)}%</td><td>${x.i?`<a href="#" data-ov="issues:area:${esc(a)}">${x.i}</a>`:'0'}</td></tr>`}).join('')}</table></div>`;
  // checks
  const byRule={}; iss.forEach(i=>{const k=i.rule+'|'+i.sev; byRule[k]=(byRule[k]||0)+1});   // grouped by check AND the findings' own severity
  const rl=Object.keys(byRule).sort((a,b)=>SEV[a.split('|')[1]].rank-SEV[b.split('|')[1]].rank||byRule[b]-byRule[a]);
  h+=`<div class="ovcard"><h3>Checks</h3>${rl.length?`<table class="ovtbl">${rl.slice(0,10).map(k=>{const [r,sv]=k.split('|');return `<tr><td><span class="pill ${SEV[sv].cls}">${SEV[sv].label}</span></td><td><a href="#" data-ov="issues:rule:${r}">${esc(RULES[r][1])}</a></td><td>${byRule[k].toLocaleString()}</td></tr>`}).join('')}</table>${rl.length>10?`<div class="dim" style="margin-top:6px">and ${rl.length-10} more kinds</div>`:''}`:'<div class="dim">No problems found.</div>'}<div style="margin-top:10px"><button class="btn" data-ov="issues">Open all checks</button></div></div>`;
  // latest changes
  let lc='';
  if(S.diff){const D=S.diff; const parts=[[D.addedTables.length,'tables added'],[D.removedTables.length,'tables removed'],[D.newRows.length,'fields added'],[D.goneRows.length,'fields removed'],[D.changes.length,'values changed'],[D.colsAdded.length+D.colsRemoved.length,'columns added or removed'],[D.metaChanges.length,'table details changed'],[D.subCount,'form and view changes']].filter(x=>x[0]);
    lc+=`<div class="ovrow"><b>${esc(D.pl)} → ${esc(D.cl)}</b><a href="#" data-ov="versions">What changed</a></div>${parts.length?'<ul style="margin:4px 0 10px;padding-left:18px">'+parts.map(x=>`<li>${x[0]} ${x[1]}</li>`).join('')+'</ul>':'<div class="dim">No differences.</div>'}`}
  const ed=[...S.edits.values()];
  if(ed.length) lc+=`<div class="ovrow"><b>Your edits (${ed.length})</b><a href="#" data-ov="changes">All changes</a></div><ul style="margin:4px 0 0;padding-left:18px">${ed.slice(-5).reverse().map(e=>`<li><a href="#" data-cgo="${ed.indexOf(e)}">${esc(e.sh.label)} · ${esc(editLabel(e))}</a> <span class="dim">${esc(e.col)}</span></li>`).join('')}</ul>`;
  if(S.pending.length) lc+=`<div style="margin-top:8px;color:var(--pink)">${S.pending.length} carried-over edit${S.pending.length===1?'':'s'} need${S.pending.length===1?'s':''} your attention. <a href="#" data-ov="changes">Review</a></div>`;
  {const own=ownPrefixes(); if(own.size&&!isStarter()){const pe=issues().filter(i=>/^pname-|^rel-name-dup|^nn-target/.test(i.rule)&&i.sev==='error').length;
    h+=RO?'':`<div class="ovcard"><h3>Build a Dataverse solution</h3><div>Turns your new tables, fields and relationships into an unmanaged solution, with a PowerShell script that imports it using pac.</div>${pe?`<div style="margin-top:6px;color:#B42318">${pe} problem${pe===1?'':'s'} will keep some tables or relationships out. <a href="#" data-ov="issues:error">See them</a></div>`:''}<div style="margin-top:10px"><button class="btn primary" data-ov="solution">Build solution…</button></div></div>`}}
  {const mf=manualFields(); if(mf.length){const k=x=>mf.filter(m=>m.kind===x).length, tb=new Set(mf.map(m=>m.sh)).size;
    h+=`<div class="ovcard"><h3>To build by hand</h3><div>${mf.length} calculated or rollup field${mf.length===1?'':'s'} in ${tb} table${tb===1?'':'s'} (${[['Calculated',k('Calculated')],['Rollup',k('Rollup')],['Formula',k('Formula')]].filter(x=>x[1]).map(x=>x[1]+' '+x[0].toLowerCase()).join(', ')}).</div><div class="dim" style="margin-top:4px">Their formulas aren't in the workbook, so they can't go in a generated solution. Create them in Power Apps after import.</div><div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap"><button class="btn primary" data-ov="manual">Download the list (.xlsx)</button><button class="btn" data-ov="issues:rule:manual-build">See them in Checks</button></div></div>`}}
  h+=`<div class="ovcard"><h3>Latest changes</h3>${lc||'<div class="dim">No edits yet, and no earlier version to compare with. Use <b>Workbook ▾ → Load a newer version</b> to compare.</div>'}</div>`;
  // Dataverse
  const ds=S.dv?dvSummary():null;
  h+=`<div class="ovcard"><h3>Dataverse</h3>${S.dv?`<div>${ds.matched} of ${ds.tables} tables ${S.dv.zip?'in the solution '+esc(S.dv.sol.name):'found in '+esc(S.dv.org||'the imported metadata')}, ${ds.diffs} difference${ds.diffs===1?'':'s'}.</div><div class="dim" style="margin-top:4px">Imported ${esc(new Date(S.dv.at).toLocaleString())}</div><div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap"><button class="btn" data-ov="issues:dv">See the differences</button><button class="btn" data-ov="dv">Dataverse panel</button></div>`
    :`<div class="dim">Not checked yet. ${LIVE?'Check this workbook against a solution in this environment':'Add an exported solution (.zip) to check this workbook against it'}: undocumented tables and fields, what is not built yet, and differences in types, required levels and relationships.</div><div style="margin-top:10px"><button class="btn primary" data-ov="dv">${LIVE?'Check against this environment…':'Compare with a solution…'}</button></div>`}</div>`;
  main.innerHTML=h+'</div></div>';
}

/* ---------- checks page ---------- */
function issState(){return S.issSt||(S.issSt={sev:{error:true,warn:true,info:true},rule:'',areas:new Set(),dv:false,shown:300})}
function renderIssues(){
  const main=$('#main'), all=issues(), st=issState(), q=(S.issQ||'').toLowerCase().trim();
  const list=all.filter(i=>st.sev[i.sev]&&(!st.rule||(st.rule.endsWith('*')?i.rule.startsWith(st.rule.slice(0,-1)):i.rule===st.rule))&&(!st.areas.size||i.sh.kind==='entity'&&st.areas.has(areaOf(i.sh)))&&(!st.dv||i.rule.startsWith('dv-'))
    &&(!q||(i.sh.label+' '+i.where+' '+i.sh.logical+' '+i.field+' '+RULES[i.rule][1]+' '+i.msg).toLowerCase().includes(q)));
  S.issList=list;
  const c=issueCounts(), byRule={}; all.forEach(i=>{byRule[i.rule]=(byRule[i.rule]||0)+1});
  const chip=(k)=>`<button class="btn ${st.sev[k]?'on':''}" data-isev="${k}"><span class="pill ${SEV[k].cls}">${SEV[k].plural}</span> ${c[k]}</button>`;
  let h=`<div class="vhead"><h1>Checks</h1><div class="sub">${all.length} finding${all.length===1?'':'s'} · ${c.error} error${c.error===1?'':'s'}, ${c.warn} warning${c.warn===1?'':'s'}, ${c.info} info${S.dv?' · including the Dataverse comparison':''}</div>
    <div class="desc">Problems found in the data model itself: missing or duplicated logical names, lookups to tables that are not documented, dictionary entries without a tab${S.dv?', and differences from the imported Dataverse metadata':''}. They update as you edit.</div></div>
    <div class="toolbar">${['error','warn','info'].map(chip).join('')}
      <select id="irule" style="height:32px;border:1px solid var(--line);border-radius:8px;background:var(--panel);padding:0 8px;max-width:320px"><option value="">All checks</option>${Object.keys(RULES).filter(r=>byRule[r]).map(r=>`<option value="${r}" ${st.rule===r?'selected':''}>${esc(RULES[r][1])} (${byRule[r]})</option>`).join('')}</select>
      ${st.rule.endsWith('*')?`<span class="af">Lookup checks <button data-iclr="rule">×</button></span>`:''}${hasAreas()?`<button class="btn ${st.areas.size?'on':''}" data-areabtn="iss">Area: ${esc(areaLabel(st.areas))} ▾</button>`:''}${st.areas.size?`<span class="af">${esc([...st.areas].join(', '))} <button data-iclr="area">×</button></span>`:''}${st.dv?`<span class="af">Dataverse only <button data-iclr="dv">×</button></span>`:''}
      <span class="grow"></span><span class="count">${list.length===all.length?list.length+' shown':list.length+' of '+all.length+' shown'}</span><button class="btn" data-act="iss-csv">Export (CSV)</button></div>
    <div class="gridwrap" id="isswrap">`;
  if(!list.length) h+=`<div class="empty">${all.length?'<b>Nothing matches.</b><br>Try clearing a filter or the search.':'<b>No problems found.</b>'}</div>`;
  else{
    h+=`<table class="grid" style="width:100%"><colgroup><col style="width:110px"><col style="width:200px"><col style="width:190px"><col style="width:250px"><col></colgroup><thead><tr><th><div class="th">Severity</div></th><th><div class="th">Table</div></th><th><div class="th">Field</div></th><th><div class="th">Check</div></th><th><div class="th">Detail</div></th></tr></thead><tbody>`;
    list.slice(0,st.shown).forEach((i,k)=>{h+=`<tr data-ii="${k}" style="cursor:pointer"><td><span class="pill ${SEV[i.sev].cls}">${SEV[i.sev].label}</span></td><td><div class="cell lnk">${esc(i.where||i.sh.label)}</div></td><td><div class="cell mono">${esc(i.field)}</div></td><td><div class="cell">${esc(RULES[i.rule][1])}</div></td><td><div class="cell">${esc(i.msg)}</div></td></tr>`});
    h+='</tbody></table>';
    if(list.length>st.shown) h+=`<div class="more"><button class="btn" data-act="iss-more">Show more (${list.length-st.shown} remaining)</button></div>`;
  }
  main.innerHTML=h+'</div>';
}
function issueRows(){return [['Severity','Table','Logical name','Field','Check','Detail']].concat((S.issList||issues()).map(i=>[SEV[i.sev].label,i.where||i.sh.label,i.where?'':(i.sh.logical||''),i.field,RULES[i.rule][1],i.msg]))}

/* ---------- relationships and primary columns, as recorded in the workbook ---------- */
// Relationship Type column: N:1 on a lookup (1:N accepted: the same relationship seen from the other table),
// N:N on a row that describes a many-to-many relationship (its other table in "Targets:")
function relTypeOf(sh,row){
  const v=getVal(sh,row,'Relationship Type').trim().toUpperCase().replace(/\s+/g,''); if(!v) return '';
  if(/^(N:1|1:N|MANY-?TO-?ONE|ONE-?TO-?MANY)$/.test(v)) return 'N:1';
  if(/^(N:N|M:N|MANY-?TO-?MANY)$/.test(v)) return 'N:N';
  return '?';
}
const isNNRow=(sh,row)=>relTypeOf(sh,row)==='N:N';
// Cascade Delete column -> the value Dataverse uses; null when the text isn't recognised
function cascadeOf(sh,row){const v=getVal(sh,row,'Cascade Delete').trim().toLowerCase().replace(/\s+/g,''); return v===''||v==='removelink'?'RemoveLink':v==='restrict'?'Restrict':v==='cascade'?'Cascade':null}
const pnameOf=sh=>String(sh.mo['primary name column']||'').trim().toLowerCase();
const pkOf=sh=>String(sh.mo['primary key']||'').trim().toLowerCase()||(sh.logical?sh.logical+'id':'');
const isPnameRow=(sh,row)=>{const p=pnameOf(sh);return !!p&&getVal(sh,row,'Logical Name').trim().toLowerCase()===p};
// the primary key row: the Primary Key detail, or <table>id when the workbook doesn't record it
const isPkRow=(sh,row)=>{const k=pkOf(sh);return !!k&&getVal(sh,row,'Logical Name').trim().toLowerCase()===k};

/* ---------- Dataverse solution generator ---------- */
// Builds an unmanaged solution (solution.xml + customizations.xml) from the workbook: new tables with their fields,
// your new fields on existing tables (as shells holding only those fields), lookups, customer lookups and N:N.
// Calculated/rollup fields, activity tables, multi-table lookups, images and files are listed instead.
const solKey=()=>'dme.sol:'+(S.proj||'bundled');
function solDefaults(){
  const ents=S.sheets.filter(s=>s.kind==='entity'), own=ownPrefixes(ents), cnt=new Map();
  ents.forEach(sh=>sh.rows.forEach(r=>{const m=/^([a-z][a-z0-9]{1,7})_/.exec(getVal(sh,r,'Logical Name').trim().toLowerCase()); if(m&&!isMsPrefix(m[1])&&(!own.size||own.has(m[1]))) cnt.set(m[1],(cnt.get(m[1])||0)+1)}));
  const top=[...cnt.entries()].sort((a,b)=>b[1]-a[1])[0], prefix=top?top[0]:'new';
  const opt=new Map();
  ents.forEach(sh=>sh.rows.forEach(r=>{if(!getVal(sh,r,'Logical Name').trim().toLowerCase().startsWith(prefix+'_')||!/choice|picklist/i.test(getVal(sh,r,'Attribute Type'))) return;
    (getVal(sh,r,'Additional data').match(/^\s*\d{9,}\s*:/gm)||[]).forEach(x=>{const p=Math.floor(parseInt(x,10)/10000); opt.set(p,(opt.get(p)||0)+1)})}));
  const op=[...opt.entries()].sort((a,b)=>b[1]-a[1])[0], P=prefix.toUpperCase(), pub=myPubs().find(p=>p.prefix===prefix);
  return {solName:P+'_DataModel',solDisplay:P+' data model',version:'1.0.0.0',pubName:pub?pub.pubName:prefix,pubDisplay:pub?pub.pubDisplay:P,prefix,optPrefix:pub&&pub.optPrefix?pub.optPrefix:op?op[0]:10000,scope:'all'};
}
const solSettings=()=>Object.assign(solDefaults(),store.get(solKey())||{});
function solValidate(c){
  const e=[];
  if(!/^[A-Za-z_][A-Za-z0-9_]{0,63}$/.test(c.solName)) e.push('Solution name: letters, digits and underscores, starting with a letter.');
  if(!/^[A-Za-z_][A-Za-z0-9_]{0,63}$/.test(c.pubName)) e.push('Publisher name: letters, digits and underscores, starting with a letter.');
  if(!/^[a-z][a-z0-9]{1,7}$/.test(c.prefix)||c.prefix==='mscrm') e.push('Prefix: 2 to 8 lower-case letters or digits, starting with a letter (not "mscrm").');
  if(!(Number.isInteger(+c.optPrefix)&&+c.optPrefix>=10000&&+c.optPrefix<=99999)) e.push('Choice value prefix: a whole number from 10000 to 99999.');
  if(!/^\d+\.\d+\.\d+\.\d+$/.test(c.version)) e.push('Version: four numbers, for example 1.0.0.0.');
  if(!c.solDisplay.trim()||!c.pubDisplay.trim()) e.push('Display names cannot be blank.');
  return e;
}
// the Additional data cell, read into its settings: "Max length: 100" -> {'max length':'100'}, option lines -> options[]
function addlOf(sh,row){
  const o={options:[]}; let sec=null;
  String(getVal(sh,row,'Additional data')).split('\n').map(l=>l.trim()).filter(Boolean).forEach(l=>{
    const m=/^([^:]{1,40}):\s*(.*)$/.exec(l);
    if(m&&!/^-?\d+$/.test(m[1].trim())){sec=m[1].trim().toLowerCase(); if(m[2]!=='') o[sec]=m[2].trim()}
    else if(sec==='options'){const k=/^(-?\d+)\s*:\s*(.*)$/.exec(l); if(k) o.options.push({v:+k[1],label:k[2].replace(/\s*\(no color\)\s*$/i,'').trim()})}
  });
  return o;
}
// what to do with one field: {act:'attr'|'lookup'|'customer'|'auto'|'manual'|'skip', ...}
function fieldSpec(sh,row){
  const at=getVal(sh,row,'Attribute Type').trim(), l=at.toLowerCase().replace(/[^a-z]/g,''), ln=getVal(sh,row,'Logical Name').trim().toLowerCase(), A=addlOf(sh,row);
  const num=k=>A[k]!=null&&A[k]!==''&&!isNaN(+A[k])?+A[k]:null;
  if(MANUAL_RE.test(getVal(sh,row,'Type'))) return {act:'manual',why:getVal(sh,row,'Type').trim()+' field: create it by hand (see the hand-build list)'};
  if(/^(virtual|entityname|state|status|statusreason|owner|partylist|managedproperty|uniqueidentifier|primarykey)$/.test(l)) return {act:'auto',why:'created by Dataverse'};
  if(/^(currency|money)$/.test(l)&&/_base$/.test(ln)) return {act:'auto',why:'currency base field, created by Dataverse'};
  if(/^(text|string|singlelineoftext)$/.test(l)) return {act:'attr',t:'nvarchar',format:({text:'text',email:'email',url:'url',phone:'phone',textarea:'textarea',tickersymbol:'tickersymbol'})[(A.format||'text').toLowerCase()]||'text',max:Math.max(1,Math.min(4000,num('max length')||100))};
  if(/^(multilinetext|multiplelinesoftext|memo|ntext)$/.test(l)) return {act:'attr',t:'ntext',max:Math.max(1,Math.min(1048576,num('max length')||2000))};
  if(/^(wholenumber|integer|int)$/.test(l)) return {act:'attr',t:'int',min:num('minimum value')??-2147483648,max:num('maximum value')??2147483647};
  if(l==='bigint') return {act:'attr',t:'bigint'};
  if(l==='decimal') return {act:'attr',t:'decimal',min:num('minimum value')??-100000000000,max:num('maximum value')??100000000000,acc:num('precision')??2};
  if(/^(double|float|floatingpointnumber)$/.test(l)) return {act:'attr',t:'float',min:num('minimum value')??0,max:num('maximum value')??1000000000,acc:num('precision')??2};
  if(/^(currency|money)$/.test(l)) return {act:'attr',t:'money',min:num('minimum value')??-922337203685477,max:num('maximum value')??922337203685477,acc:num('precision')??2};
  if(/^(datetime|dateandtime|dateonly|date)$/.test(l)){const d=l==='dateonly'||l==='date'||/dateonly/i.test(A.format||''); return {act:'attr',t:'datetime',format:d?'date':'datetime',behavior:d?2:1}}
  if(/^(twooptions|boolean|yesno)$/.test(l)) return {act:'attr',t:'bit',yes:A['true']||'Yes',no:A['false']||'No',def:/^(true|yes|1)$/i.test(A['default value']||'')?1:0};
  if(/^(choice|picklist|optionset|choices|multiselectpicklist|multiselectoptionset)$/.test(l)){
    if(!A.options.length) return {act:'skip',why:'choice field with no options listed'};
    const d=String(A['default']||'').trim();
    return {act:'attr',t:/choices|multi/.test(l)?'multiselectpicklist':'picklist',options:A.options,def:/^-?\d+$/.test(d)?+d:-1};
  }
  if(l==='lookup'){const tg=lookupTargetsOf(sh,row); if(!tg.length) return {act:'skip',why:'lookup with no table in "Targets:"'}; if(tg.length>1) return {act:'skip',why:'lookup to several tables ('+tg.join(', ')+'): create it by hand'}; return {act:'lookup',target:tg[0]}}
  if(l==='customer'){const tg=lookupTargetsOf(sh,row); return {act:'customer',targets:tg.length?tg:['account','contact']}}
  if(/^(image|file)$/.test(l)) return {act:'skip',why:at+' field: create it by hand'};
  return {act:'skip',why:at?'field type "'+at+'" is not supported by the generator':'no attribute type'};
}
// decide what goes in the solution. Nothing here touches the workbook.
function buildPlan(cfg){
  const P=cfg.prefix.toLowerCase(), mine=ln=>ln.startsWith(P+'_'), tablesOnly=cfg.scope==='tables';
  const ents=S.sheets.filter(s=>s.kind==='entity'&&s.logical);
  const plan={cfg,tablesOnly,newTables:[],shells:[],rels:[],nn:[],report:[],counts:{auto:0,left:0}};
  const rep=(tbl,item,what,action,why)=>plan.report.push({tbl,item,what,action,why:why||''});
  const used=new Set(), relName=base=>{base=base.replace(/[^A-Za-z0-9_]/g,'_'); let n=base.slice(0,100),i=1; while(used.has(n.toLowerCase())) n=base.slice(0,95)+'_'+(++i); used.add(n.toLowerCase()); return n};
  // names already chosen in the workbook are reserved first, so generated names never clash with them
  ents.forEach(sh=>sh.rows.forEach(r=>{const n=(isNNRow(sh,r)?getVal(sh,r,'Logical Name'):getVal(sh,r,'Relationship Name')).trim(); if(n) used.add(n.toLowerCase())}));
  const take=n=>{used.delete(n.toLowerCase()); return relName(n)};
  const planned=new Set(), schemaOf={};
  ents.forEach(sh=>{schemaOf[sh.logical]=sh.schema||sh.logical});
  ents.forEach(sh=>{
    const isNew=mine(sh.logical);
    if(isNew){
      const why=[], pn=pnameOf(sh), prow=pn&&sh.rows.find(r=>getVal(sh,r,'Logical Name').trim().toLowerCase()===pn);
      if(!pn) why.push('no Primary Name Column in its table details');
      else if(!prow) why.push('its primary name column '+pn+' is not in the field list');
      else if(fieldSpec(sh,prow).t!=='nvarchar') why.push('its primary name column '+pn+' is not single-line text');
      if(/^(true|yes|1)$/i.test(String(sh.mo['is activity']||''))) why.push('activity tables are created by hand');
      {const kr=sh.rows.find(r=>getVal(sh,r,'Logical Name').trim().toLowerCase()===pkOf(sh)), kt=kr&&getVal(sh,kr,'Attribute Type').trim(); if(kt&&!isGuidType(kt)) why.push('its primary key '+pkOf(sh)+' is '+kt+', but Dataverse primary keys are unique identifiers (use an alternate key)')}
      if(why.length){rep(sh.label,sh.logical,'Table','Not included',why.join('; ')); return}
      if(/^(true|yes|1)$/i.test(String(sh.mo['has activities']||''))) rep(sh.label,sh.logical,'Table setting','Build by hand','Has Activities: after import, turn on Activities in the table\'s properties in Power Apps');
      planned.add(sh.logical);
    }
    const T={sh,isNew,schema:sh.schema||sh.logical,fields:[]};
    sh.rows.forEach(row=>{
      const ln=getVal(sh,row,'Logical Name').trim().toLowerCase(); if(!ln||!mine(ln)||isSubgridRow(sh,row)) return;   // not yours (Dataverse's or Microsoft's own), or a form sub-grid
      if(tablesOnly&&!(isNew&&ln===pnameOf(sh))){if(!(isNew&&ln===pkOf(sh))){plan.counts.left++; rep(sh.label,ln,isNNRow(sh,row)?'N:N relationship':'Field','Left out','tables-only build')} return}
      if(isNNRow(sh,row)){plan.nn.push({sh,row,name:getVal(sh,row,'Logical Name').trim()}); return}
      if(isNew&&ln===pkOf(sh)) return;                                                           // the primary key is generated with the table
      {const twin=systemTwin(ln); if(twin){rep(sh.label,ln,'Field','Not included','Dataverse creates '+twin+' on every table, so this would be a second, custom copy of it'); return}}
      const sp=fieldSpec(sh,row);
      if(sp.act==='auto'){plan.counts.auto++; return}
      if(sp.act==='manual'){rep(sh.label,ln,'Field','Build by hand',sp.why); return}
      if(sp.act==='skip'){rep(sh.label,ln,'Field','Not included',sp.why); return}
      T.fields.push({row,ln,spec:sp,primary:isNew&&ln===pnameOf(sh)});
    });
    if(isNew) plan.newTables.push(T); else if(T.fields.length) plan.shells.push(T);
  });
  const all=[...plan.newTables,...plan.shells], strip=ln=>ln.replace(new RegExp('^'+P+'_'),'');
  // lookups and customer lookups become relationships; a target that is yours must be in this solution
  all.forEach(T=>{T.fields=T.fields.filter(f=>{
    const sh=T.sh,row=f.row,given=getVal(sh,row,'Relationship Name').trim(),cas=cascadeOf(sh,row)||'RemoveLink';
    if(f.spec.act==='lookup'){
      const tg=f.spec.target;
      if(mine(tg)&&!planned.has(tg)){rep(sh.label,f.ln,'Field','Not included','its table '+tg+' is not in this solution'); return false}
      plan.rels.push({name:given?take(given):relName(P+'_'+strip(tg)+'_'+strip(sh.logical)+'_'+strip(f.ln)),referencing:T.schema,referenced:schemaOf[tg]||tg,attr:getVal(sh,row,'Schema Name').trim()||f.ln,ln:f.ln,cascade:cas,shell:!T.isNew});
    }
    if(f.spec.act==='customer'){
      const bad=f.spec.targets.filter(tg=>mine(tg)&&!planned.has(tg));
      if(bad.length){rep(sh.label,f.ln,'Field','Not included','its table '+bad.join(', ')+' is not in this solution'); return false}
      f.spec.targets.forEach(tg=>plan.rels.push({name:relName((given||P+'_'+strip(sh.logical)+'_'+strip(f.ln))+'_'+strip(tg)),referencing:T.schema,referenced:schemaOf[tg]||tg,attr:getVal(sh,row,'Schema Name').trim()||f.ln,ln:f.ln,cascade:cas,shell:!T.isNew}));
    }
    return true;
  })});
  plan.nn=plan.nn.map(n=>{
    const tg=lookupTargetsOf(n.sh,n.row), lbl=n.sh.label;
    if(tg.length!==1){rep(lbl,n.name||'(no name)','N:N relationship','Not included','needs exactly one table in "Targets:"'); return null}
    if(mine(n.sh.logical)&&!planned.has(n.sh.logical)||mine(tg[0])&&!planned.has(tg[0])){rep(lbl,n.name,'N:N relationship','Not included','one of its tables is not in this solution'); return null}
    const name=n.name?take(n.name):relName(P+'_'+strip(n.sh.logical)+'_'+strip(tg[0]));
    return {name,first:schemaOf[n.sh.logical]||n.sh.logical,second:schemaOf[tg[0]]||tg[0],label:getVal(n.sh,n.row,'Display Name').trim()};
  }).filter(Boolean);
  plan.shells=plan.shells.filter(T=>T.fields.length);
  plan.newTables.forEach(T=>{rep(T.sh.label,T.sh.logical,'Table','Included','new table with '+T.fields.length+' field'+(T.fields.length===1?'':'s')); T.fields.forEach(f=>rep(T.sh.label,f.ln,'Field','Included',(f.primary?'primary name, ':'')+(f.spec.t||f.spec.act)))});
  plan.shells.forEach(T=>{rep(T.sh.label,T.sh.logical,'Table','Included','existing table: only your '+T.fields.length+' new field'+(T.fields.length===1?'':'s')); T.fields.forEach(f=>rep(T.sh.label,f.ln,'Field','Included',f.spec.t||f.spec.act))});
  plan.rels.forEach(r=>rep(r.referencing,r.name,'Relationship (1:N)','Included',r.referenced+' → '+r.referencing+' via '+r.ln+', delete: '+r.cascade));
  plan.nn.forEach(r=>rep(r.first,r.name,'Relationship (N:N)','Included',r.first+' ↔ '+r.second));
  plan.fieldCount=all.reduce((a,T)=>a+T.fields.length,0);
  return plan;
}
const xe=s=>String(s??'').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g,'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const lbl1033=(wrap,item,text)=>`<${wrap}><${item} description="${xe(text)}" languagecode="1033" /></${wrap}>`;
function reqLevel(v,primary){const f=facet('Required Level',v); return primary||/Required/.test(f)?'required':f==='Recommended'?'recommended':'none'}
function attrXml(T,f,cfg){
  const sh=T.sh,row=f.row,sp=f.spec,v=cfg.version;
  const schema=getVal(sh,row,'Schema Name').trim()||f.ln, disp=getVal(sh,row,'Display Name').trim()||schema, desc=getVal(sh,row,'Description').trim();
  const type=sp.act==='lookup'?'lookup':sp.act==='customer'?'customer':sp.t, primary=!!f.primary;
  const secured=sh.colIdx['Secured']!==undefined&&/^(true|yes|1)$/i.test(getVal(sh,row,'Secured'))?1:0;
  const opts=(name,kind,items)=>`<optionset Name="${xe(name)}"><OptionSetType>${kind}</OptionSetType>${kind==='bit'?'':'<IsGlobal>0</IsGlobal>'}<IntroducedVersion>${v}</IntroducedVersion><IsCustomizable>1</IsCustomizable>${kind==='bit'?'<ExternalTypeName></ExternalTypeName>':''}${lbl1033('displaynames','displayname',disp)}${lbl1033('Descriptions','Description',desc)}<options>${items.map(o=>`<option value="${o.v}" ExternalValue="" IsHidden="0"><labels><label description="${xe(o.label||String(o.v))}" languagecode="1033" /></labels></option>`).join('')}</options></optionset>`;
  let x=`<attribute PhysicalName="${xe(schema)}"><Type>${type}</Type><Name>${xe(f.ln)}</Name><LogicalName>${xe(f.ln)}</LogicalName><RequiredLevel>${reqLevel(getVal(sh,row,'Required Level'),primary)}</RequiredLevel>`+
    `<DisplayMask>${primary?'PrimaryName|ValidForAdvancedFind|ValidForForm|ValidForGrid|RequiredForForm':'ValidForAdvancedFind|ValidForForm|ValidForGrid'}</DisplayMask><ImeMode>auto</ImeMode>`+
    `<ValidForUpdateApi>1</ValidForUpdateApi><ValidForReadApi>1</ValidForReadApi><ValidForCreateApi>1</ValidForCreateApi><IsCustomField>1</IsCustomField><IsAuditEnabled>1</IsAuditEnabled><IsSecured>${secured}</IsSecured>`+
    `<IntroducedVersion>${v}</IntroducedVersion><IsCustomizable>1</IsCustomizable><IsRenameable>1</IsRenameable><CanModifySearchSettings>1</CanModifySearchSettings><CanModifyRequirementLevelSettings>1</CanModifyRequirementLevelSettings><CanModifyAdditionalSettings>1</CanModifyAdditionalSettings>`+
    `<SourceType>0</SourceType><IsGlobalFilterEnabled>0</IsGlobalFilterEnabled><IsSortableEnabled>0</IsSortableEnabled><CanModifyGlobalFilterSettings>1</CanModifyGlobalFilterSettings><CanModifyIsSortableSettings>1</CanModifyIsSortableSettings><IsDataSourceSecret>0</IsDataSourceSecret><AutoNumberFormat></AutoNumberFormat><IsSearchable>${primary?1:0}</IsSearchable><IsFilterable>0</IsFilterable><IsRetrievable>1</IsRetrievable><IsLocalizable>0</IsLocalizable>`;
  if(type==='nvarchar') x+=`<Format>${sp.format}</Format><MaxLength>${sp.max}</MaxLength><Length>${sp.max*2}</Length>`;
  else if(type==='ntext') x+=`<Format>text</Format><MaxLength>${sp.max}</MaxLength>`;
  else if(type==='int') x+=`<Format></Format><MinValue>${sp.min}</MinValue><MaxValue>${sp.max}</MaxValue>`;
  else if(type==='bigint') x+=`<MinValue>-9223372036854775808</MinValue><MaxValue>9223372036854775807</MaxValue>`;
  else if(type==='decimal'||type==='float') x+=`<MinValue>${sp.min}</MinValue><MaxValue>${sp.max}</MaxValue><Accuracy>${sp.acc}</Accuracy>`;
  else if(type==='money') x+=`<MinValue>${sp.min}</MinValue><MaxValue>${sp.max}</MaxValue><Accuracy>${sp.acc}</Accuracy><AccuracySource>${sp.acc===2?2:0}</AccuracySource><IsBaseCurrency>0</IsBaseCurrency>`;
  else if(type==='datetime') x+=`<Format>${sp.format}</Format><CanChangeDateTimeBehavior>1</CanChangeDateTimeBehavior><Behavior>${sp.behavior}</Behavior>`;
  else if(type==='bit') x+=`<AppDefaultValue>${sp.def}</AppDefaultValue>`+opts(sh.logical+'_'+f.ln,'bit',[{v:1,label:sp.yes},{v:0,label:sp.no}]);
  else if(type==='picklist'||type==='multiselectpicklist'){const n=sh.logical+'_'+f.ln; x+=`${type==='picklist'?`<AppDefaultValue>${sp.def}</AppDefaultValue>`:''}<OptionSetName>${xe(n)}</OptionSetName>`+opts(n,'picklist',sp.options)}
  else if(type==='lookup'||type==='customer') x+=`<LookupStyle>single</LookupStyle><LookupTypes />`;
  return x+lbl1033('displaynames','displayname',disp)+lbl1033('Descriptions','Description',desc)+'</attribute>';
}
const RIBBON='<RibbonDiffXml><CustomActions /><Templates><RibbonTemplates Id="Mscrm.Templates"></RibbonTemplates></Templates><CommandDefinitions /><RuleDefinitions><TabDisplayRules /><DisplayRules /><EnableRules /></RuleDefinitions><LocLabels /></RibbonDiffXml>';
function entityXml(T,cfg){
  const sh=T.sh,v=cfg.version,disp=sh.label,schema=T.schema;
  const head=`<Entity><Name LocalizedName="${xe(disp)}" OriginalName="${xe(disp)}">${xe(schema)}</Name><EntityInfo>`;
  const attrs=T.fields.map(f=>attrXml(T,f,cfg)).join('');
  if(!T.isNew) return head+`<entity Name="${xe(schema)}" unmodified="1"><attributes>${attrs}</attributes></entity></EntityInfo>${RIBBON}</Entity>`;
  const yes=k=>/^(true|yes|1)$/i.test(String(sh.mo[k]||''));
  const own=/org/i.test(String(sh.mo['ownership type']||''))?'OrgOwned':'UserOwned';
  const pk=pkOf(sh), pkRow=sh.rows.find(r=>getVal(sh,r,'Logical Name').trim().toLowerCase()===pk), pkSchema=(pkRow&&getVal(sh,pkRow,'Schema Name').trim())||pk;
  const pkXml=`<attribute PhysicalName="${xe(pkSchema)}"><Type>primarykey</Type><Name>${xe(pk)}</Name><LogicalName>${xe(pk)}</LogicalName><RequiredLevel>systemrequired</RequiredLevel><DisplayMask>ValidForAdvancedFind|RequiredForGrid</DisplayMask><ImeMode>auto</ImeMode><ValidForUpdateApi>0</ValidForUpdateApi><ValidForReadApi>1</ValidForReadApi><ValidForCreateApi>1</ValidForCreateApi><IsCustomField>0</IsCustomField><IsAuditEnabled>0</IsAuditEnabled><IsSecured>0</IsSecured><IntroducedVersion>${v}</IntroducedVersion><IsCustomizable>1</IsCustomizable><IsRenameable>1</IsRenameable><CanModifySearchSettings>1</CanModifySearchSettings><CanModifyRequirementLevelSettings>0</CanModifyRequirementLevelSettings><CanModifyAdditionalSettings>1</CanModifyAdditionalSettings><SourceType>0</SourceType><IsGlobalFilterEnabled>0</IsGlobalFilterEnabled><IsSortableEnabled>0</IsSortableEnabled><CanModifyGlobalFilterSettings>1</CanModifyGlobalFilterSettings><CanModifyIsSortableSettings>1</CanModifyIsSortableSettings><IsDataSourceSecret>0</IsDataSourceSecret><AutoNumberFormat></AutoNumberFormat><IsSearchable>0</IsSearchable><IsFilterable>1</IsFilterable><IsRetrievable>1</IsRetrievable><IsLocalizable>0</IsLocalizable>${lbl1033('displaynames','displayname',disp)}${lbl1033('Descriptions','Description','Unique identifier for entity instances')}</attribute>`;
  const flags=`<EntitySetName>${xe(sh.logical+'s')}</EntitySetName><IsDuplicateCheckSupported>1</IsDuplicateCheckSupported><IsBusinessProcessEnabled>0</IsBusinessProcessEnabled><IsRequiredOffline>0</IsRequiredOffline><IsInteractionCentricEnabled>0</IsInteractionCentricEnabled><IsCollaboration>0</IsCollaboration><AutoRouteToOwnerQueue>0</AutoRouteToOwnerQueue><IsConnectionsEnabled>0</IsConnectionsEnabled><EntityColor></EntityColor><IsDocumentManagementEnabled>0</IsDocumentManagementEnabled><AutoCreateAccessTeams>0</AutoCreateAccessTeams><IsOneNoteIntegrationEnabled>0</IsOneNoteIntegrationEnabled><IsKnowledgeManagementEnabled>0</IsKnowledgeManagementEnabled><IsSLAEnabled>0</IsSLAEnabled><IsDocumentRecommendationsEnabled>0</IsDocumentRecommendationsEnabled><IsBPFEntity>0</IsBPFEntity>`+
    `<OwnershipTypeMask>${own}</OwnershipTypeMask><IsAuditEnabled>${yes('audit tracking')?1:0}</IsAuditEnabled><IsRetrieveAuditEnabled>0</IsRetrieveAuditEnabled><IsRetrieveMultipleAuditEnabled>0</IsRetrieveMultipleAuditEnabled><IsActivity>0</IsActivity><ActivityTypeMask></ActivityTypeMask><IsActivityParty>0</IsActivityParty><IsReplicated>0</IsReplicated><IsReplicationUserFiltered>0</IsReplicationUserFiltered><IsMailMergeEnabled>1</IsMailMergeEnabled><IsVisibleInMobile>0</IsVisibleInMobile><IsVisibleInMobileClient>1</IsVisibleInMobileClient><IsReadOnlyInMobileClient>0</IsReadOnlyInMobileClient><IsOfflineInMobileClient>0</IsOfflineInMobileClient><DaysSinceRecordLastModified>0</DaysSinceRecordLastModified><MobileOfflineFilters></MobileOfflineFilters><IsMapiGridEnabled>1</IsMapiGridEnabled><IsReadingPaneEnabled>1</IsReadingPaneEnabled><IsQuickCreateEnabled>0</IsQuickCreateEnabled><SyncToExternalSearchIndex>0</SyncToExternalSearchIndex><IntroducedVersion>${v}</IntroducedVersion><IsCustomizable>1</IsCustomizable><IsRenameable>1</IsRenameable><IsMappable>1</IsMappable><CanModifyAuditSettings>1</CanModifyAuditSettings><CanModifyMobileVisibility>1</CanModifyMobileVisibility><CanModifyMobileClientVisibility>1</CanModifyMobileClientVisibility><CanModifyMobileClientReadOnly>1</CanModifyMobileClientReadOnly><CanModifyMobileClientOffline>1</CanModifyMobileClientOffline><CanModifyConnectionSettings>1</CanModifyConnectionSettings><CanModifyDuplicateDetectionSettings>1</CanModifyDuplicateDetectionSettings><CanModifyMailMergeSettings>1</CanModifyMailMergeSettings><CanModifyQueueSettings>1</CanModifyQueueSettings><CanCreateAttributes>1</CanCreateAttributes><CanCreateForms>1</CanCreateForms><CanCreateCharts>1</CanCreateCharts><CanCreateViews>1</CanCreateViews><CanModifyAdditionalSettings>1</CanModifyAdditionalSettings><CanEnableSyncToExternalSearchIndex>1</CanEnableSyncToExternalSearchIndex><IconVectorName></IconVectorName><EnforceStateTransitions>0</EnforceStateTransitions><CanChangeHierarchicalRelationship>1</CanChangeHierarchicalRelationship><EntityHelpUrlEnabled>0</EntityHelpUrlEnabled><EntityHelpUrl></EntityHelpUrl><ChangeTrackingEnabled>0</ChangeTrackingEnabled><CanChangeTrackingBeEnabled>1</CanChangeTrackingBeEnabled><IsEnabledForExternalChannels>0</IsEnabledForExternalChannels><IsMSTeamsIntegrationEnabled>0</IsMSTeamsIntegrationEnabled><IsSolutionAware>0</IsSolutionAware>${yes('has notes')?'<HasRelatedNotes>True</HasRelatedNotes>':''}`;   // exports write notes only when on; activities are not a table setting in the file
  return head+`<entity Name="${xe(schema)}">${lbl1033('LocalizedNames','LocalizedName',disp)}${lbl1033('LocalizedCollectionNames','LocalizedCollectionName',sh.mo['plural display name']||disp+'s')}${lbl1033('Descriptions','Description',sh.mo['description']||'')}<attributes>${pkXml}${attrs}</attributes>${flags}</entity></EntityInfo>${RIBBON}</Entity>`;
}
function relXml(r,cfg){
  const desc=`<RelationshipDescription><Descriptions><Description description="" languagecode="1033" /></Descriptions></RelationshipDescription>`;
  if(r.first) return `<EntityRelationship Name="${xe(r.name)}"><EntityRelationshipType>ManyToMany</EntityRelationshipType><IsCustomizable>1</IsCustomizable><IntroducedVersion>${cfg.version}</IntroducedVersion><IsHierarchical>0</IsHierarchical><FirstEntityName>${xe(r.first)}</FirstEntityName><SecondEntityName>${xe(r.second)}</SecondEntityName><IntersectEntityName>${xe(r.name.toLowerCase())}</IntersectEntityName><IsValidForAdvancedFind>1</IsValidForAdvancedFind><EntityRelationshipRoles>`+   // as exported: no description on N:N, roles numbered 1 and 2
    [1,2].map(n=>`<EntityRelationshipRole><NavPaneDisplayOption>UseCollectionName</NavPaneDisplayOption><NavPaneArea>Details</NavPaneArea><NavPaneOrder>10000</NavPaneOrder><NavigationPropertyName>${xe(r.name)}</NavigationPropertyName><AssociationRoleOrdinal>${n}</AssociationRoleOrdinal></EntityRelationshipRole>`).join('')+`</EntityRelationshipRoles></EntityRelationship>`;
  return `<EntityRelationship Name="${xe(r.name)}"><EntityRelationshipType>OneToMany</EntityRelationshipType><IsCustomizable>1</IsCustomizable><IntroducedVersion>${cfg.version}</IntroducedVersion><IsHierarchical>0</IsHierarchical><ReferencingEntityName>${xe(r.referencing)}</ReferencingEntityName><ReferencedEntityName>${xe(r.referenced)}</ReferencedEntityName>`+
    `<CascadeAssign>NoCascade</CascadeAssign><CascadeDelete>${r.cascade}</CascadeDelete><CascadeArchive>NoCascade</CascadeArchive><CascadeReparent>NoCascade</CascadeReparent><CascadeShare>NoCascade</CascadeShare><CascadeUnshare>NoCascade</CascadeUnshare><CascadeRollupView>NoCascade</CascadeRollupView><IsValidForAdvancedFind>1</IsValidForAdvancedFind><ReferencingAttributeName>${xe(r.attr)}</ReferencingAttributeName>${desc}`+
    `<EntityRelationshipRoles><EntityRelationshipRole><NavPaneDisplayOption>UseCollectionName</NavPaneDisplayOption><NavPaneArea>Details</NavPaneArea><NavPaneOrder>10000</NavPaneOrder><NavigationPropertyName>${xe(r.ln)}</NavigationPropertyName><RelationshipRoleType>1</RelationshipRoleType></EntityRelationshipRole><EntityRelationshipRole><NavigationPropertyName>${xe(r.name)}</NavigationPropertyName><RelationshipRoleType>0</RelationshipRoleType></EntityRelationshipRole></EntityRelationshipRoles></EntityRelationship>`;
}
function solutionFiles(plan){
  const c=plan.cfg, X='<?xml version="1.0" encoding="utf-8"?>\n';
  const addr=n=>`<Address><AddressNumber>${n}</AddressNumber><AddressTypeCode>1</AddressTypeCode>`+['City','County','Country','Fax','FreightTermsCode','ImportSequenceNumber','Latitude','Line1','Line2','Line3','Longitude','Name','PostalCode','PostOfficeBox','PrimaryContactName'].map(k=>`<${k} xsi:nil="true"></${k}>`).join('')+`<ShippingMethodCode>1</ShippingMethodCode>`+['StateOrProvince','Telephone1','Telephone2','Telephone3','TimeZoneRuleVersionNumber','UPSZone','UTCOffset','UTCConversionTimeZoneCode'].map(k=>`<${k} xsi:nil="true"></${k}>`).join('')+`</Address>`;
  const roots=[...plan.newTables.map(T=>`<RootComponent type="1" schemaName="${xe(T.sh.logical)}" behavior="0" />`),...plan.shells.map(T=>`<RootComponent type="1" schemaName="${xe(T.sh.logical)}" behavior="2" />`),
    ...plan.rels.filter(r=>r.shell).map(r=>`<RootComponent type="10" schemaName="${xe(r.name)}" behavior="0" />`),...plan.nn.map(r=>`<RootComponent type="10" schemaName="${xe(r.name)}" behavior="0" />`)];
  const solution=X+`<ImportExportXml version="9.2.0.0" SolutionPackageVersion="9.2" languagecode="1033" generatedBy="CrmLive" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><SolutionManifest><UniqueName>${xe(c.solName)}</UniqueName>${lbl1033('LocalizedNames','LocalizedName',c.solDisplay)}<Descriptions /><Version>${xe(c.version)}</Version><Managed>0</Managed>`+
    `<Publisher><UniqueName>${xe(c.pubName)}</UniqueName>${lbl1033('LocalizedNames','LocalizedName',c.pubDisplay)}<Descriptions /><EMailAddress xsi:nil="true"></EMailAddress><SupportingWebsiteUrl xsi:nil="true"></SupportingWebsiteUrl><CustomizationPrefix>${xe(c.prefix)}</CustomizationPrefix><CustomizationOptionValuePrefix>${+c.optPrefix}</CustomizationOptionValuePrefix><Addresses>${addr(1)}${addr(2)}</Addresses></Publisher>`+
    `<RootComponents>${roots.join('')}</RootComponents><MissingDependencies /></SolutionManifest></ImportExportXml>`;
  const customizations=X+`<ImportExportXml xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" OrganizationVersion="9.2.0.0" OrganizationSchemaType="Standard" CRMServerServiceabilityVersion="9.2.0.0"><Entities>${[...plan.newTables,...plan.shells].map(T=>entityXml(T,c)).join('')}</Entities><Roles /><Workflows /><FieldSecurityProfiles /><Templates /><EntityMaps />`+
    `<EntityRelationships>${[...plan.rels,...plan.nn].map(r=>relXml(r,c)).join('')}</EntityRelationships><OrganizationSettings /><optionsets /><CustomControls /><EntityDataProviders /><Languages><Language>1033</Language></Languages></ImportExportXml>`;
  const types=X+'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/octet-stream" /></Types>';
  return {'[Content_Types].xml':types,'solution.xml':solution,'customizations.xml':customizations};
}
// zipName and c are given for the script in a build zip; without them it is the general script from Export -> Import script
function importScript(zipName,c){
  const what=c?c.solName+' '+c.version:'a solution (.zip)';
  const pick=zipName?`  $SolutionPath = Join-Path $PSScriptRoot '${zipName}'`:`  # the one solution zip in this folder (build zips from the Data Model Explorer are left out)
  $zips = @(Get-ChildItem -Path $PSScriptRoot -Filter *.zip | Where-Object { $_.Name -notlike '* build.zip' })
  if ($zips.Count -ne 1) { throw "Found $($zips.Count) solution zips next to this script. Say which one with -SolutionPath." }
  $SolutionPath = $zips[0].FullName`;
  return `<#
  Imports ${what} into a Dataverse environment with the Power Platform CLI (pac).

  Usage:   .\\import.ps1 -EnvironmentUrl https://yourorg.crm11.dynamics.com
           .\\import.ps1 -EnvironmentUrl https://yourorg.crm11.dynamics.com -Check   # run Microsoft's solution checker first
           .\\import.ps1 -EnvironmentUrl https://yourorg.crm11.dynamics.com -SolutionPath .\\MySolution_1_0_0_0.zip
  ${zipName?'Without -SolutionPath it imports '+zipName+' from this folder.':'Without -SolutionPath it imports the one solution zip in this folder.'}

  If Windows refuses to run a downloaded script, run this once first:   Unblock-File .\\import.ps1

  Needs PowerShell 7 (or Windows PowerShell 5.1) and pac. If pac is missing, it is installed:
  with the .NET SDK when present (dotnet tool install), otherwise with winget on Windows.
  Your account needs the System Customizer or System Administrator role. Import into a development environment first.
#>
param(
  [Parameter(Mandatory = $true)][string]$EnvironmentUrl,
  [string]$SolutionPath,
  [switch]$Check
)
$ErrorActionPreference = 'Stop'
if (-not $SolutionPath) {
${pick}
}
if (-not (Test-Path $SolutionPath)) { throw "Solution file not found: $SolutionPath" }
$solution = (Resolve-Path $SolutionPath).Path
Write-Host "Solution: $solution"

function Test-Pac { [bool](Get-Command pac -ErrorAction SilentlyContinue) }
if (-not (Test-Pac)) {
  Write-Host 'The Power Platform CLI (pac) is not installed. Installing it...'
  if (Get-Command dotnet -ErrorAction SilentlyContinue) {
    dotnet tool install --global Microsoft.PowerApps.CLI.Tool
    $env:PATH += [IO.Path]::PathSeparator + (Join-Path $HOME '.dotnet/tools')
  } elseif (Get-Command winget -ErrorAction SilentlyContinue) {
    winget install --id Microsoft.PowerAppsCLI --exact --accept-source-agreements --accept-package-agreements
    $env:PATH = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
  } else {
    throw 'Install the Power Platform CLI first (https://aka.ms/PowerPlatformCLI), then run this script again.'
  }
  if (-not (Test-Pac)) { throw 'pac was installed but is not available in this window yet. Open a new PowerShell window and run the script again.' }
}

Write-Host "Signing in to $EnvironmentUrl (a browser window opens)..."
pac auth create --environment $EnvironmentUrl
if ($LASTEXITCODE -ne 0) { throw 'Sign-in failed.' }
pac env who

if ($Check) {
  pac solution check --path $solution --outputDirectory (Join-Path (Split-Path $solution) 'check-results')
}

Write-Host 'Importing (this can take a while for a large model)...'
pac solution import --path $solution --publish-changes --async --max-async-wait-time 120
if ($LASTEXITCODE -ne 0) { throw 'The import failed. The messages above say why; nothing was changed.' }

Write-Host ''
Write-Host 'Imported. Next:'
Write-Host '  1. Create the fields in calculated-and-rollup-fields.xlsx by hand (if that file is here).'
Write-Host '  2. Check build-report.csv for anything marked "Not included".'
Write-Host '  3. Run the Dataverse check in the Data Model Explorer against this environment.'
`;
}
async function generateSolution(cfg){
  const plan=buildPlan(cfg); if(!plan.newTables.length&&!plan.shells.length&&!plan.nn.length) return toast('Nothing to build: no tables or fields with the prefix "'+cfg.prefix+'_"');
  const files=solutionFiles(plan), inner=new JSZip(); Object.entries(files).forEach(([n,t])=>inner.file(n,t));
  const ver=cfg.version.replace(/\./g,'_'), innerName=cfg.solName+'_'+ver+'.zip';
  const innerBytes=await inner.generateAsync({type:'uint8array',compression:'DEFLATE'});
  const outer=new JSZip(); outer.file(innerName,innerBytes); outer.file('import.ps1',importScript(innerName,cfg).replace(/\r?\n/g,'\r\n'));
  outer.file('build-report.csv',csv([['Table','Item','What','Action','Detail']].concat(plan.report.map(r=>[r.tbl,r.item,r.what,r.action,r.why]))));
  const mb=plan.tablesOnly?null:await manualWorkbook(); if(mb) outer.file('calculated-and-rollup-fields.xlsx',mb);
  const notIn=plan.report.filter(r=>r.action==='Not included').length, hand=plan.report.filter(r=>r.action==='Build by hand').length;
  outer.file('README.txt',[cfg.solDisplay+' ('+cfg.solName+' '+cfg.version+'), generated '+new Date().toLocaleString()+' from '+S.fileName,'',
    'Contents','  '+innerName+'  the unmanaged solution to import','  import.ps1  signs in with pac and imports it (installs pac if needed)','  build-report.csv  everything included, not included, or to build by hand, and why',(mb?'  calculated-and-rollup-fields.xlsx  fields to create by hand after the import':''),'',
    'What is in the solution',(plan.tablesOnly?'  Tables only: each new table with its primary name column. '+plan.counts.left+' fields and relationships were left out (see build-report.csv).':null),'  '+plan.newTables.length+' new tables, '+plan.shells.length+' existing tables gaining fields, '+plan.fieldCount+' fields, '+plan.rels.length+' one-to-many and '+plan.nn.length+' many-to-many relationships.','  '+plan.counts.auto+' fields are created by Dataverse itself and are not listed. '+notIn+' items are not included and '+hand+' are to build by hand (see build-report.csv).','',
    'Publisher: '+cfg.pubDisplay+' ('+cfg.pubName+'), prefix '+cfg.prefix+', choice value prefix '+cfg.optPrefix+'. If the environment already has this publisher, its unique name must match.','',
    'To import:  .\\import.ps1 -EnvironmentUrl https://yourorg.crm11.dynamics.com','Import into a development environment first. Then export the solution from there as managed for test and production.'].filter(l=>l!==undefined&&l!==null).join('\r\n'));
  const out=await outer.generateAsync({type:'blob',compression:'DEFLATE'});
  download(cfg.solName+'_'+ver+' build.zip',out);
  toast(plan.tablesOnly?'Solution built: '+plan.newTables.length+' new tables, each with its primary name column'+(notIn?' · '+notIn+' not included (see the report)':''):'Solution built: '+plan.newTables.length+' new tables, '+plan.fieldCount+' fields, '+(plan.rels.length+plan.nn.length)+' relationships'+(notIn?' · '+notIn+' not included (see the report)':''));
  return plan;
}
// the dialog: publisher and solution settings, a summary of what will be built, then Generate
function solDialog(){
  const c=solSettings(), m=document.createElement('div'); m.className='convmask'; m.setAttribute('role','dialog'); m.setAttribute('aria-modal','true'); m.setAttribute('aria-label','Build a Dataverse solution');
  const f=(k,label,hint)=>`<label class="solf"><span>${label}</span><input data-k="${k}" value="${esc(c[k])}"><small>${hint||''}</small></label>`;
  m.innerHTML=`<div class="convbox solbox"><h3>Build a Dataverse solution</h3><p class="dim" style="margin:4px 0 12px">Creates an unmanaged solution with your new tables, the fields you add to existing tables, and their relationships, plus a PowerShell script that imports it with pac.</p>
    <div class="solscope" role="radiogroup" aria-label="What to build"><span>What to build</span>
      <label><input type="radio" name="solscope" value="all" ${c.scope!=='tables'?'checked':''}><b>Tables, fields and relationships</b><small>Everything in the workbook with your prefix</small></label>
      <label><input type="radio" name="solscope" value="tables" ${c.scope==='tables'?'checked':''}><b>Tables only</b><small>Each new table with its primary name column; add the rest later</small></label></div>
    <div class="solgrid">${f('solName','Solution unique name')}${f('solDisplay','Solution display name')}${f('version','Version','for example 1.0.0.0')}${f('pubName','Publisher unique name','must match the publisher if it already exists')}${f('pubDisplay','Publisher display name')}${f('prefix','Prefix','tables and fields starting with this are built · <a href="#" data-sol="pubs">Publishers and prefixes</a>')}${f('optPrefix','Choice value prefix','numbering for new choice options')}</div>
    <div class="solsum" id="solsum"></div><div class="solerr" id="solerr"></div>
    <div class="convbtns"><button class="btn ghost" data-sol="ps1" title="Just the PowerShell script, for importing a solution zip you already have" style="margin-right:auto">Import script only</button><button class="btn" data-sol="cancel">Cancel</button> <button class="btn primary" data-sol="go">Generate</button></div></div>`;
  document.body.appendChild(m);
  const read=()=>{const o={}; m.querySelectorAll('[data-k]').forEach(i=>o[i.dataset.k]=i.value.trim()); o.prefix=o.prefix.toLowerCase(); o.scope=(m.querySelector('[name="solscope"]:checked')||{}).value==='tables'?'tables':'all'; return o};
  const summary=()=>{const o=read(), errs=solValidate(o); m.querySelector('#solerr').innerHTML=errs.map(e=>`<div>${esc(e)}</div>`).join('');
    if(errs.length){m.querySelector('#solsum').innerHTML='';return}
    const p=buildPlan(o), n=a=>p.report.filter(r=>r.action===a), notIn=n('Not included'), hand=n('Build by hand');
    m.querySelector('#solsum').innerHTML=p.tablesOnly?`<b>Will be built</b><ul><li>${p.newTables.length} new table${p.newTables.length===1?'':'s'}, each with its primary name column</li><li>${p.counts.left} field${p.counts.left===1?'':'s'} and relationship${p.counts.left===1?'':'s'} left out (listed in build-report.csv)</li></ul>`+
      (notIn.length?`<div style="color:var(--pink)"><b>${notIn.length} not included:</b> ${notIn.slice(0,4).map(r=>esc(r.tbl+' · '+r.item+': '+r.why)).join('; ')}${notIn.length>4?'; …':''}. Full list in build-report.csv.</div>`:''):`<b>Will be built</b><ul><li>${p.newTables.length} new table${p.newTables.length===1?'':'s'}</li><li>${p.shells.length} existing table${p.shells.length===1?'':'s'} gaining your fields</li><li>${p.fieldCount} field${p.fieldCount===1?'':'s'}, ${p.rels.length} one-to-many and ${p.nn.length} many-to-many relationship${p.nn.length===1?'':'s'}</li></ul>`+
      (hand.length?`<div><b>${hand.length}</b> to build by hand (calculated and rollup fields), listed in the download.</div>`:'')+
      (notIn.length?`<div style="color:var(--pink)"><b>${notIn.length} not included:</b> ${notIn.slice(0,4).map(r=>esc(r.tbl+' · '+r.item+': '+r.why)).join('; ')}${notIn.length>4?'; …':''}. Full list in build-report.csv.</div>`:'')};
  {const pi=m.querySelector('[data-k="prefix"]'); pi.setAttribute('list','dme-pfx'); pi.insertAdjacentHTML('afterend',`<datalist id="dme-pfx">${myPubs().map(p=>`<option value="${esc(p.prefix)}">${esc(p.pubDisplay)}</option>`).join('')}</datalist>`);
    // picking one of your prefixes fills in its publisher
    pi.addEventListener('input',()=>{const pub=myPubs().find(p=>p.prefix===pi.value.trim().toLowerCase()); if(pub) [['pubName',pub.pubName],['pubDisplay',pub.pubDisplay],['optPrefix',pub.optPrefix]].forEach(([k,v])=>{if(v!=='') m.querySelector(`[data-k="${k}"]`).value=v})})}
  let t; m.addEventListener('input',()=>{clearTimeout(t);t=setTimeout(summary,250)}); m.addEventListener('change',e=>{if(e.target.name==='solscope') summary()}); summary();
  const close=()=>{document.removeEventListener('keydown',key,true);m.remove()}, key=e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();close()}};
  document.addEventListener('keydown',key,true);
  m.addEventListener('click',async e=>{const b=e.target.closest('[data-sol]'); if(!b){if(e.target===m)close();return}
    if(b.dataset.sol==='cancel') return close();
    if(b.dataset.sol==='ps1') return doExport('ps1');
    if(b.dataset.sol==='pubs'){e.preventDefault(); return pubsDialog(()=>{const pf=read().prefix, pub=myPubs().find(p=>p.prefix===pf); if(pub){[['pubName',pub.pubName],['pubDisplay',pub.pubDisplay],['optPrefix',pub.optPrefix]].forEach(([k,v])=>{if(v!=='') m.querySelector(`[data-k="${k}"]`).value=v})} summary()})}
    const o=read(), errs=solValidate(o); if(errs.length){summary();return}
    store.set(solKey(),o); {const ps=myPubs(), i=ps.findIndex(p=>p.prefix===o.prefix), pub={prefix:o.prefix,pubName:o.pubName,pubDisplay:o.pubDisplay,optPrefix:+o.optPrefix}; if(i>=0) ps[i]=pub; else if(ps.length) ps.push(pub); if(ps.length) store.set('dme.pubs',ps)}
    b.disabled=true; b.textContent='Building…';
    try{await generateSolution(o); close()}catch(err){console.error(err); b.disabled=false; b.textContent='Generate'; m.querySelector('#solerr').textContent='Could not build the solution: '+err.message}
  });
  m.querySelector('[data-k]').focus();
}

/* ---------- Mermaid ERD ---------- */
const SYS_TABLES=new Set(['systemuser','team','businessunit','transactioncurrency','organization','owner','calendar','queue','equipment','role']);
const mid=s=>String(s||'').replace(/[^A-Za-z0-9_]/g,'_').replace(/^(\d)/,'_$1')||'x';
const mq=s=>String(s||'').replace(/["\n\r]/g,' ').replace(/\s+/g,' ').trim();
function lookupTargetsOf(sh,row){
  if(sh.colIdx['Additional data']===undefined) return [];
  return targetsFromText(getVal(sh,row,'Additional data'));
}
// the lookup targets listed in an Additional data cell ("Targets:" followed by logical names), lower-cased
function targetsFromText(text){
  const out=[]; let inT=false;
  String(text||'').split('\n').map(l=>l.trim()).filter(Boolean).forEach(l=>{
    const m=l.match(/^targets?\s*:\s*(.*)$/i);
    if(m){inT=true;m[1].split(/[,;]/).forEach(x=>{x=x.trim();if(x)out.push(x.toLowerCase())});return}
    if(/^[A-Za-z][A-Za-z ]*:/.test(l)){inT=false;return}
    if(inT) out.push(l.toLowerCase());
  });
  return out;
}
function mtype(t){
  const l=String(t||'').toLowerCase();
  if(/lookup|owner|customer|uniqueidentifier/.test(l)) return 'uuid';
  if(/two options|boolean|bool|yes\/no/.test(l)) return 'boolean';
  if(/date/.test(l)) return 'datetime';
  if(/whole|bigint|integer|choice|picklist|state|status|options?$/.test(l)) return 'int';
  if(/decimal|double|float|currency|money/.test(l)) return 'decimal';
  return 'string';
}
const ERD_EASY=30, ERD_BIG=80;   // tables: drawn by default up to EASY; asked before drawing more than BIG
function erdInit(){
  if(S.erd) return S.erd;
  const ui=S.ui.erd||{};
  S.erd={sel:new Set(S.sheets.filter(s=>s.kind==='entity'&&s.custom).map(s=>s.idx)),attrs:ui.attrs||'keys',stubs:ui.stubs!==false,sys:ui.sys!==false,ext:!!ui.ext,rel:ui.rel!==false,dir:ui.dir||'LR',zoom:0,fit:'screen',q:'',src:false,n:0,pos:{},merge:ui.merge!==false,dock:ui.dock||'right',sw:ui.sw||440,sh:ui.sh||260,smax:false,follow:ui.follow!==false,auto:{},prim:new Set(),lbl:ui.lbl||'hover',nn:ui.nn!==false,hide:new Set(ui.hide||[]),relOpen:new Set(),areas:new Set(),acol:!!ui.acol,core:new Set((ui.core||[]).map(x=>String(x).toLowerCase())),optsOpen:!!ui.optsOpen};
  // start small: the custom tables or every table only when that is a readable number, otherwise nothing and a prompt
  {const ents=S.sheets.filter(s=>s.kind==='entity'), cust=ents.filter(s=>s.custom); S.erd.sel=new Set((cust.length&&cust.length<=ERD_EASY?cust:ents.length<=ERD_EASY?ents:[]).map(s=>s.idx))}
  return S.erd;
}
// a relationship hidden from the diagram: 'l:<table>|<lookup field>|<target>' for a lookup, 'n:<relationship name>' for N:N
const erdRk=(sh,row,tg)=>'l:'+(sh.logical+'|'+getVal(sh,row,'Logical Name')+'|'+tg).toLowerCase();
function erdTargets(E,sh,row){
  const out=[];
  lookupTargetsOf(sh,row).forEach(tg=>{
    if(E.sys&&SYS_TABLES.has(tg)) return;
    if(E.hide.size){const k=erdRk(sh,row,tg); if(E.hide.has(k)){if(E.hidSeen){E.hidSeen.add(k); E.hidNodes.add(mid(sh.logical)); E.hidNodes.add(mid(tg))} return}}
    const i=S.byLogical[tg]; const tsh=i!=null?S.sheets[i]:null;
    if(tsh){ if(!E.sel.has(tsh.idx)&&!E.stubs) return }
    else if(!(E.stubs&&E.ext)) return;
    out.push({tg,tsh});
  });
  return out;
}
function buildErd(){
  const E=erdInit(); const stats={tables:0,stubs:0,rels:0,attrs:0};
  const nodes=new Map(); const rels=[]; E.hidSeen=new Set(); E.hidNodes=new Set();
  const node=(key,sh,label)=>{let n=nodes.get(key);if(!n){n={id:mid(key),label:label||key,sh,sel:false};nodes.set(key,n)}return n};
  const sels=S.sheets.filter(s=>s.kind==='entity'&&E.sel.has(s.idx));
  sels.forEach(s=>{node(s.logical,s,s.label).sel=true});
  const seenRel=new Set();
  sels.forEach(s=>{
    const ti=s.colIdx['Attribute Type']; if(ti===undefined) return;
    s.rows.forEach(row=>{
      if(!/lookup|owner|customer/i.test(getVal(s,row,'Attribute Type'))) return;
      const req=/required/i.test(getVal(s,row,'Required Level'))&&!/none|optional|recommended/i.test(getVal(s,row,'Required Level').replace(/required/ig,''));
      const lbl=mq(getVal(s,row,'Display Name')||getVal(s,row,'Logical Name'));
      erdTargets(E,s,row).forEach(({tg,tsh})=>{
        const p=node(tg,tsh,tsh?tsh.label:tg);
        const k=p.id+'>'+mid(s.logical)+'>'+lbl; if(seenRel.has(k)) return; seenRel.add(k);
        rels.push({p:p.id,c:mid(s.logical),lbl,req,unk:!relKnown(s,row,tg)});
      });
    });
  });
  const nnSeen=new Set();
  sels.forEach(s=>s.rows.forEach(row=>{ // N:N rows recorded in the workbook
    if(!isNNRow(s,row)) return; const nm=getVal(s,row,'Logical Name').trim(), tg=lookupTargetsOf(s,row)[0]; if(!nm||!tg||nnSeen.has(nm.toLowerCase())) return;
    if(E.sys&&SYS_TABLES.has(tg)) return; if(E.hide.has('n:'+nm.toLowerCase())){E.hidSeen.add('n:'+nm.toLowerCase()); E.hidNodes.add(mid(s.logical)); E.hidNodes.add(mid(tg)); return} const i=S.byLogical[tg], tsh=i!=null?S.sheets[i]:null;
    if(tsh){if(!E.sel.has(tsh.idx)&&!E.stubs) return} else if(!(E.stubs&&E.ext)) return;
    nnSeen.add(nm.toLowerCase()); const o=node(tg,tsh,tsh?tsh.label:tg); rels.push({p:mid(s.logical),c:o.id,lbl:mq(getVal(s,row,'Display Name')||nm),req:false,nn:true});
  }));
  if(S.dv&&E.nn){ // N:N relationships are not in the workbook; they come from the imported Dataverse metadata
    const seenNN=nnSeen;
    sels.forEach(s=>{const de=S.dv.ents[s.logical]; if(!de) return;
      de.nn.forEach(r=>{
        if(seenNN.has(String(r.schema).toLowerCase())||(E.sys&&SYS_TABLES.has(r.other))) return;
        if(E.hide.has('n:'+String(r.schema).toLowerCase())){E.hidSeen.add('n:'+String(r.schema).toLowerCase()); E.hidNodes.add(mid(s.logical)); E.hidNodes.add(mid(r.other)); return}
        const i=S.byLogical[r.other], tsh=i!=null?S.sheets[i]:null;
        if(tsh){if(!E.sel.has(tsh.idx)&&!E.stubs) return} else if(!(E.stubs&&E.ext)) return;
        seenNN.add(String(r.schema).toLowerCase()); const o=node(r.other,tsh,tsh?tsh.label:r.other);
        rels.push({p:mid(s.logical),c:o.id,lbl:mq(r.schema),req:false,nn:true});
      })});
  }
  const conn=new Set(E.hidNodes); rels.forEach(r=>{conn.add(r.p);conn.add(r.c)});
  if(E.rel) [...nodes.entries()].forEach(([k,n])=>{if(!conn.has(n.id)){nodes.delete(k);stats.hidden=(stats.hidden||0)+1}});
  const L=['erDiagram'];
  if(E.dir==='TB') L.push('  direction TB'); else L.push('  direction LR');
  nodes.forEach(n=>{
    const head=n.id+'["'+mq(n.label)+'"]';
    if(!n.sel||E.attrs==='none'||!n.sh){ L.push('  '+head+' {','  }'); n.sel?stats.tables++:stats.stubs++; return }
    stats.tables++;
    const sh=n.sh; L.push('  '+head+' {'); const seen=new Set(); n.rows=[];
    const pkn=(sh.logical+'id').toLowerCase();
    if(E.attrs==='keys'&&!sh.rows.some(r=>getVal(sh,r,'Logical Name').toLowerCase()===pkn)){L.push('    uuid '+mid(pkn)+' PK'); n.rows.push({k:'PK',name:mid(pkn),type:'uuid',label:''}); stats.attrs++; seen.add(mid(pkn))}
    sh.rows.forEach(row=>{
      const ln=getVal(sh,row,'Logical Name'); if(!ln) return;
      const at=getVal(sh,row,'Attribute Type'); const isL=/lookup|owner|customer/i.test(at);
      const isPK=ln.toLowerCase()===pkOf(sh);
      const drawn=isL&&erdTargets(E,sh,row).length>0;
      const rk=isL?lookupTargetsOf(sh,row).filter(tg=>!(E.sys&&SYS_TABLES.has(tg))).map(tg=>erdRk(sh,row,tg)):[], hid=rk.length>0&&rk.every(k=>E.hide.has(k));
      if(E.attrs==='keys'&&!isPK&&!drawn&&!hid) return;
      const id=mid(ln); if(seen.has(id)) return; seen.add(id);
      if(!hid){L.push('    '+mtype(at)+' '+id+(isPK?' PK':isL?' FK':'')+' "'+mq(getVal(sh,row,'Display Name'))+'"'); stats.attrs++}
      n.rows.push({k:isPK?'PK':isL?'FK':'',name:id,type:mtype(at),label:getVal(sh,row,'Display Name'),rk:(drawn||hid)?rk:null,hid});
    });
    L.push('  }');
  });
  rels.forEach(r=>L.push('  '+r.p+(r.nn?' }o..o{ ':r.unk?' }|--|{ ':r.req?' ||--o{ ':' |o--o{ ')+r.c+' : "'+r.lbl+'"')); stats.rels=rels.length; stats.unk=rels.filter(r=>r.unk).length; E.unkCount=stats.unk;
  const cust=[...nodes.values()].filter(n=>n.sel&&n.sh&&n.sh.custom).map(n=>n.id);
  const oo=[...nodes.values()].filter(n=>!(n.sel&&n.sh&&n.sh.custom)).map(n=>n.id);
  if(E.acol&&hasAreas()){
    // colour by area: border colour from the table's area, thick for custom tables; tables outside the workbook stay plain
    const byCls={}; [...nodes.values()].forEach(n=>{let c='ootb'; if(n.sh){const i=areaList().findIndex(x=>x[0]===areaOf(n.sh)); c='ar'+i+(n.sel&&n.sh.custom?'c':'o')} (byCls[c]=byCls[c]||[]).push(n.id)});
    L.push('  classDef ootb stroke:#667085,stroke-width:1px');
    Object.keys(byCls).filter(c=>c!=='ootb').forEach(c=>{const col=AREA_COLS[+c.slice(2,-1)%AREA_COLS.length]; L.push('  classDef '+c+' stroke:'+col+',stroke-width:'+(c.endsWith('c')?'3px':'2px'))});
    Object.entries(byCls).forEach(([c,ids])=>L.push('  class '+ids.join(',')+' '+c));
  } else {
    L.push('  classDef cust stroke:#BB1C73,stroke-width:3px');
    L.push('  classDef ootb stroke:#0A4873,stroke-width:1px');
    if(cust.length) L.push('  class '+cust.join(',')+' cust');
    if(oo.length) L.push('  class '+oo.join(',')+' ootb');
  }
  stats.hidRels=E.hidSeen.size; E.model={nodes:[...nodes.values()],rels};
  return {src:L.join('\n'),stats};
}
let erdTimer=null;
function erdRefresh(now){clearTimeout(erdTimer);erdTimer=setTimeout(drawErd,now?0:250)}
async function drawErd(){
  const cv=$('#erdcv'); if(!cv) return; const E=erdInit();
  E.relIdx=null; const {src,stats}=buildErd(); E.srcText=src; erdUpdHid(stats.hidRels); erdUpdCount();
  {const lg=$('#erdlegend'); if(lg){ const unkKey=stats.unk?' &nbsp; <span style="display:inline-block;width:22px;border-top:2px solid #98A2B3;vertical-align:3px"></span> Relationship type not recorded – review':''; if(E.acol&&hasAreas()) lg.innerHTML='<span style="margin-right:6px">Areas:</span>'+areaList().map(([a])=>`<span style="display:inline-flex;align-items:center;gap:4px;margin-right:12px"><span style="display:inline-block;width:14px;height:10px;border:3px solid ${areaColour(a)};border-radius:2px"></span>${esc(a)}</span>`).join('')+'<span>Thick border: custom table</span>'+unkKey;
    else lg.innerHTML='<span style="display:inline-block;width:14px;height:10px;border:3px solid #BB1C73;border-radius:2px;vertical-align:-1px"></span> Custom table &nbsp; <span style="display:inline-block;width:14px;height:10px;border:1px solid #0A4873;border-radius:2px;vertical-align:-1px"></span> Out of the box or referenced'+unkKey}}
  const ta=$('#erdsrc'); if(ta&&ta!==document.activeElement) ta.value=src;
  $('#erdinfo').textContent=stats.tables+' tables'+(stats.stubs?' + '+stats.stubs+' referenced':'')+' · '+stats.rels+' relationships'+(E.attrs!=='none'?' · '+stats.attrs+' attributes':'')+(stats.hidRels?' · '+stats.hidRels+' hidden by you':'')+(stats.hidden?' · '+stats.hidden+' unrelated hidden':'')+(stats.unk?' · '+stats.unk+' of '+stats.rels+' relationships have no recorded type (plain lines)':'');
  if(!E.sel.size){const n=S.sheets.filter(s=>s.kind==='entity').length; cv.innerHTML=`<div class="msg" style="max-width:520px"><b>Pick the tables to draw.</b><br>Tick tables on the left, filter them (for example by prefix), or click ★ next to a table to build the diagram around it.${n>ERD_EASY?` With ${n} tables in this workbook, a few dozen at a time is easiest to read.`:''}</div>`;E.svg='';return}
  const my=++E.n;
  // a big diagram takes a moment to lay out: say so first, so the page doesn't look stuck
  if(E.model.nodes.length>60){cv.innerHTML='<div class="msg">Laying out '+E.model.nodes.length+' tables and '+stats.rels+' relationships…</div>'; await new Promise(r=>setTimeout(r,30)); if(my!==E.n) return}
  try{ erdRender(cv,E) }
  catch(err){ E.svg=''; cv.innerHTML='<div class="err">The diagram could not be drawn:\n'+esc(String(err&&err.message||err))+'\n\nTry fewer tables or "Names only". The Mermaid source below is still valid to copy.</div>' }
}
/* ------- drawing: the diagram is drawn straight from E.model as SVG (no Mermaid layout), then laid out and wired ------- */
const ERD_FONT='Aptos,"Segoe UI",Arial,sans-serif', ERD_HD=34, ERD_RH=24;
let erdCtx=null; const erdTWc=new Map();
function erdTW(t,font){const k=font+'\u0001'+t; let w=erdTWc.get(k); if(w===undefined){ if(!erdCtx) erdCtx=document.createElement('canvas').getContext('2d'); erdCtx.font=font; w=erdCtx.measureText(t).width; if(erdTWc.size>60000) erdTWc.clear(); erdTWc.set(k,w)} return w}
const erdX=s=>String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
// the look of one table box: border colour and width as the Mermaid classes in the source say
function erdStroke(E,n){
  if(E.acol&&hasAreas()){ if(!n.sh) return ['#667085',1]; const i=areaList().findIndex(x=>x[0]===areaOf(n.sh)); const c=n.sel&&n.sh.custom; return [AREA_COLS[Math.max(0,i)%AREA_COLS.length],c?3:2] }
  return n.sel&&n.sh&&n.sh.custom?['#BB1C73',3]:['#0A4873',1];
}
// an eye that shows or hides the relationship(s) in `keys`; crossed out when they are hidden
function erdEye(x,y,keys,hid,what){
  const c=hid?'#B54708':'#5f7a90';
  return '<g class="eyebtn'+(hid?' off':'')+'" data-rk="'+erdX(keys.join(' '))+'" role="button" tabindex="0" aria-pressed="'+(!hid)+'" aria-label="'+erdX((hid?'Show ':'Hide ')+what)+'" transform="translate('+x+','+y+')"><title>'+erdX((hid?'Hidden: click to show ':'Click to hide ')+what)+'</title>'+
    '<rect x="-12" y="-10" width="24" height="20" rx="6" fill="#FFFFFF" fill-opacity=".01"/><path d="M-8,0C-5,-5.5 5,-5.5 8,0C5,5.5 -5,5.5 -8,0Z" fill="none" stroke="'+c+'" stroke-width="1.6"/><circle r="2.4" fill="'+c+'"/>'+
    (hid?'<path d="M-8,-6.5L8,6.5" stroke="'+c+'" stroke-width="1.8"/>':'')+'</g>';
}
function erdBox(E,n,i){
  const HF='bold 15px '+ERD_FONT, RF='13px '+ERD_FONT, P=10;
  const [stroke,sw]=erdStroke(E,n);
  let rows=n.rows||[];
  // N:N relationships have no field row of their own: they get a row in the box, so they have an eye too
  if(rows.length&&n.sh){
    const nn=erdRelsOf(n.sh).filter(r=>r.dir==='nn'&&(E.hide.has(r.k)||(r.ol&&E.nodeIds&&E.nodeIds.has(mid(r.ol)))));
    rows=rows.concat(nn.map(r=>({k:'N:N',name:r.txt,type:'',label:'↔ '+r.other,rk:[r.k],hid:E.hide.has(r.k)})));
  }
  const rowEyes=rows.some(r=>r.rk);
  // Names only: one eye in the header, for all of this table's own relationships
  const own=(!rows.length&&n.sh)?erdRelsOf(n.sh).filter(r=>r.dir!=='in').map(r=>r.k):[], headEye=own.length>0, headHid=headEye&&own.every(k=>E.hide.has(k));
  let w=Math.max(120,erdTW(n.label,HF)+36+(headEye?56:0)), cols=null;
  if(rows.length){
    cols=[0,0,0,0]; rows.forEach(r=>{cols[0]=Math.max(cols[0],erdTW(r.type,RF));cols[1]=Math.max(cols[1],erdTW(r.name,RF));cols[2]=Math.max(cols[2],r.k?erdTW(r.k,'bold 12px '+ERD_FONT):0);cols[3]=Math.max(cols[3],erdTW(r.label||'',RF))});
    const inner=cols.reduce((s,c)=>s+(c?c+2*P:0),0)+(rowEyes?28:0); w=Math.max(w,inner);
  }
  const h=rows.length?ERD_HD+rows.length*ERD_RH:44, x0=-w/2, y0=-h/2;
  const o=['<g class="node" id="erd-entity-'+erdX(n.id)+'-'+i+'" data-k="'+i+'" transform="translate(0,0)">',
    '<rect x="'+x0+'" y="'+y0+'" width="'+w+'" height="'+h+'" rx="3" fill="#FFFFFF"/>'];
  const eyes=[];
  if(rows.length){
    o.push('<rect x="'+x0+'" y="'+y0+'" width="'+w+'" height="'+ERD_HD+'" fill="#E3ECF4"/>');
    o.push('<text x="0" y="'+(y0+ERD_HD/2+5)+'" text-anchor="middle" font-family="'+erdX(ERD_FONT)+'" font-size="15" font-weight="bold" fill="#0A4873">'+erdX(n.label)+'</text>');
    rows.forEach((r,j)=>{
      const y=y0+ERD_HD+j*ERD_RH; if(j%2) o.push('<rect x="'+x0+'" y="'+y+'" width="'+w+'" height="'+ERD_RH+'" fill="#F4F7FA"/>');
      o.push('<g class="erow'+(r.hid?' hid':'')+'">');
      let x=x0, ty=y+ERD_RH/2+4.5; const col=(t,c,extra)=>{ if(!c) return; o.push('<text x="'+(x+P)+'" y="'+ty+'" font-family="'+erdX(ERD_FONT)+'" font-size="'+(extra?12:13)+'"'+(extra?' font-weight="bold"':'')+' fill="'+(extra&&(t==='FK'||t==='N:N')?'#BB1C73':'#0A4873')+'">'+erdX(t)+'</text>'); x+=c+2*P };
      col(r.type,cols[0]); col(r.name,cols[1]); col(r.k||'',cols[2],1); col(r.label||'',cols[3]);
      o.push('</g>');
      if(r.rk) eyes.push(erdEye(x0+w-16,y+ERD_RH/2,r.rk,r.hid,'the relationship '+(r.label||r.name)+(r.k==='N:N'?'':' ('+r.name+')')));
    });
    o.push('<line x1="'+x0+'" y1="'+(y0+ERD_HD)+'" x2="'+(x0+w)+'" y2="'+(y0+ERD_HD)+'" stroke="'+stroke+'" stroke-width="1"/>');
  } else o.push('<text x="'+(headEye?-14:0)+'" y="5" text-anchor="middle" font-family="'+erdX(ERD_FONT)+'" font-size="15" font-weight="bold" fill="#0A4873">'+erdX(n.label)+'</text>');
  o.push('<rect x="'+x0+'" y="'+y0+'" width="'+w+'" height="'+h+'" rx="3" fill="none" stroke="'+stroke+'" stroke-width="'+sw+'"/>');
  if(headEye) eyes.push(erdEye(x0+w-20,0,own,headHid,"this table's own relationships (its lookups and N:N)"));
  o.push(eyes.join('')+'</g>');
  return {html:o.join(''),w,h};
}
// line ends: crow's foot notation, a separate marker for each end so exported SVG works in any viewer
const ERD_DEFS='<defs>'+
  '<marker id="erdm-many-e" viewBox="0 -10 22 20" refX="22" refY="0" markerWidth="22" markerHeight="20" markerUnits="userSpaceOnUse" orient="auto"><path d="M12,0L22,-8M12,0L22,0M12,0L22,8" fill="none" stroke="#0A4873" stroke-width="1.4"/><circle cx="7" cy="0" r="4" fill="#fff" stroke="#0A4873" stroke-width="1.4"/></marker>'+
  '<marker id="erdm-many-s" viewBox="0 -10 22 20" refX="0" refY="0" markerWidth="22" markerHeight="20" markerUnits="userSpaceOnUse" orient="auto"><path d="M10,0L0,-8M10,0L0,0M10,0L0,8" fill="none" stroke="#0A4873" stroke-width="1.4"/><circle cx="15" cy="0" r="4" fill="#fff" stroke="#0A4873" stroke-width="1.4"/></marker>'+
  '<marker id="erdm-one-s" viewBox="0 -10 22 20" refX="0" refY="0" markerWidth="22" markerHeight="20" markerUnits="userSpaceOnUse" orient="auto"><path d="M5,-8L5,8M10,-8L10,8" fill="none" stroke="#0A4873" stroke-width="1.4"/></marker>'+
  '<marker id="erdm-zone-s" viewBox="0 -10 22 20" refX="0" refY="0" markerWidth="22" markerHeight="20" markerUnits="userSpaceOnUse" orient="auto"><path d="M5,-8L5,8" fill="none" stroke="#0A4873" stroke-width="1.4"/><circle cx="13" cy="0" r="4" fill="#fff" stroke="#0A4873" stroke-width="1.4"/></marker>'+
  '</defs>';
function erdRender(cv,E){
  const M=E.model; E.nodeIds=new Set(M.nodes.map(n=>n.id)); const nodes=M.nodes.map((n,i)=>{const b=erdBox(E,n,i); return {m:n,i,html:b.html,w:b.w,h:b.h,key:n.id.toLowerCase(),name:n.id.toLowerCase(),ox:0,oy:0,cx:0,cy:0,core:E.core.has(n.id.toLowerCase())}});
  const byId=new Map(nodes.map(n=>[n.m.id,n]));
  // one line per relationship, or one per pair of tables and direction when merging (names joined)
  const groups=new Map(); M.rels.forEach(r=>{const a=byId.get(r.p), b=byId.get(r.c); if(!a||!b) return; const k=(E.merge&&a!==b)?([a.i,b.i].sort((x,y)=>x-y).join('|')+'|'+a.i+(r.nn?'|nn':'')+(r.unk?'|unk':'')):'r'+groups.size; (groups.get(k)||groups.set(k,[]).get(k)).push(r)});
  const edges=[]; groups.forEach(g=>{const r=g[0]; edges.push({a:byId.get(r.p),b:byId.get(r.c),nn:!!r.nn,unk:!!r.unk,req:g.some(q=>q.req),txt:[...new Set(g.map(q=>q.txt||q.lbl))].join(' · ')})});
  const out=['<svg xmlns="http://www.w3.org/2000/svg" class="erdsvg lbl-'+E.lbl+'" font-family="'+erdX(ERD_FONT)+'">',ERD_DEFS,'<g class="edges">'];
  edges.forEach((e,i)=>{
    const st=e.unk?'':' marker-start="url(#erdm-'+(e.nn?'many':e.req?'one':'zone')+'-s)" marker-end="url(#erdm-many-e)"';
    out.push('<path class="rl'+(e.unk?' erdunk':'')+'" data-e="'+i+'" fill="none" stroke="'+(e.unk?'#98A2B3':'#0A4873')+'" stroke-width="1.5"'+(e.nn?' stroke-dasharray="6 4"':'')+st+'><title>'+erdX(e.txt)+'</title></path>');
  });
  out.push('</g><g class="arrows"></g><g class="nodes">'); nodes.forEach(n=>out.push(n.html)); out.push('</g><g class="labels">');
  edges.forEach((e,i)=>{const w=erdTW(e.txt,'12px '+ERD_FONT)+12; out.push('<g class="lab" data-e="'+i+'"><rect x="'+(-w/2)+'" y="-10" width="'+w+'" height="20" rx="4" fill="#FFFFFF" fill-opacity=".92"/><text x="0" y="4" text-anchor="middle" font-size="12" fill="#0A4873">'+erdX(e.txt)+'</text></g>')});
  out.push('</g></svg>');
  cv.innerHTML=out.join('');
  const s=cv.querySelector('svg');
  const gs=s.querySelectorAll('g.nodes > g.node'); nodes.forEach((n,i)=>{n.g=gs[i]; n.g.style.cursor='grab'; if(n.core) n.g.style.filter='drop-shadow(0 0 7px rgba(232,163,23,.9))'});
  const ps=s.querySelectorAll('g.edges > path'), ls=s.querySelectorAll('g.labels > g.lab'); edges.forEach((e,i)=>{e.p=ps[i]; e.lab=ls[i]; e.parA=true});
  erdWire(E,s,nodes,edges);
}
function erdWire(E,s,nodes,edges){
  const cv=$('#erdcv'), arrG=s.querySelector('g.arrows');
  const inc=new Map(nodes.map(n=>[n,[]])); edges.forEach(e=>{inc.get(e.a).push(e); if(e.b!==e.a) inc.get(e.b).push(e)});
  // parallel lines between the same two tables are spaced apart; that order never changes, so work it out once
  const cnt={}; edges.forEach(e=>{if(e.a!==e.b){e.pk=Math.min(e.a.i,e.b.i)+'|'+Math.max(e.a.i,e.b.i); cnt[e.pk]=(cnt[e.pk]||0)+1; e.k2=cnt[e.pk]-1}});
  const loopIdx=new Map(); edges.forEach(e=>{if(e.a===e.b){const l=loopIdx.get(e.a)||0; e.li=l; loopIdx.set(e.a,l+1)}});
  const move=(n,cx,cy)=>{n.cx=cx;n.cy=cy;n.g.setAttribute('transform','translate('+cx+','+cy+')')};
  const route=e=>{
    const {a,b}=e;
    if(a===b){const rx=a.cx+a.w/2, y0=a.cy-a.h/2+22+e.li*34, o=56+e.li*10;
      e.p.setAttribute('d','M'+rx+','+y0+'C'+(rx+o)+','+(y0-14)+','+(rx+o)+','+(y0+26)+','+rx+','+(y0+12)); e.lab.setAttribute('transform','translate('+(rx+o+4+e.lab.firstChild.width.baseVal.value/2)+','+(y0+6)+')');
      if(e.arr) e.arr.setAttribute('d',''); return}
    const dx=b.cx-a.cx, dy=b.cy-a.cy, off=(e.k2-(cnt[e.pk]-1)/2)*14; let P;
    if(Math.abs(dx)*a.h>=Math.abs(dy)*a.w*.6&&Math.abs(dx)>(a.w+b.w)/2*.6){
      const sg=dx>=0?1:-1, sx=a.cx+sg*a.w/2, tx=b.cx-sg*b.w/2, sy=a.cy+Math.max(-a.h/2+8,Math.min(a.h/2-8,off)), ty=b.cy+Math.max(-b.h/2+8,Math.min(b.h/2-8,off)), c=(sx+tx)/2;
      P=[[sx,sy],[c,sy],[c,ty],[tx,ty]];
    }else{
      const sg=dy>=0?1:-1, sy=a.cy+sg*a.h/2, ty=b.cy-sg*b.h/2, sx=a.cx+Math.max(-a.w/2+8,Math.min(a.w/2-8,off)), tx=b.cx+Math.max(-b.w/2+8,Math.min(b.w/2-8,off)), c=(sy+ty)/2;
      P=[[sx,sy],[sx,c],[tx,c],[tx,ty]];
    }
    e.p.setAttribute('d','M'+P[0]+'C'+P[1]+','+P[2]+','+P[3]);
    const bz=u=>{const m=1-u;return [0,1].map(i=>m*m*m*P[0][i]+3*m*m*u*P[1][i]+3*m*u*u*P[2][i]+u*u*u*P[3][i])};
    const md=bz(.5); e.lab.setAttribute('transform','translate('+md[0]+','+md[1]+')');
    if(e.nn||e.unk){if(e.arr)e.arr.setAttribute('d','');return} // many-to-many or type unknown: no direction arrow
    const p1=bz(.45),p2=bz(.55); let ux=p2[0]-p1[0],uy=p2[1]-p1[1]; const ln=Math.hypot(ux,uy)||1; ux/=ln;uy/=ln; ux=-ux;uy=-uy; // points to the table looked up
    const mx=md[0],my=md[1],L=11,Wd=6; if(!e.arr){e.arr=document.createElementNS('http://www.w3.org/2000/svg','path');e.arr.setAttribute('fill','#0A4873');e.arr.setAttribute('class','erdarr');e.arr.style.pointerEvents='none';arrG.appendChild(e.arr)}
    e.arr.setAttribute('d','M'+(mx+ux*L/2)+','+(my+uy*L/2)+'L'+(mx-ux*L/2-uy*Wd)+','+(my-uy*L/2+ux*Wd)+'L'+(mx-ux*L/2+uy*Wd)+','+(my-uy*L/2-ux*Wd)+'Z');
  };
  // hover: only the lines of the tables under the pointer change; the rest are dimmed by one class on the diagram
  let hot=[];
  const vis=focus=>{
    hot.forEach(e=>{e.p.classList.remove('hot'); e.lab.classList.remove('hot'); if(e.arr) e.arr.classList.remove('hot')}); hot=[];
    s.setAttribute('class','erdsvg lbl-'+E.lbl+(focus?' focus':''));
    if(focus) focus.forEach(n=>inc.get(n).forEach(e=>{e.p.classList.add('hot'); e.lab.classList.add('hot'); if(e.arr) e.arr.classList.add('hot'); hot.push(e)}));
  };
  const bbox=()=>{let x0=1e12,y0=1e12,x1=-1e12,y1=-1e12; nodes.forEach(n=>{x0=Math.min(x0,n.cx-n.w/2);y0=Math.min(y0,n.cy-n.h/2);x1=Math.max(x1,n.cx+n.w/2+(loopIdx.has(n)?90:0));y1=Math.max(y1,n.cy+n.h/2)}); return {x:x0,y:y0,width:x1-x0,height:y1-y0}};
  E.bbox=bbox;
  const fit=init=>{
    const m0=s.getScreenCTM(); if(!init&&!E.zoom&&m0) E.zoom=m0.a; // freeze the zoom once you start moving things
    const bb=bbox(), pad=24; s.setAttribute('viewBox',(bb.x-pad)+' '+(bb.y-pad)+' '+(bb.width+pad*2)+' '+(bb.height+pad*2));
    erdZoom(E.zoom,true,init);
    if(!init&&m0){const m1=s.getScreenCTM(); if(m1){cv.scrollLeft+=m1.e-m0.e; cv.scrollTop+=m1.f-m0.f}}
  };
  const src=(E.srcText||'')+'|core:'+[...E.core].sort().join(','); let h=5381; for(let i=0;i<src.length;i++) h=((h<<5)+h+src.charCodeAt(i))|0;
  const pkey='p'+(h>>>0).toString(36), all=store.get('dme.erdpos')||{};
  const persist=()=>{all[pkey]=E.pos; const ks=Object.keys(all); if(ks.length>12) delete all[ks[0]]; store.set('dme.erdpos',all)};
  E.pos=all[pkey]||(E.keepPos?{...E.keepPos}:{}); E.keepPos=null;
  if(!nodes.every(n=>E.pos[n.name])){ erdAutoLayout(nodes,edges.filter(e=>e.a!==e.b).map(e=>[e.a,e.b])); nodes.forEach(n=>{E.pos[n.name]=[n.cx,n.cy]}); persist() }
  nodes.forEach(n=>move(n,E.pos[n.name][0],E.pos[n.name][1]));
  edges.forEach(route); vis(null); E.applyVis=()=>vis(null);
  fit(true);
  E.svgEl=s;
  let drag=null, raf=0;
  const scale=()=>{const m=s.getScreenCTM(); return m?m.a:1};
  const nodeOf=t=>{const g=t&&t.closest&&t.closest('g.node'); return g?nodes[+g.dataset.k]:null};
  s.addEventListener('pointerdown',ev=>{
    if(ev.button!==0) return; if(ev.target.closest&&ev.target.closest('.eyebtn')) return; const n=nodeOf(ev.target);
    drag=n?{n,x:ev.clientX,y:ev.clientY,cx:n.cx,cy:n.cy,sc:scale()}:{pan:1,x:ev.clientX,y:ev.clientY,sl:cv.scrollLeft,st:cv.scrollTop};
    if(n){n.g.parentNode.appendChild(n.g);n.g.style.cursor='grabbing'} else cv.style.cursor='grabbing';
    try{s.setPointerCapture(ev.pointerId)}catch(_){} ev.preventDefault();
  });
  s.addEventListener('pointermove',ev=>{
    if(!drag) return;
    if(drag.pan){cv.scrollLeft=drag.sl-(ev.clientX-drag.x);cv.scrollTop=drag.st-(ev.clientY-drag.y);return}
    drag.tx=drag.cx+(ev.clientX-drag.x)/drag.sc; drag.ty=drag.cy+(ev.clientY-drag.y)/drag.sc;
    if(!raf) raf=requestAnimationFrame(()=>{raf=0; if(!drag||drag.pan) return; move(drag.n,drag.tx,drag.ty); inc.get(drag.n).forEach(route)}); // only the moved table's lines, once per frame
  });
  s.addEventListener('pointerover',ev=>{if(drag&&!drag.pan) return; const n=nodeOf(ev.target); if(n) vis(new Set([n]))});
  s.addEventListener('pointerout',ev=>{if(drag&&!drag.pan) return; const g=ev.target.closest&&ev.target.closest('g.node'); if(g&&!(ev.relatedTarget&&g.contains(ev.relatedTarget))) vis(null)});
  const end=ev=>{
    if(!drag) return; const d=drag; drag=null; cv.style.cursor='';
    if(d.pan) return; if(raf){cancelAnimationFrame(raf);raf=0} if(d.tx!=null){move(d.n,d.tx,d.ty); inc.get(d.n).forEach(route)}
    d.n.g.style.cursor='grab'; E.pos[d.n.name]=[d.n.cx,d.n.cy]; persist(); fit(false);
    const under=document.elementFromPoint(ev.clientX,ev.clientY); const un=nodeOf(under); vis(un===d.n?new Set([d.n]):null);
  };
  s.addEventListener('pointerup',end); s.addEventListener('pointercancel',end);
  const toggle=b=>{const ks=b.dataset.rk.split(' ').filter(Boolean), allHid=ks.every(k=>E.hide.has(k)); ks.forEach(k=>allHid?E.hide.delete(k):E.hide.add(k)); E.focusRk=b.dataset.rk; erdHidChanged()};
  s.addEventListener('click',ev=>{const b=ev.target.closest&&ev.target.closest('.eyebtn'); if(b){ev.stopPropagation(); toggle(b)}});
  s.addEventListener('keydown',ev=>{const b=ev.target.closest&&ev.target.closest('.eyebtn'); if(b&&(ev.key==='Enter'||ev.key===' ')){ev.preventDefault(); toggle(b)}});
  if(E.focusRk){const b=[...s.querySelectorAll('.eyebtn')].find(x=>x.dataset.rk===E.focusRk); E.focusRk=null; if(b) b.focus({preventScroll:true})}
}
function erdAutoLayout(nodes,links){
  const N=nodes.length; if(N<2) return;
  const cores=nodes.filter(n=>n.core); const dg=new Map(nodes.map(n=>[n,Math.hypot(n.w,n.h)/2])); const diag=n=>dg.get(n);
  const deg=new Map(nodes.map(n=>[n,0])); links.forEach(([a,b])=>{deg.set(a,deg.get(a)+1);deg.set(b,deg.get(b)+1)});
  // unique pairs with their number of lines, and each table's neighbours (looked up once, not searched for every time)
  const pm=new Map(); links.forEach(([a,b])=>{const [x,y]=a.key<b.key?[a,b]:[b,a]; const k=x.key+'|'+y.key; const u=pm.get(k); if(u) u[2]++; else pm.set(k,[x,y,1])});
  const uniq=[...pm.values()];
  const adj=new Map(nodes.map(n=>[n,[]])); uniq.forEach(([a,b])=>{adj.get(a).push(b);adj.get(b).push(a)}); const nb=n=>adj.get(n);
  // BFS from the core tables (or, with none, from the most connected table)
  const roots=cores.length?cores:[...nodes].sort((a,b)=>deg.get(b)-deg.get(a));
  const seen=new Set(), lvl=new Map(), par=new Map(); let q=[];
  const run=()=>{for(let h=0;h<q.length;h++){const c=q[h]; nb(c).forEach(o=>{if(!seen.has(o)){seen.add(o);lvl.set(o,lvl.get(c)+1);par.set(o,c);q.push(o)}})} q=[]};
  const bfs=r=>{ if(seen.has(r)) return; seen.add(r); lvl.set(r,0); q=[r]; run() };
  if(cores.length){ cores.forEach(r=>{seen.add(r);lvl.set(r,0)}); q=[...cores]; run(); nodes.forEach(n=>{if(!seen.has(n)) bfs(n)}) } else roots.forEach(bfs);
  const R0=Math.sqrt(nodes.reduce((s,n)=>s+n.w*n.h,0))*.9;
  if(cores.length){
    // core tables form a tight group in the middle; everything else sits on rings around that group
    const gap=150+4*N; const tot=cores.reduce((s,n)=>s+n.w,0)+gap*(cores.length-1); let x=-tot/2;
    cores.forEach(n=>{n.cx=x+n.w/2; n.cy=0; x+=n.w+gap});
    const ext=Math.max(tot/2,Math.max(...cores.map(n=>n.h))/2), maxd=Math.max(...nodes.map(diag));
    const base=ext+maxd+160+8*N, step=maxd*1.6+160;
    const byL={}; nodes.forEach(n=>{if(n.core) return; const l=lvl.get(n)||1; (byL[l]=byL[l]||[]).push(n)});
    const ci=n=>{let p=n; while(par.has(p)) p=par.get(p); return Math.max(0,cores.indexOf(p))};
    Object.keys(byL).map(Number).sort((a,b)=>a-b).forEach(l=>{
      const g=byL[l].sort((a,b)=>ci(a)-ci(b)||(par.get(a)&&par.get(b)?(a.pAng||0)-(b.pAng||0):0)||a.key.localeCompare(b.key));
      g.forEach((n,i)=>{const ang=Math.PI/2+(i/g.length)*Math.PI*2; n.pAng=ang; n.ring=base+(l-1)*step; n.cx=Math.cos(ang)*n.ring*1.35; n.cy=Math.sin(ang)*n.ring})});
    }else{
    const byL={}; nodes.forEach(n=>{(byL[lvl.get(n)]=byL[lvl.get(n)]||[]).push(n)});
    Object.keys(byL).forEach(l=>{const g=byL[l]; g.forEach((n,i)=>{const ang=(i/g.length)*Math.PI*2+l*.6; const r=l==0?0:R0*(.5+.5*l); n.cx=Math.cos(ang)*r*1.3; n.cy=Math.sin(ang)*r})});
  }
  // forces, on plain arrays (same model as before; much less work per step)
  const X=new Float64Array(N), Y=new Float64Array(N), D=new Float64Array(N), FX=new Float64Array(N), FY=new Float64Array(N), core=nodes.map(n=>!!n.core), idx=new Map(nodes.map((n,i)=>[n,i]));
  nodes.forEach((n,i)=>{X[i]=n.cx;Y[i]=n.cy;D[i]=diag(n)});
  const U=uniq.map(([a,b,m])=>[idx.get(a),idx.get(b),m]), ring=nodes.map(n=>n.ring||0), REP=40000*(1+N/12), LL=70+6*N;
  const ITER=N>150?300:500;
  for(let it=0;it<ITER;it++){
    const t=1-it/ITER, rf=Math.min(1,.4+t); FX.fill(0); FY.fill(0);
    for(let i=0;i<N;i++){const xi=X[i],yi=Y[i],di=D[i]; for(let j=i+1;j<N;j++){
      const dx=X[j]-xi, dy=Y[j]-yi, d=Math.sqrt(dx*dx+dy*dy)||1; const gap=Math.max(1,d-di-D[j]); const rep=REP/(gap*gap+400)*rf;
      const fx=dx/d*rep, fy=dy/d*rep; FX[i]-=fx;FY[i]-=fy;FX[j]+=fx;FY[j]+=fy }}
    for(const [a,b,m] of U){
      const dx=X[b]-X[a], dy=Y[b]-Y[a], d=Math.sqrt(dx*dx+dy*dy)||1; const L=D[a]+D[b]+LL;
      const k=.04*(1+Math.min(2,m-1)*.5)*(d-L); const fx=dx/d*k, fy=dy/d*k; FX[a]+=fx;FY[a]+=fy;FX[b]-=fx;FY[b]-=fy }
    if(cores.length) for(let i=0;i<N;i++){if(core[i]||!ring[i]) continue; const d=Math.hypot(X[i],Y[i])||1, k=.05*(ring[i]-d); FX[i]+=X[i]/d*k; FY[i]+=Y[i]/d*k}
    const cap=60*t+4;
    for(let i=0;i<N;i++){if(core[i]) continue; const m=Math.hypot(FX[i],FY[i])||1; const s=Math.min(1,cap/m); X[i]+=FX[i]*s-(cores.length?0:X[i]*.004); Y[i]+=FY[i]*s-(cores.length?0:Y[i]*.004)}
  }
  nodes.forEach((n,i)=>{n.cx=X[i];n.cy=Y[i]});
  const sep=()=>{ for(let p=0;p<200;p++){let any=false;
    for(let i=0;i<N;i++)for(let j=i+1;j<N;j++){
      const a=nodes[i],b=nodes[j]; const ox=(a.w+b.w)/2+60-Math.abs(b.cx-a.cx), oy=(a.h+b.h)/2+60-Math.abs(b.cy-a.cy);
      if(ox>0&&oy>0){any=true; const wa=a.core?0:(b.core?1:.5), wb=b.core?0:(a.core?1:.5);
        if(ox<oy){const s=b.cx>=a.cx?1:-1;a.cx-=s*ox*wa;b.cx+=s*ox*wb}else{const s=b.cy>=a.cy?1:-1;a.cy-=s*oy*wa;b.cy+=s*oy*wb}}
    }
    if(!any) break} };
  sep();
  erdAnneal(nodes,uniq.map(u=>[u[0],u[1]]));
  // Direction: left to right turns a layout that came out tall on its side; top to bottom does the opposite
  const x0=Math.min(...nodes.map(n=>n.cx-n.w/2)), x1=Math.max(...nodes.map(n=>n.cx+n.w/2)), y0=Math.min(...nodes.map(n=>n.cy-n.h/2)), y1=Math.max(...nodes.map(n=>n.cy+n.h/2));
  const W=x1-x0, H=y1-y0, dir=erdInit().dir;
  if(dir!=='TB'&&H>W*1.15){ nodes.forEach(n=>{const x=n.cx; n.cx=n.cy*1.4; n.cy=-x/1.4}); sep() }
  else if(dir==='TB'&&W>H*1.15){ nodes.forEach(n=>{const x=n.cx; n.cx=n.cy/1.4; n.cy=-x*1.4}); sep() }
}
function erdAnneal(nodes,pairs){
  // refinement: move tables to reduce crossing lines and lines running through other tables.
  // Only the cost that a move changes is worked out (the lines and boxes of the moved tables), not the whole diagram again.
  const N=nodes.length, P=pairs.length; if(N<4||!P) return;
  let seed=12345; const rnd=()=>{seed|=0;seed=seed+0x6D2B79F5|0;let x=Math.imul(seed^seed>>>15,1|seed);x=x+Math.imul(x^x>>>7,61|x)^x;return((x^x>>>14)>>>0)/4294967296};
  const gauss=()=>(rnd()+rnd()+rnd()-1.5)*1.6;
  const ccw=(ax,ay,bx,by,cx,cy)=>(cy-ay)*(bx-ax)>(by-ay)*(cx-ax);
  const cross=(p,q,r,s)=>{ if(p===r||p===s||q===r||q===s) return false; return ccw(p.cx,p.cy,r.cx,r.cy,s.cx,s.cy)!==ccw(q.cx,q.cy,r.cx,r.cy,s.cx,s.cy)&&ccw(p.cx,p.cy,q.cx,q.cy,r.cx,r.cy)!==ccw(p.cx,p.cy,q.cx,q.cy,s.cx,s.cy)};
  const through=(a,b,n)=>{ // segment a-b against the box of n (with a margin)
    const x0=n.cx-n.w/2-12,x1=n.cx+n.w/2+12,y0=n.cy-n.h/2-12,y1=n.cy+n.h/2+12;
    if((a.cx<x0&&b.cx<x0)||(a.cx>x1&&b.cx>x1)||(a.cy<y0&&b.cy<y0)||(a.cy>y1&&b.cy>y1)) return false; // quick no: both ends on one side
    let t0=0,t1=1; const dx=b.cx-a.cx,dy=b.cy-a.cy;
    const clip=(p,q)=>{ if(p===0) return q>=0; const r=q/p; if(p<0){if(r>t1) return false; if(r>t0) t0=r}else{if(r<t0) return false; if(r<t1) t1=r} return true };
    return clip(-dx,a.cx-x0)&&clip(dx,x1-a.cx)&&clip(-dy,a.cy-y0)&&clip(dy,y1-a.cy)&&t1>t0};
  const ov=(a,b)=>{const ox=(a.w+b.w)/2+50-Math.abs(a.cx-b.cx), oy=(a.h+b.h)/2+50-Math.abs(a.cy-b.cy); return ox>0&&oy>0?400+ox+oy:0};
  const byNode=new Map(nodes.map(n=>[n,[]])); pairs.forEach((p,i)=>{byNode.get(p[0]).push(i); byNode.get(p[1]).push(i)});
  // the part of the total cost that involves the tables in `mv`
  const part=mv=>{
    let c=0; const mine=new Set(); mv.forEach(n=>byNode.get(n).forEach(i=>mine.add(i)));
    mine.forEach(i=>{const [a,b]=pairs[i]; c+=.0025*Math.hypot(a.cx-b.cx,a.cy-b.cy);
      for(let j=0;j<P;j++){ if(j===i||(mine.has(j)&&j<i)) continue; const q=pairs[j]; if(cross(a,b,q[0],q[1])) c+=6 }
      for(let k=0;k<N;k++){const n=nodes[k]; if(n!==a&&n!==b&&through(a,b,n)) c+=30}});
    for(let i=0;i<P;i++){ if(mine.has(i)) continue; const [a,b]=pairs[i]; mv.forEach(n=>{if(n!==a&&n!==b&&through(a,b,n)) c+=30}) }
    mv.forEach((m,mi)=>{for(let k=0;k<N;k++){const n=nodes[k]; if(n===m) continue; const o=mv.indexOf(n); if(o>=0&&o<mi) continue; c+=ov(m,n)}});
    return c};
  const free=nodes.filter(n=>!n.core); if(!free.length) return;
  const t0=performance.now(), budget=Math.min(1500,250+N*4);
  const iters=Math.min(20000,Math.max(800,Math.round(4e7/(P*8+N*4+1))));
  let cur=0, best=0, bestPos=nodes.map(n=>[n.cx,n.cy]);
  for(let it=0;it<iters;it++){
    if((it&31)===0&&performance.now()-t0>budget) break;
    const f=1-it/iters, T=3*f*f+.02, step=15+220*f;
    const a=free[Math.floor(rnd()*free.length)];
    let swap=null; const ox=a.cx, oy=a.cy;
    if(rnd()<.2&&free.length>1){swap=free[Math.floor(rnd()*free.length)]; if(swap===a) swap=null}
    const mv=swap?[a,swap]:[a]; const before=part(mv); let so=null;
    if(swap){so=[swap.cx,swap.cy]; swap.cx=a.cx;swap.cy=a.cy;a.cx=so[0];a.cy=so[1]}
    else{a.cx+=gauss()*step; a.cy+=gauss()*step}
    const dlt=part(mv)-before;
    if(dlt<=0||rnd()<Math.exp(-dlt/T)){cur+=dlt; if(cur<best-1e-9){best=cur;bestPos=nodes.map(n=>[n.cx,n.cy])}}
    else{ if(swap){swap.cx=a.cx;swap.cy=a.cy;a.cx=ox;a.cy=oy} else{a.cx=ox;a.cy=oy} }
  }
  nodes.forEach((n,i)=>{n.cx=bestPos[i][0];n.cy=bestPos[i][1]});
}
function erdZoom(z,keep,ctr,anchor){
  const E=erdInit(); const s=$('#erdcv svg'); if(!s) return;
  const cv=$('#erdcv'); const vb=(s.getAttribute('viewBox')||'').split(/\s+/).map(Number);
  const w0=vb[2]||s.getBoundingClientRect().width, h0=vb[3]||s.getBoundingClientRect().height;
  // remember which diagram point is in the middle of the view, so zooming keeps it there
  let ref=null; const m0=s.getScreenCTM(), cr=cv.getBoundingClientRect();
  if(m0&&!ctr){const p=s.createSVGPoint(); p.x=anchor?anchor.x:cr.left+cr.width/2; p.y=anchor?anchor.y:cr.top+cr.height/2; ref=p.matrixTransform(m0.inverse())}
  if(!keep){ const cur=E.zoom||(m0?m0.a:1)||1; E.zoom=z===0?0:Math.max(.05,Math.min(8,cur*z)) }
  // no zoom chosen yet: size the diagram to the screen resolution (it can run past the panel; drag or scroll to see the rest).
  // After Fit, size it to the visible panel instead.
  let sc=E.zoom; if(!sc){
    if(E.fit==='view'){const pw=cv.clientWidth-24, ph=cv.clientHeight-24; sc=Math.max(.05,Math.min(pw/w0,ph/h0,3))}
    else{const sw=(window.screen&&screen.width)||innerWidth, sh=(window.screen&&screen.height)||innerHeight; sc=Math.max(.05,Math.min((sw-48)/w0,(sh-48)/h0,1.5))}
  }
  s.style.maxWidth='none'; s.style.width=(w0*sc)+'px'; s.style.height=(h0*sc)+'px'; s.setAttribute('width',w0*sc); s.setAttribute('height',h0*sc);
  // the scrollable area is bigger than the diagram, so the canvas can always be dragged around
  s.style.margin=Math.round(cv.clientHeight*.75)+'px '+Math.round(cv.clientWidth*.75)+'px';
  if(ctr||(!keep&&z===0)){const sr=s.getBoundingClientRect(), c2=cv.getBoundingClientRect(); cv.scrollLeft+=(sr.left+sr.width/2)-(c2.left+c2.width/2); cv.scrollTop+=(sr.top+sr.height/2)-(c2.top+c2.height/2)}
  else if(ref){const m1=s.getScreenCTM(); if(m1){const p=s.createSVGPoint(); p.x=ref.x; p.y=ref.y; const q=p.matrixTransform(m1); cv.scrollLeft+=q.x-(anchor?anchor.x:cr.left+cr.width/2); cv.scrollTop+=q.y-(anchor?anchor.y:cr.top+cr.height/2)}}
}
function erdBBox(s){ const E=erdInit(); return E.bbox?E.bbox():s.getBBox() }
function erdViewSvg(){
  // only the part of the diagram that is on screen right now (without empty space around the tables)
  const s=$('#erdcv svg'), cv=$('#erdcv'); if(!s) return null; const m=s.getScreenCTM(); if(!m) return null; const inv=m.inverse(), r=cv.getBoundingClientRect();
  const pt=(x,y)=>{const p=s.createSVGPoint();p.x=x;p.y=y;return p.matrixTransform(inv)};
  const a=pt(r.left,r.top), b=pt(r.right,r.bottom), bb=erdBBox(s), pad=16;
  let x0=Math.max(a.x,bb.x-pad), y0=Math.max(a.y,bb.y-pad), x1=Math.min(b.x,bb.x+bb.width+pad), y1=Math.min(b.y,bb.y+bb.height+pad);
  if(x1-x0<20||y1-y0<20){x0=bb.x-pad;y0=bb.y-pad;x1=bb.x+bb.width+pad;y1=bb.y+bb.height+pad}
  const w=x1-x0, h=y1-y0, c=s.cloneNode(true); c.setAttribute('viewBox',x0+' '+y0+' '+w+' '+h); c.setAttribute('width',w); c.setAttribute('height',h); c.removeAttribute('style');
  c.querySelectorAll('[style]').forEach(x=>{x.style.opacity='';x.style.cursor=''});
  // names on the lines are exported only when they are set to show always; nothing is left dimmed or highlighted
  c.setAttribute('class','erdsvg'); c.querySelectorAll('.hot').forEach(x=>x.classList.remove('hot')); if(erdInit().lbl!=='all') c.querySelectorAll('g.lab').forEach(x=>x.remove()); c.querySelectorAll('.eyebtn').forEach(x=>x.remove());
  return {svg:new XMLSerializer().serializeToString(c),w,h};
}
function erdDrawio(base){
  const E=erdInit(), M=E.model; if(!M||!M.nodes.length) return toast('Nothing to export yet');
  const x=s=>String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  const HD=30, RH=22, T=[];
  M.nodes.forEach(n=>{
    const rows=(n.rows||[]).filter(r=>!r.hid); const lines=rows.map(r=>(r.k?r.k+'  ':'     ')+r.name+(r.label&&r.k==='FK'?'  ('+r.label+')':''));
    const chars=Math.max(n.label.length+4,...lines.map(l=>l.length)); T.push({n,rows,lines,w:Math.max(170,Math.min(380,Math.round(chars*7.2+24))),h:HD+Math.max(RH,rows.length*RH)+(rows.length?4:0)});
  });
  const byId={}; T.forEach(t=>byId[t.n.id.toLowerCase()]=t);
  // positions: the layout you see (centres), spread a little because draw.io text is wider, then pushed apart so boxes never overlap
  const have=T.filter(t=>E.pos&&E.pos[t.n.id.toLowerCase()]).length===T.length;
  T.forEach((t,i)=>{ if(have){const p=E.pos[t.n.id.toLowerCase()]; t.cx=p[0]*1.3; t.cy=p[1]*1.3} else {t.cx=(i%5)*320; t.cy=Math.floor(i/5)*300} });
  for(let pass=0;pass<300;pass++){let any=false;
    for(let i=0;i<T.length;i++)for(let j=i+1;j<T.length;j++){const a=T[i],b=T[j]; const ox=(a.w+b.w)/2+50-Math.abs(a.cx-b.cx), oy=(a.h+b.h)/2+50-Math.abs(a.cy-b.cy);
      if(ox>0&&oy>0){any=true; if(ox<oy){const s=b.cx>=a.cx?1:-1;a.cx-=s*ox/2;b.cx+=s*ox/2}else{const s=b.cy>=a.cy?1:-1;a.cy-=s*oy/2;b.cy+=s*oy/2}}}
    if(!any) break}
  const minx=Math.min(...T.map(t=>t.cx-t.w/2)), miny=Math.min(...T.map(t=>t.cy-t.h/2));
  T.forEach(t=>{t.x=Math.round((t.cx-t.w/2-minx+40)/10)*10; t.y=Math.round((t.cy-t.h/2-miny+40)/10)*10});
  let id=2; const out=[]; const cellId=new Map();
  T.forEach(t=>{
    const custom=t.n.sel&&t.n.sh&&t.n.sh.custom, core=E.core.has(t.n.id.toLowerCase()), tid='t'+(id++); cellId.set(t.n.id,tid); t.tid=tid;
    out.push('<mxCell id="'+tid+'" value="'+x(t.n.label)+'" style="swimlane;fontStyle=1;childLayout=stackLayout;horizontal=1;startSize='+HD+';horizontalStack=0;resizeParent=1;resizeParentMax=0;resizeLast=0;collapsible=0;marginBottom=0;whiteSpace=wrap;html=1;fontColor=#0A4873;fillColor='+(custom?'#F7D4E7':'#E3ECF4')+';strokeColor='+(E.acol&&hasAreas()&&t.n.sh?areaColour(areaOf(t.n.sh)):custom?'#BB1C73':'#0A4873')+';strokeWidth='+(custom?3:1)+';swimlaneFillColor=#FFFFFF;'+(core?'shadow=1;':'')+'" vertex="1" parent="1"><mxGeometry x="'+t.x+'" y="'+t.y+'" width="'+t.w+'" height="'+t.h+'" as="geometry"/></mxCell>');
    t.lines.forEach((l,i)=>{const k=t.rows[i].k; out.push('<mxCell id="'+tid+'r'+i+'" value="'+x(l)+'" style="text;strokeColor=none;fillColor=none;align=left;verticalAlign=middle;spacingLeft=8;spacingRight=6;overflow=hidden;rotatable=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;whiteSpace=wrap;html=1;fontFamily=Courier New;fontSize=11;fontColor='+(k==='FK'?'#BB1C73':'#0A4873')+';'+(k==='PK'?'fontStyle=1;':'')+'" vertex="1" parent="'+tid+'"><mxGeometry y="'+(HD+i*RH)+'" width="'+t.w+'" height="'+RH+'" as="geometry"/></mxCell>')});
  });
  // relationships: parent (the table looked up) -> child (holds the lookup). One line per pair unless merging is off.
  const groups=new Map(); M.rels.forEach(r=>{const k=(r.nn?'nn:':r.unk?'unk:':'')+(E.merge?r.p+'>'+r.c:r.p+'>'+r.c+'>'+r.lbl); (groups.get(k)||groups.set(k,[]).get(k)).push(r)});
  groups.forEach(g=>{
    const r=g[0], P=byId[r.p.toLowerCase()], C=byId[r.c.toLowerCase()]; if(!P||!C) return;
    const lbl=[...new Set(g.map(q=>q.lbl))].join(' · '), req=g.some(q=>q.req), eid='e'+(id++);
    const style='edgeStyle=orthogonalEdgeStyle;rounded=1;orthogonalLoop=1;jettySize=auto;html=1;fontSize=11;fontColor=#0A4873;labelBackgroundColor=#FFFFFF;'+(r.unk?'strokeColor=#98A2B3;startArrow=none;endArrow=none;':'strokeColor=#0A4873;startArrow='+(r.nn?'ERzeroToMany':req?'ERmandOne':'ERzeroToOne')+(r.nn?';dashed=1':'')+';startFill=0;endArrow=ERzeroToMany;endFill=0;');
    let geo='<mxGeometry relative="1" as="geometry"/>';
    if(P===C) geo='<mxGeometry relative="1" as="geometry"><Array as="points"><mxPoint x="'+(P.x+P.w+50)+'" y="'+(P.y+HD)+'"/><mxPoint x="'+(P.x+P.w+50)+'" y="'+(P.y+HD+40)+'"/></Array></mxGeometry>';
    out.push('<mxCell id="'+eid+'" value="'+x(lbl)+'" style="'+style+'" edge="1" parent="1" source="'+P.tid+'" target="'+C.tid+'">'+geo+'</mxCell>');
  });
  const xml='<?xml version="1.0" encoding="UTF-8"?>\n<mxfile host="app.diagrams.net" agent="Data Model Explorer"><diagram name="ERD" id="erd"><mxGraphModel dx="1400" dy="900" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="0" pageScale="1" pageWidth="1169" pageHeight="827" math="0" shadow="0"><root><mxCell id="0"/><mxCell id="1" parent="0"/>\n'+out.join('\n')+'\n</root></mxGraphModel></diagram></mxfile>';
  download(base+'.drawio',new Blob([xml],{type:'application/vnd.jgraph.mxfile'}));
  toast('draw.io file downloaded. Open it at app.diagrams.net or in the draw.io desktop app.');
}
function erdNamesBtn(){const E=erdInit(),b=document.querySelector('[data-ea="names"]'); if(b) b.textContent='Names: '+({hover:'on hover',all:'always',none:'hidden'}[E.lbl]||'on hover'); document.querySelectorAll('[data-ek="lbl"]').forEach(x=>x.classList.toggle('on',x.dataset.ev===E.lbl)); erdOptSum()}
function renderErdPage(){
  const E=erdInit(); E.relIdx=null; const main=$('#main');
  const groups={}; S.sheets.filter(s=>s.kind==='entity').forEach(s=>{const g=s.area||'Other tables';(groups[g]=groups[g]||[]).push(s)});
  const ord=Object.keys(groups).sort((a,b)=>(a==='Other tables')-(b==='Other tables')||a.localeCompare(b));
  const f=E.q.toLowerCase();
  const list=ord.filter(g=>!E.areas.size||E.areas.has(g)).map(g=>{
    const items=groups[g].filter(s=>erdMatch(s,f));
    return items.length?`<h4>${esc(g)}</h4>`+items.map(s=>erdLbl(s,E)).join(''):'';
  }).join('');
  const seg=(k,opts)=>`<div class="seg">${opts.map(([v,l])=>`<button data-ek="${k}" data-ev="${v}" class="${E[k]===v?'on':''}">${l}</button>`).join('')}</div>`;
  main.innerHTML=`<div class="erdv"><div class="ctl"><div class="ctop"><h1>ERD</h1>
    <div class="esec">Tables <span class="dim" id="erdcount"></span></div>
    <input type="search" id="erdq" placeholder="Filter tables${(()=>{const p=[...ownPrefixes()][0]; return p?", e.g. "+esc(p)+"_":""})()}" value="${esc(E.q)}">
    <div class="quick"><button data-eq="custom">Custom only</button><button data-eq="all">All</button><button data-eq="none">None</button>${hasAreas()?`<button data-areabtn="erd" class="${E.areas.size?'on':''}" style="${E.areas.size?'border-color:var(--accent);background:var(--accent-bg)':''}">Area: ${esc(areaLabel(E.areas))} ▾</button>`:''}</div>
    <div class="quick" id="erdshown" style="${E.q?'':'display:none'}"><button data-eq="shown" title="Tick every table the filter shows">Tick all shown</button><button data-eq="unshown" title="Untick every table the filter shows">Untick all shown</button></div>
    <div class="dim enote" id="erdcore"></div><div class="dim enote" id="erdhid"></div>
</div>
    <div class="lst" id="erdlst">${list}</div>
    <div class="cbot"><div class="esec" style="margin-top:0">Show</div>${seg('attrs',[['none','Names only'],['keys','Keys + lookups'],['all','All fields']])}
    <details id="erdopts"${E.optsOpen?' open':''}><summary><span>Layout and options</span><span class="dim" id="erdoptsum"></span></summary><div class="opt">
    <div class="dim">Direction</div>${seg('dir',[['LR','Left to right'],['TB','Top to bottom']])}
    <div class="dim">Relationship names</div>${seg('lbl',[['hover','On hover'],['all','Always'],['none','Hidden']])}
    <div class="dim" style="margin-top:4px">Which tables are drawn</div>
    <label><input type="checkbox" id="erdfollow" ${E.follow?'checked':''}> Ticking a table also ticks the tables it relates to</label>
    <label><input type="checkbox" id="erdstubs" ${E.stubs?'checked':''}> Show tables the ticked tables look up to</label>
    <label><input type="checkbox" id="erdext" ${E.ext?'checked':''}> Include tables not in the workbook</label>
    <label><input type="checkbox" id="erdrel" ${E.rel?'checked':''}> Hide tables with no relationships</label>
    <label><input type="checkbox" id="erdsys" ${E.sys?'checked':''}> Hide user, team and business unit</label>
    <div class="dim" style="margin-top:4px">Lines and colour</div>
    <label><input type="checkbox" id="erdmerge" ${E.merge?'checked':''}> Merge lines between the same two tables</label>
    ${S.dv?`<label><input type="checkbox" id="erdnn" ${E.nn?'checked':''}> Show N:N relationships from Dataverse</label>`:''}
    ${hasAreas()?`<label><input type="checkbox" id="erdacol" ${E.acol?'checked':''}> Colour by area</label>`:`<span class="dim" style="font-size:12.5px">Fill in <b>Area</b> in the Table Dictionary to pick and colour tables by area.</span>`}</div></details></div></div>
    <div class="stage"><div class="tb"><span class="info" id="erdinfo"></span><span class="grow"></span>
      <button class="btn" data-ez="0.8">−</button><button class="btn" data-ez="0" title="Fit the whole diagram in the panel">Fit</button><button class="btn" data-ez="1.25">+</button>
      <button class="btn" data-ea="names" title="Show or hide the relationship names on the lines">Names</button><button class="btn" data-ea="relayout" title="Discard your arrangement and lay the tables out again">Auto layout</button><span class="erdexp"><button class="btn" data-ea="expmenu" aria-haspopup="true">Export ▾</button><span class="erdmenu" id="erdmenu" hidden><button data-ea="drawio">draw.io (.drawio)<small>Editable, with your layout</small></button><button data-ea="svg">Picture (SVG)</button><button data-ea="png">Picture (PNG)</button><hr><button data-ea="mmd">Mermaid (.mmd)</button><button data-ea="copy">Copy Mermaid</button><button data-ea="src" class="${E.src?'on':''}">Show Mermaid source</button></span></span></div>
      <div class="dim" id="erdlegend" style="padding:6px 16px;border-bottom:1px solid var(--line2)"><span style="display:inline-block;width:14px;height:10px;border:3px solid #BB1C73;border-radius:2px;vertical-align:-1px"></span> Custom table &nbsp; <span style="display:inline-block;width:14px;height:10px;border:1px solid #0A4873;border-radius:2px;vertical-align:-1px"></span> Out of the box or referenced</div>
      <div class="body ${E.dock} ${E.src?'srcopen':''}" id="erdbody" style="--sw:${E.sw}px;--sh:${E.sh}px"><div class="cv" id="erdcv"><div class="msg">Drawing…</div></div>
        <div class="sres" id="erdsres" title="Drag to resize. Double-click to reset."></div>
        <div class="srcbox" id="erdsrcbox"><div class="sh"><b>Mermaid source</b><span class="dim hint">Read-only. Use Copy to take it elsewhere.</span><span class="grow"></span><button class="btn" data-ea="dock" title="Dock the source to the right or to the bottom">Dock: ${E.dock==='right'?'right':'bottom'}</button><button class="btn" data-ea="maxsrc" title="Make the source panel larger or smaller">Expand</button><button class="btn" data-ea="copy">Copy</button><button class="btn" data-ea="src" title="Close">✕</button></div>
          <textarea id="erdsrc" spellcheck="false" readonly title="Read-only. Use Copy to take the Mermaid source elsewhere."></textarea></div></div></div></div>`;
  const root=main.querySelector('.erdv');
  root.addEventListener('change',e=>{
    const t=e.target;
    if(t.dataset.es){erdPick(+t.dataset.es,t.checked); const lst=$('#erdlst'),keep=lst.scrollTop; renderErdList(); lst.scrollTop=keep; erdRefresh()}
    else if(t.id==='erdfollow'){E.follow=t.checked;erdSave()}
    else if(t.id==='erdstubs'){E.stubs=t.checked;erdSave();erdRefresh()}
    else if(t.id==='erdrel'){E.rel=t.checked;erdSave();erdRefresh()}
    else if(t.id==='erdext'){E.ext=t.checked;erdSave();erdRefresh()}
    else if(t.id==='erdmerge'){E.merge=t.checked;erdSave();erdRefresh(true)}
    else if(t.id==='erdsys'){E.sys=t.checked;erdSave();erdRefresh()}
    else if(t.id==='erdnn'){E.nn=t.checked;erdSave();erdRefresh(true)}
    else if(t.id==='erdacol'){E.acol=t.checked;erdSave();erdRefresh(true)}
    erdOptSum();
  });
  $('#erdopts').addEventListener('toggle',e=>{E.optsOpen=e.target.open; erdSave()});
  root.addEventListener('input',e=>{if(e.target.id==='erdq'){E.q=e.target.value;$('#erdshown').style.display=E.q?'':'none';const lst=$('#erdlst');const keep=lst.scrollTop;renderErdList();lst.scrollTop=keep}});
  root.addEventListener('click',e=>{
    const b=e.target.closest('button'); if(!b) return;
    if(b.dataset.core){e.preventDefault();const s=S.sheets.find(x=>x.idx===+b.dataset.core); if(!s) return; const k=mid(s.logical).toLowerCase();
      if(E.core.has(k)) E.core.delete(k); else {E.core.add(k);E.sel.add(s.idx)}
      erdSave(); const lst=$('#erdlst'),keep=lst.scrollTop; renderErdList(); lst.scrollTop=keep; erdUpdCore(); erdRefresh(true); return}
    if(b.dataset.ek){E[b.dataset.ek]=b.dataset.ev; if(b.dataset.ek==='lbl') setTimeout(erdNamesBtn,0);erdSave();b.parentElement.querySelectorAll('button').forEach(x=>x.classList.toggle('on',x===b));erdRefresh(true)}
    else if(b.dataset.eq){
      const ents=S.sheets.filter(s=>s.kind==='entity');
      if(b.dataset.eq==='shown'||b.dataset.eq==='unshown'){const f=E.q.toLowerCase(); ents.filter(s=>erdMatch(s,f)).forEach(s=>{ if(b.dataset.eq==='shown') E.sel.add(s.idx); else E.sel.delete(s.idx) }); }
      else {
        const pick=b.dataset.eq==='all'?ents:b.dataset.eq==='custom'?ents.filter(s=>s.custom):[];
        const apply=()=>{E.auto={};E.prim=new Set();E.sel=new Set(pick.map(s=>s.idx));document.querySelectorAll('#erdlst input[data-es]').forEach(x=>x.checked=E.sel.has(+x.dataset.es));erdRefresh(true)};
        if(pick.length>ERD_BIG) dlg({title:'Draw '+pick.length+' tables?',body:'A diagram this large can take 10 seconds or more to draw and is hard to read. Filtering to a few dozen related tables usually works better.',ok:'Draw them all'}).then(ok=>{if(ok)apply()});
        else apply();
        return;
      }
      document.querySelectorAll('#erdlst input[data-es]').forEach(x=>x.checked=E.sel.has(+x.dataset.es)); erdRefresh(true)}
    else if(b.dataset.ez!==undefined){if(+b.dataset.ez===0) E.fit='view'; erdZoom(+b.dataset.ez)}
    else if(b.dataset.ea){ if(b.dataset.ea!=='expmenu') $('#erdmenu').hidden=true; erdAction(b.dataset.ea,b) }
  });
  root.addEventListener('click',e=>{if(e.target.closest('[data-hidclear]')){e.preventDefault();E.hide.clear();erdHidChanged();return}});
  root.addEventListener('click',e=>{if(e.target.closest('[data-coreclear]')){e.preventDefault();E.core.clear();erdSave();renderErdList();erdUpdCore();erdRefresh(true)}});
  erdUpdCore(); erdNamesBtn(); erdOptSum();
  // the canvas fills the screen: re-fit when the window or panel size changes, drag empty space to pan, mouse wheel to zoom at the pointer
  const bodyEl=$('#erdbody'), sres=$('#erdsres'); let rs=null;
  sres.addEventListener('pointerdown',ev=>{const r=bodyEl.getBoundingClientRect(); rs={x:ev.clientX,y:ev.clientY,w:E.sw,h:E.sh,bw:r.width,bh:r.height}; document.body.classList.add('resizing'); try{sres.setPointerCapture(ev.pointerId)}catch(_){} ev.preventDefault()});
  sres.addEventListener('pointermove',ev=>{if(!rs) return; if(E.dock==='right'){E.sw=Math.max(260,Math.min(rs.bw-180,rs.w-(ev.clientX-rs.x))); bodyEl.style.setProperty('--sw',E.sw+'px')}else{E.sh=Math.max(120,Math.min(rs.bh-120,rs.h-(ev.clientY-rs.y))); bodyEl.style.setProperty('--sh',E.sh+'px')}});
  const endRs=()=>{if(!rs) return; rs=null; document.body.classList.remove('resizing'); erdSave()}; sres.addEventListener('pointerup',endRs); sres.addEventListener('pointercancel',endRs);
  sres.addEventListener('dblclick',()=>{E.sw=440;E.sh=260;bodyEl.style.setProperty('--sw','440px');bodyEl.style.setProperty('--sh','260px');erdSave()});
  const cvEl=$('#erdcv'); let pan=null;
  if(S.erdRO){S.erdRO.disconnect();S.erdRO=null} if(window.ResizeObserver){let last=0; S.erdRO=new ResizeObserver(()=>{const w=cvEl.clientWidth*10000+cvEl.clientHeight; if(w!==last){last=w; if(!E.zoom) erdZoom(0,true,true)}}).observe(cvEl)}
  cvEl.addEventListener('pointerdown',ev=>{if(ev.button!==0||ev.target!==cvEl) return; pan={x:ev.clientX,y:ev.clientY,sl:cvEl.scrollLeft,st:cvEl.scrollTop}; cvEl.style.cursor='grabbing'; try{cvEl.setPointerCapture(ev.pointerId)}catch(_){} ev.preventDefault()});
  cvEl.addEventListener('pointermove',ev=>{if(!pan) return; cvEl.scrollLeft=pan.sl-(ev.clientX-pan.x); cvEl.scrollTop=pan.st-(ev.clientY-pan.y)});
  const endPan=()=>{pan=null; cvEl.style.cursor=''}; cvEl.addEventListener('pointerup',endPan); cvEl.addEventListener('pointercancel',endPan);
  cvEl.addEventListener('wheel',ev=>{ev.preventDefault(); const f=Math.pow(1.0018,-Math.max(-120,Math.min(120,ev.deltaY))*(ev.deltaMode===1?16:1)); erdZoom(f,false,false,{x:ev.clientX,y:ev.clientY});},{passive:false});
  drawErd();
}
// choosing areas narrows the table list to them and draws their tables (asking first when that is a lot)
function erdAreas(set){
  const E=erdInit(); E.areas=set;
  const btn=document.querySelector('[data-areabtn="erd"]'); if(btn){btn.textContent='Area: '+areaLabel(set)+' ▾'; btn.style.cssText=set.size?'border-color:var(--accent);background:var(--accent-bg)':''}
  const lst=$('#erdlst'); renderErdList(); if(lst) lst.scrollTop=0;
  if(!set.size) return;
  const pick=S.sheets.filter(s=>s.kind==='entity'&&set.has(areaOf(s)));
  const apply=()=>{E.auto={};E.prim=new Set();E.sel=new Set(pick.map(s=>s.idx));renderErdList();erdRefresh(true)};
  if(pick.length>ERD_BIG) dlg({title:'Draw '+pick.length+' tables?',body:'These areas hold '+pick.length+' tables. A diagram this large can take 10 seconds or more to draw and is hard to read.',ok:'Draw them all'}).then(ok=>{if(ok)apply()});
  else apply();
}
function erdUpdCount(){const E=erdInit(),el=$('#erdcount'); if(!el) return; const n=S.sheets.filter(s=>s.kind==='entity').length; el.textContent=E.sel.size+' of '+n+' ticked'}
// the closed options heading says what is set, so nothing is hidden by surprise
function erdOptSum(){const E=erdInit(),el=$('#erdoptsum'); if(!el) return;
  const on=[E.ext&&'not in workbook',!E.stubs&&'no looked-up tables',!E.rel&&'unrelated shown',!E.sys&&'user/team shown',!E.merge&&'lines not merged',E.acol&&'colour by area',!E.follow&&'no auto-tick'].filter(Boolean);
  el.textContent=(E.dir==='TB'?'Top to bottom':'Left to right')+' · names '+({hover:'on hover',all:'always',none:'hidden'}[E.lbl]||'on hover')+(on.length?' · '+on.join(', '):'')}
function erdUpdCore(){const E=erdInit(),el=$('#erdcore'); if(!el) return;
  const names=S.sheets.filter(s=>s.kind==='entity'&&E.core.has(mid(s.logical).toLowerCase())).map(s=>s.label);
  el.innerHTML=names.length?'Core: <b>'+names.map(esc).join(', ')+'</b> <a href="#" data-coreclear style="margin-left:6px">clear</a>':'★ a table to arrange the diagram around it.'}
function erdMatch(s,f){ if(!f) return true; return f.split(/[\s,;]+/).filter(Boolean).some(w=>(s.label+' '+s.logical+' '+s.schema).toLowerCase().includes(w)) }
function erdLbl(s,E){return `<label><input type="checkbox" data-es="${s.idx}" ${E.sel.has(s.idx)?'checked':''}> <span class="tn">${esc(s.label)}<small class="lg">${esc(s.logical)}</small></span><small>${s.custom?'custom':'ootb'}</small><button type="button" class="corebtn ${E.core.has(mid(s.logical).toLowerCase())?'on':''}" data-core="${s.idx}" title="Make this a core table: the diagram is arranged around the core tables">★</button></label>`}
/* the relationships of one table, both ways: its own lookups, lookups to it from other tables, and N:N */
function erdRelIndex(){
  const E=erdInit(), idx=new Map(), lk=/lookup|owner|customer/i;
  const add=(lg,r)=>{lg=String(lg).toLowerCase(); let a=idx.get(lg); if(!a) idx.set(lg,a=[]); if(!a.some(x=>x.k===r.k)) a.push(r)};
  const lbl=lg=>{const i=S.byLogical[lg]; return i!=null?S.sheets[i].label:lg};
  S.sheets.filter(s=>s.kind==='entity').forEach(s=>s.rows.forEach(row=>{
    const ln=getVal(s,row,'Logical Name'); if(!ln) return; const dn=getVal(s,row,'Display Name')||ln;
    if(isNNRow(s,row)){const tg=lookupTargetsOf(s,row)[0]; if(!tg) return; const k='n:'+ln.toLowerCase(); add(s.logical,{k,txt:dn,other:lbl(tg),ol:tg,dir:'nn'}); add(tg,{k,txt:dn,other:s.label,ol:s.logical,dir:'nn'}); return}
    if(!lk.test(getVal(s,row,'Attribute Type'))) return;
    lookupTargetsOf(s,row).forEach(tg=>{
      if(E.sys&&SYS_TABLES.has(tg)) return; const k=erdRk(s,row,tg);
      add(s.logical,{k,txt:dn,other:lbl(tg),dir:'out'}); if(tg.toLowerCase()!==s.logical.toLowerCase()) add(tg,{k,txt:dn,other:s.label,dir:'in'});
    });
  }));
  if(S.dv&&E.nn) Object.entries(S.dv.ents).forEach(([lg,de])=>(de.nn||[]).forEach(r=>add(lg,{k:'n:'+String(r.schema).toLowerCase(),txt:r.schema,other:lbl(r.other),ol:r.other,dir:'nn'})));
  return idx;
}
function erdRelsOf(sh){const E=erdInit(); if(!E.relIdx) E.relIdx=erdRelIndex(); return E.relIdx.get(sh.logical.toLowerCase())||[]}
function erdUpdHid(n){const E=erdInit(),el=$('#erdhid'); if(!el) return;
  el.innerHTML=E.hide.size?`${n!=null?n:E.hide.size} hidden relationship${(n!=null?n:E.hide.size)===1?'':'s'} in this diagram <a href="#" data-hidclear style="margin-left:6px">show all</a>`:''}
// after changing which relationships are hidden: keep the tables where they are, redraw, and refresh the list
function erdHidChanged(){const E=erdInit(); E.keepPos=E.pos; erdSave(); const lst=$('#erdlst'),keep=lst?lst.scrollTop:0; if(lst){renderErdList(); lst.scrollTop=keep} erdRefresh(true)}
/* selecting a table also selects the tables it relates to (and unselecting removes the ones it brought in) */
function erdAdj(){
  if(S.adj) return S.adj;
  const adj=new Map(), add=(a,b)=>{if(a===b)return;(adj.get(a)||adj.set(a,new Set()).get(a)).add(b);(adj.get(b)||adj.set(b,new Set()).get(b)).add(a)};
  S.sheets.filter(s=>s.kind==='entity').forEach(sh=>{ sh.rows.forEach(row=>{ lookupTargetsOf(sh,row).forEach(tg=>{ const i=S.byLogical[tg]; if(i!==undefined) add(sh.idx,i) }) }) });
  return S.adj=adj;
}
function erdRelated(idx){const E=erdInit(); const out=[...(erdAdj().get(idx)||[])]; return out.filter(i=>{const s=S.sheets[i]; return !(E.sys&&SYS_TABLES.has(s.logical))})}
function erdPick(idx,on){
  const E=erdInit(); if(!E.auto) E.auto={};
  if(on){
    E.sel.add(idx); Object.values(E.auto).forEach(a=>a.delete(idx)); // a table you tick yourself is no longer "brought in"
    if(E.follow){ const mine=new Set(); erdRelated(idx).forEach(i=>{ if(!E.sel.has(i)){E.sel.add(i);mine.add(i)} }); E.auto[idx]=mine }
  } else {
    E.sel.delete(idx); const mine=E.auto[idx]; delete E.auto[idx];
    Object.values(E.auto).forEach(a=>a.delete(idx));
    if(mine) mine.forEach(i=>{ const kept=Object.values(E.auto).some(a=>a.has(i)); const explicit=!Object.values(E.auto).some(a=>a.has(i))&&E.prim&&E.prim.has(i); if(!kept&&!explicit&&!E.core.has(mid(S.sheets[i].logical).toLowerCase())) E.sel.delete(i) });
  }
  if(!E.prim) E.prim=new Set(); on?E.prim.add(idx):E.prim.delete(idx);
}
function renderErdList(){
  const E=erdInit(); E.relIdx=null; const f=E.q.toLowerCase();
  const groups={}; S.sheets.filter(s=>s.kind==='entity').forEach(s=>{const g=s.area||'Other tables';(groups[g]=groups[g]||[]).push(s)});
  const ord=Object.keys(groups).sort((a,b)=>(a==='Other tables')-(b==='Other tables')||a.localeCompare(b));
  $('#erdlst').innerHTML=ord.filter(g=>!E.areas.size||E.areas.has(g)).map(g=>{const items=groups[g].filter(s=>erdMatch(s,f));
    return items.length?`<h4>${esc(g)}</h4>`+items.map(s=>erdLbl(s,E)).join(''):''}).join('');
}
function erdSave(){const E=erdInit();S.ui.erd={acol:E.acol,nn:E.nn,attrs:E.attrs,stubs:E.stubs,sys:E.sys,ext:E.ext,rel:E.rel,dir:E.dir,merge:E.merge,dock:E.dock,sw:E.sw,sh:E.sh,lbl:E.lbl,follow:E.follow,optsOpen:!!E.optsOpen,core:[...E.core],hide:[...E.hide]};store.set('dme.ui',S.ui)}
function erdAction(a,btn){
  const E=erdInit(); const base=S.fileName.replace(/\.[^.]+$/,'')+' - ERD';
  if(a==='expmenu'){const m=$('#erdmenu'); m.hidden=!m.hidden; if(!m.hidden) setTimeout(()=>document.addEventListener('click',function c(ev){if(!ev.target.closest('.erdexp')){m.hidden=true} document.removeEventListener('click',c)},{once:false}),0); return}
  if(a==='names'){E.lbl=E.lbl==='hover'?'all':E.lbl==='all'?'none':'hover'; erdSave(); erdNamesBtn(); if(E.applyVis) E.applyVis(); return}
  if(a==='relayout'){const all=store.get('dme.erdpos')||{};let h=5381;const src=(E.srcText||'')+'|core:'+[...E.core].sort().join(',');for(let i=0;i<src.length;i++)h=((h<<5)+h+src.charCodeAt(i))|0;delete all['p'+(h>>>0).toString(36)];store.set('dme.erdpos',all);E.pos={};drawErd();return}
  if(a==='src'){E.src=!E.src; const bd=$('#erdbody'); bd.classList.toggle('srcopen',E.src); const sb=document.querySelector('.tb [data-ea="src"]'); if(sb){sb.classList.toggle('on',E.src); sb.textContent=E.src?'Hide Mermaid source':'Show Mermaid source'} return}
  if(a==='dock'){E.dock=E.dock==='right'?'bottom':'right'; erdSave(); const bd=$('#erdbody'); bd.classList.remove('right','bottom'); bd.classList.add(E.dock); btn.textContent='Dock: '+(E.dock==='right'?'right':'bottom'); return}
  if(a==='maxsrc'){E.smax=!E.smax; $('#erdbody').classList.toggle('smax',E.smax); btn.textContent=E.smax?'Shrink':'Expand'; return}
  if(a==='copy'){const t=E.srcText||'';(navigator.clipboard&&navigator.clipboard.writeText?navigator.clipboard.writeText(t):Promise.reject()).then(()=>toast('Mermaid copied'),()=>{const ta=$('#erdsrc');if(!E.src){E.src=true;$('#erdbody').classList.add('srcopen')}ta.select();toast('Press Ctrl+C to copy')});return}
  if(a==='drawio'){erdDrawio(base);return}
  if(a==='mmd'){download(base+'.mmd',new Blob([E.srcText||''],{type:'text/plain'}));return}
  const v=erdViewSvg(); if(!v) return toast('Nothing to export yet');
  if(a==='svg'){download(base+'.svg',new Blob([v.svg],{type:'image/svg+xml'}));return}
  if(a==='png'){
    const sc=Math.min(3,8000/Math.max(v.w,v.h,1)); const c=document.createElement('canvas'); c.width=Math.round(v.w*sc); c.height=Math.round(v.h*sc);
    const x=c.getContext('2d'); x.fillStyle='#fff'; x.fillRect(0,0,c.width,c.height);
    const img=new Image(); img.onload=()=>{try{x.drawImage(img,0,0,c.width,c.height);c.toBlob(b=>download(base+'.png',b),'image/png')}catch(e){toast('PNG export is not available here. Use SVG.')}};
    img.onerror=()=>toast('PNG export is not available here. Use SVG.');
    img.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(v.svg);
  }
}

function applyAndRender(){if(S.cur==='__erd')return;if(S.cur==='__readme'){renderReadme();return}if(S.cur==='__overview'){renderOverview();return}if(S.cur==='__issues'){renderIssues();return}const v=viewFor(S.cur);S.view=v;S.filtered=filterItems(v);renderMain()}
// each screen (a table, Overview, Checks, ERD, All fields, How it works) is a step in the browser's history, so Back,
// Alt+Left and a mouse's back button return to the previous screen. The address stays the same.
let navDepth=0;
function navRecord(fromHistory){
  if(fromHistory) return; const v=S.cur;
  if(history.state&&history.state.dmeView===v&&history.state.dmeProj===S.proj) return;
  if(history.state&&history.state.dmeView!=null&&history.state.dmeProj!==S.proj) navDepth=0;   // another workbook: its own history starts here
  try{ if(history.state&&history.state.dmeView!=null&&history.state.dmeProj===S.proj){history.pushState({dmeView:v,dmeProj:S.proj,depth:navDepth+1},''); navDepth++} else history.replaceState({dmeView:v,dmeProj:S.proj,depth:0},'') }catch(e){}
  const b=$('#btnBack'); if(b) b.disabled=navDepth<=0;
}
function viewExists(v){v=String(v); return /^__(erd|readme|overview|issues|all)$/.test(v)||/^\d+$/.test(v)&&!!S.sheets[+v]}
addEventListener('popstate',e=>{const st=e.state; if(!st||st.dmeView==null) return;
  navDepth=st.depth||0; const b=$('#btnBack'); if(b) b.disabled=navDepth<=0;
  go(st.dmeProj===S.proj&&viewExists(st.dmeView)?(/^\d+$/.test(st.dmeView)?+st.dmeView:st.dmeView):'__overview',{fromHistory:true})});
function go(id,opts={}){
  const special={__erd:renderErdPage,__readme:renderReadme,__overview:renderOverview,__issues:renderIssues}[String(id)];
  if(special){
    S.cur=String(id);S.selIt=null;S.selItem=null;S.view=null;S.filtered=[];
    document.querySelectorAll('.drawer.open').forEach(d=>d.classList.remove('open'));   // a full page: no panel left on top of it
    $('#q').value=S.cur==='__issues'?(S.issQ||''):''; $('#q').placeholder=S.cur==='__issues'?'Search the checks…':'Open a table to search';
    renderNav(); special(); navRecord(opts.fromHistory); return;
  }
  S.cur=String(id); S.selIt=null; S.selItem=null; $('#detail').classList.remove('open');
  const st=vstate(S.cur); $('#q').value=st.q; $('#q').placeholder='Search '+(S.cur==='__all'?'all fields':viewFor(S.cur).label)+'…';
  S.view=viewFor(S.cur); S.filtered=filterItems(S.view);
  if(opts.focusRow){ // ensure row is visible: clear filters that hide it
    let idx=S.filtered.findIndex(it=>it.row===opts.focusRow);
    if(idx<0){st.q='';st.filters={};st.quick={};$('#q').value='';S.filtered=filterItems(S.view);idx=S.filtered.findIndex(it=>it.row===opts.focusRow)}
    if(idx>=st.shown) st.shown=idx+50;
  }
  renderNav(); renderMain();
  if(opts.focusRow){
    const idx=S.filtered.findIndex(it=>it.row===opts.focusRow);
    const tr=$(`#gridwrap tr[data-i="${idx}"]`);
    if(tr){tr.scrollIntoView({block:'center'});tr.classList.add('flash')}
  }
  $('#gridwrap')&&($('#gridwrap').scrollTop=opts.focusRow?$('#gridwrap').scrollTop:0);
  navRecord(opts.fromHistory);
}

/* ---------- events ---------- */
document.addEventListener('click',e=>{
  const t=e.target;
  if(!t.closest('.pop,.menu,[data-filter],[data-act="cols"],#btnExport,#btnMore,#btnCheck,#btnWb,#btnMob,[data-areabtn]')) closePops();
  let n;
  if((n=t.closest('[data-areabtn]'))){
    e.preventDefault(); const k=n.dataset.areabtn;
    if(k==='erd'){const E=erdInit(); areaPop(n,E.areas,erdAreas,'Shows these areas in the list and draws their tables.')}
    else if(k==='iss'){const st=issState(); areaPop(n,st.areas,set=>{st.areas=set;st.shown=300;renderIssues()})}
    else if(k==='all'){const st=vstate('__all'); areaPop(n,st.areas,set=>{st.areas=set;st.shown=150;applyAndRender()})}
    return;
  }
  if((n=t.closest('[data-wb]'))){e.preventDefault();wbChoose(n.dataset.wb);return}
  if(t.closest('[data-ovx]')){S.restored=false;renderOverview();return}
  if((n=t.closest('[data-view]'))){document.body.classList.remove('navopen');go(n.dataset.view);return}
  if(document.body.classList.contains('navopen')&&!t.closest('.side,#btnNav')) document.body.classList.remove('navopen');
  if((n=t.closest('[data-rt]'))){
    e.stopPropagation(); const tr=n.closest('tr'); const it=S.filtered[+tr.dataset.i];
    const cur=S.rowOv.has(it.row)?S.rowOv.get(it.row):S.ui.expanded!==false; S.rowOv.set(it.row,!cur);
    tr.classList.toggle('rcol',cur); n.textContent=cur?'▸':'▾'; n.title=(cur?'Expand':'Collapse')+' this row'; return;
  }
  if((n=t.closest('[data-grp]'))){S.collapsed[n.dataset.grp]=!S.collapsed[n.dataset.grp];renderNav();return}
  if((n=t.closest('[data-golog]'))){
    e.stopPropagation(); const i=S.byLogical[n.dataset.golog]; if(i!=null) go(i); return;
  }
  if((n=t.closest('[data-go]'))){
    e.preventDefault(); e.stopPropagation();
    const idx=+n.dataset.go; const sh=S.sheets[idx];
    let focus=null;
    if(n.dataset.goname){const tr=n.closest('tr');const it=S.filtered[+tr.dataset.i];if(it)focus=it.row}
    go(idx,{focusRow:focus}); return;
  }
  if((n=t.closest('[data-sort]'))){
    const c=n.dataset.sort; const st=vstate(S.view.id);
    if(!st.sort||st.sort.col!==c) st.sort={col:c,dir:1}; else if(st.sort.dir===1) st.sort={col:c,dir:-1}; else st.sort=null;
    S.filtered=filterItems(S.view); renderMain(); return;
  }
  if((n=t.closest('[data-filter]'))){e.stopPropagation();filterPop(n.dataset.filter,n);return}
  if((n=t.closest('[data-quick]'))){
    const st=vstate(S.view.id); const k=n.dataset.quick; st.quick[k]=!st.quick[k]; st.shown=150;
    if(n.dataset.qf){} applyAndRender(); return;
  }
  if((n=t.closest('[data-qf]'))&&!t.closest('[data-quick]')){
    const [c,v]=n.dataset.qf.split('|'); const st=vstate(S.view.id);
    const f=st.filters[c];
    if(f&&f.sel&&f.sel.size===1&&f.sel.has(v)) delete st.filters[c]; else st.filters[c]={sel:new Set([v]),text:''};
    st.shown=150;
    applyAndRender(); return;
  }
  if((n=t.closest('[data-clr]'))){
    const st=vstate(S.view.id); const k=n.dataset.clr;
    if(k==='areas'){st.areas=new Set()}
    else if(k==='all'){st.q='';st.filters={};st.quick={};st.areas=new Set();$('#q').value=''}
    else if(k==='q'){st.q='';$('#q').value=''}
    else if(k.startsWith('quick:')) st.quick[k.slice(6)]=false;
    else if(k.startsWith('col:')) delete st.filters[k.slice(4)];
    applyAndRender(); return;
  }
  if((n=t.closest('[data-ov]'))){
    e.preventDefault(); const a=n.dataset.ov;
    if(a.startsWith('go:')){go(a.slice(3));return}
    if(a==='open'){pickFile();return}
    if(a==='blank'){download(T.name,new Blob([b64ToU8(T.b64)],{type:XLSX_MIME})); toast('Downloaded the blank template. Fill it in, then open it here.');return}
    if(a==='manual'){doExport('manual');return}
    if(a==='solution'){solDialog();return}
    if(a==='versions'){renderVersions();return}
    if(a==='changes'){renderChanges();return}
    if(a==='dv'){renderDv();return}
    if(a.startsWith('issues')){
      const st=issState(), r=a.split(':'); Object.assign(st,{rule:'',areas:new Set(),dv:false,sev:{error:true,warn:true,info:true},shown:300}); S.issQ='';
      if(r[1]==='rule') st.rule=r.slice(2).join(':'); else if(r[1]==='area') st.areas=new Set([r.slice(2).join(':')]); else if(r[1]==='dv') st.dv=true;
      else if(r[1]==='error'||r[1]==='warn') st.sev={error:r[1]==='error',warn:r[1]==='warn',info:false};
      $('#dvpanel').classList.remove('open'); go('__issues');
    }
    return;
  }
  if((n=t.closest('[data-isev]'))){const st=issState();st.sev[n.dataset.isev]=!st.sev[n.dataset.isev];st.shown=300;renderIssues();return}
  if((n=t.closest('[data-iclr]'))){const st=issState(),k=n.dataset.iclr;if(k==='area')st.areas=new Set();else if(k==='dv')st.dv=false;else if(k==='rule')st.rule='';renderIssues();return}
  if((n=t.closest('[data-ii]'))){const i=S.issList&&S.issList[+n.dataset.ii];if(i){if(i.row)go(i.sh.idx,{focusRow:i.row});else go(i.sh.idx)}return}
  if(t.closest('[data-dvclose]')){$('#dvpanel').classList.remove('open');return}
  if((n=t.closest('[data-live]'))){if(n.dataset.live==='load') liveLoad(); else if(n.dataset.live==='check') liveCheck(); return}
  if((n=t.closest('[data-dv]'))){
    const a=n.dataset.dv;
    if(a==='pick') $('#dvfile').click();
    else if(a==='remove') dlg({title:'Remove the Dataverse metadata?',body:'The imported table definitions are forgotten for this workbook, and the checks go back to the workbook alone.',ok:'Remove',danger:true}).then(ok=>{if(!ok)return;idb.del('__dv:'+S.proj).catch(()=>{});S.dv=null;S.issues=null;S.adj=null;updateCounts();refreshSpecial(true);renderDv()});
    return;
  }
  if((n=t.closest('[data-act]'))){
    const a=n.dataset.act;
    if(a==='cols'){e.stopPropagation();colsMenu(n)}
    else if(a==='addrow'){if(S.view&&S.view.sh) addRowUI(S.view.sh)}
    else if(a==='details'){if(S.view&&S.view.sh) detailsDialog(S.view.sh)}
    else if(a==='expall'){S.ui.expanded=S.ui.expanded===false;S.rowOv.clear();store.set('dme.ui',S.ui);renderMain()}
    else if(a==='navexp'){S.collapsed={};renderNav()}
    else if(a==='navcol'){(S.groups||[]).forEach(g=>S.collapsed[g]=true);renderNav()}
    else if(a==='more'){vstate(S.view.id).shown+=150;renderGrid(true)}
    else if(a==='iss-csv') download(S.fileName.replace(/\.[^.]+$/,'')+' - checks.csv',new Blob([csv(issueRows())],{type:'text/csv'}));
    else if(a==='alltypes'){S.ui.allTypes=!S.ui.allTypes;store.set('dme.ui',S.ui);refreshStats()}
    else if(a==='iss-more'){issState().shown+=300;renderIssues()}
    else if(a==='exp-log') doExport('log');
    else if(a==='exp-diff') doExport('diff');
    else if(a==='tmpl-dl'){const u=b64ToU8(T.b64);download(T.name,new Blob([u],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}))}
    else if(a==='tmpl-use') $('#tfile').click();
    else if(a==='tmpl-reset'){store.set('dme.tmpl',null);loadTemplate(TEMPLATE_B64,TEMPLATE_NAME);conformance();updateCounts();applyAndRender();renderTemplate();toast('Using the bundled template')}
    else if(a==='revert-all'){dlg({title:'Revert all edits?',body:'All '+S.edits.size+' edit'+(S.edits.size===1?'':'s')+' will be reverted to the original values'+(addedRows().length?', and the '+addedRows().length+' row'+(addedRows().length===1?'':'s')+' you added removed':'')+'.',ok:'Revert',danger:true}).then(ok=>{if(ok)revertAll()})}
    return;
  }
  if(t.closest('[data-dclose]')){$('#detail').classList.remove('open');return}
  if(t.closest('[data-rmrow]')&&S.selIt){const {sh,row}=S.selIt;dropAdded(sh,row);return}
  if((n=t.closest('[data-arm]'))){e.preventDefault();const x=addedRows()[+n.dataset.arm];if(x)dropAdded(x.sh,x.row,true);return}
  if((n=t.closest('[data-mrev]'))){e.preventDefault();const x=[...S.metaEd.values()][+n.dataset.mrev];if(x){setMeta(x.sh,x.k,x.old);applyAndRender();renderChanges()}return}
  if((n=t.closest('[data-mgo]'))){e.preventDefault();const x=[...S.metaEd.values()][+n.dataset.mgo];if(x)go(x.sh.idx);return}
  if((n=t.closest('[data-setkey]'))&&S.selIt){const {sh,row}=S.selIt, ln=getVal(sh,row,'Logical Name').trim(), pk=n.dataset.setkey==='pk';
    setMeta(sh,metaLabel(sh,pk?'Primary Key':'Primary Name Column'),ln); applyAndRender(); const it=S.filtered.find(x=>x.row===row); if(it) openDetail(it);
    toast(ln+' is now the '+(pk?'primary key':'primary name column')+' of '+sh.label+(pk&&!isGuidType(getVal(sh,row,'Attribute Type'))?'. Note: Dataverse primary keys are always unique identifiers (see Checks).':''));return}
  if((n=t.closest('[data-ago]'))){e.preventDefault();const x=addedRows()[+n.dataset.ago];if(x)go(x.sh.idx,{focusRow:x.row});return}
  if(t.closest('[data-cclose]')){$('#changes').classList.remove('open');return}
  if(t.closest('[data-tclose]')){$('#tmplpanel').classList.remove('open');return}
  if(t.closest('[data-vclose]')){$('#versions').classList.remove('open');return}
  if((n=t.closest('[data-vgo]'))){
    e.preventDefault(); const sh=S.sheets[+n.dataset.vgo]; const row=n.dataset.vrow?sh.rowMap[n.dataset.vrow]:null; go(sh.idx,{focusRow:row}); return;
  }
  if((n=t.closest('[data-papply]'))){e.preventDefault();const i=+n.dataset.papply;const p=S.pending[i];if(p){S.pending.splice(i,1);if(p.type==='exists'){addRow(p.sh,p.rec.v,p.rec.a);persist();updateCounts();applyAndRender()}else if(p.type==='mconflict'){setMeta(p.sh,p.rec.k,p.rec.n);applyAndRender()}else{setVal(p.sh,p.row,p.rec.c,p.rec.n);afterEdit()}renderChanges()}return}
  if((n=t.closest('[data-pdrop]'))){e.preventDefault();S.pending.splice(+n.dataset.pdrop,1);persist();updateCounts();renderChanges();return}
  if((n=t.closest('[data-pgo]'))){e.preventDefault();const p=S.pending[+n.dataset.pgo];if(p)go(p.sh.idx,{focusRow:p.row});return}
  if((n=t.closest('[data-dnav]'))){
    const i=S.filtered.indexOf(S.selIt)+(+n.dataset.dnav); if(S.filtered[i]){openDetail(S.filtered[i]);const tr=$(`#gridwrap tr[data-i="${i}"]`);if(tr)tr.scrollIntoView({block:'nearest'})} return;
  }
  if((n=t.closest('[data-revert]'))){e.preventDefault();const c=n.dataset.revert;const {sh,row}=S.selIt;setVal(sh,row,c,row.orig[sh.colIdx[c]]);afterEdit();renderDetail();return}
  if((n=t.closest('[data-fedit]'))&&S.selIt){editInDetail(n.closest('.fld'),n.closest('.fld').dataset.fcol);return}
  if((n=t.closest('[data-crev]'))){e.preventDefault();const ed=[...S.edits.values()][+n.dataset.crev];if(ed){setVal(ed.sh,ed.row,ed.col,ed.row.orig[ed.sh.colIdx[ed.col]]);afterEdit();renderChanges()}return}
  if((n=t.closest('[data-cgo]'))){e.preventDefault();const ed=[...S.edits.values()][+n.dataset.cgo];if(ed){go(ed.sh.idx,{focusRow:ed.row})}return}
  // row click -> detail
  const tr=t.closest('#gridwrap tbody tr');
  if(tr&&!t.closest('textarea,input')){const it=S.filtered[+tr.dataset.i];if(it){clearTimeout(S.rowT);S.rowT=setTimeout(()=>openDetail(it),230)}}
});
document.addEventListener('dblclick',e=>{
  clearTimeout(S.rowT);
  const td=e.target.closest('#gridwrap td.editable'); if(!td) return;
  const tr=td.parentElement; const it=S.filtered[+tr.dataset.i]; if(!it) return;
  window.getSelection&&window.getSelection().removeAllRanges();
  startEdit(td,it,td.dataset.col);
});
let qt;
$('#q').addEventListener('input',e=>{clearTimeout(qt);qt=setTimeout(()=>{if(S.cur==='__readme'||S.cur==='__erd'||S.cur==='__overview')return;if(S.cur==='__issues'){S.issQ=e.target.value;issState().shown=300;renderIssues();return}const st=vstate(S.cur);st.q=e.target.value;st.shown=150;applyAndRender()},120)});
$('#sq').addEventListener('input',e=>{S.sideFilter=e.target.value;renderNav()});
$('#btnChanges').onclick=()=>{$('#changes').classList.contains('open')?$('#changes').classList.remove('open'):renderChanges()};
$('#btnExport').onclick=e=>{e.stopPropagation();exportMenu(e.currentTarget)};
// Ctrl+S (Cmd+S): Save, as in the Save & share menu
document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&!e.altKey&&!e.shiftKey&&e.key.toLowerCase()==='s'){e.preventDefault(); if(!RO&&!document.querySelector('.convmask')) doExport('save')}});
$('#btnMore').onclick=e=>{e.stopPropagation();moreMenu(e.currentTarget)};
$('#btnCheck').onclick=e=>{e.stopPropagation();checkMenu(e.currentTarget)};
$('#btnBuild').onclick=()=>doExport('solution');
$('#btnMob').onclick=e=>{e.stopPropagation();mobMenu(e.currentTarget)};
$('#btnWb').onclick=e=>{e.stopPropagation();wbMenu(e.currentTarget)};
$('#btnTmpl').onclick=()=>{$('#tmplpanel').classList.contains('open')?$('#tmplpanel').classList.remove('open'):renderTemplate()};
$('#tfile').onchange=e=>{const f=e.target.files[0];e.target.value='';if(!f)return;const r=new FileReader();r.onload=ev=>{try{const u=new Uint8Array(ev.target.result);const b64=u8ToB64(u);if(!parseWorkbook(XLSX.read(u,XLSX_OPTS)).length)throw new Error('no usable sheets');loadTemplate(b64,f.name);const kept=store.set('dme.tmpl',{name:f.name,b64});conformance();updateCounts();applyAndRender();renderTemplate();toast('Template set to '+f.name+(kept?'':'. This browser could not remember it, so it goes back to the bundled one on reload.'))}catch(err){dlg({title:'Could not use that template',body:esc(err.message),ok:'OK',cancel:null,danger:true})}};r.readAsArrayBuffer(f)};
$('#btnHelp').onclick=()=>go('__readme'); $('#btnHelp').title='How it works · version '+DME_VERSION;
$('#btnBack').onclick=()=>{if(navDepth>0) history.back()};
// hovering a drop-down, or any text cut short, shows it in full: a select shows its chosen option, an option its text,
// and anything clipped (an ellipsis, or text wider than its box) its whole text. A title set on purpose is left alone.
document.addEventListener('mouseover',e=>{
  let el=e.target; if(!(el instanceof Element)) return;
  if(el.tagName==='OPTION'){if(!el.title&&el.textContent.trim()) el.title=el.textContent.trim(); return}
  if(el.tagName==='SELECT'){const o=el.selectedOptions&&el.selectedOptions[0], t=o?o.textContent.trim():''; if(!el.dataset.ownTitle){if(el.title&&el.dataset.autoTitle!==el.title) {el.dataset.ownTitle='1'; return} el.title=t; el.dataset.autoTitle=t} return}
  if(el.tagName==='INPUT'){if((el.type==='text'||el.type==='search'||!el.type)&&el.scrollWidth>el.clientWidth+1&&el.value&&(!el.title||el.dataset.autoTitle===el.title)){el.title=el.value; el.dataset.autoTitle=el.value} return}
  for(let i=0;i<3&&el&&el!==document.body;i++,el=el.parentElement){
    if(el.title&&el.dataset.autoTitle!==el.title) return;           // a tooltip set on purpose
    const cs=getComputedStyle(el), clipX=/hidden|clip/.test(cs.overflowX)&&el.scrollWidth>el.clientWidth+1, clipY=cs.webkitLineClamp!=='none'&&el.scrollHeight>el.clientHeight+2;
    if(clipX||clipY){
      const t=(el.innerText||el.textContent||'').trim().replace(/\s+\n/g,'\n'); if(t&&t.length<600){el.title=t; el.dataset.autoTitle=t} return}
  }
},{passive:true});
$('#btnNav').onclick=()=>document.body.classList.toggle('navopen');
$('#btnDv').onclick=()=>{$('#dvpanel').classList.contains('open')?$('#dvpanel').classList.remove('open'):renderDv()};
$('#dvfile').onchange=e=>{const fs=[...e.target.files];e.target.value='';if(fs.length)importDv(fs)};
document.addEventListener('change',e=>{if(e.target.id==='irule'){const st=issState();st.rule=e.target.value;st.shown=300;renderIssues()}});
$('#btnOpen').onclick=()=>pickFile();
$('#btnVer').onclick=()=>{$('#versions').classList.contains('open')?$('#versions').classList.remove('open'):renderVersions()};
$('#file').onchange=e=>{const f=e.target.files[0];if(f)loadFile(f);e.target.value=''};
document.addEventListener('keydown',e=>{
  // keyboard: Enter on a grid row opens its details; Enter or F2 on a detail value edits it
  {const a=document.activeElement;
   if(a&&a.matches&&a.matches('#gridwrap tbody tr[data-i]')&&(e.key==='Enter'||e.key===' ')){e.preventDefault();const it=S.filtered[+a.dataset.i];if(it){openDetail(it);setTimeout(()=>{const v=$('#detail [data-fedit]');if(v)v.focus()},50)}return}
   if(a&&a.matches&&a.matches('#detail [data-fedit]')&&(e.key==='Enter'||e.key==='F2')&&S.selIt){e.preventDefault();editInDetail(a.closest('.fld'),a.closest('.fld').dataset.fcol);return}}
  const typing=/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName);
  if(e.key==='/'&&!typing){e.preventDefault();$('#q').focus();$('#q').select()}
  else if(e.key==='Escape'){if(typing){document.activeElement.blur?.()} closePops(); $('#detail').classList.remove('open'); $('#changes').classList.remove('open'); document.querySelectorAll('.drawer.open').forEach(d=>d.classList.remove('open'))}
  else if(!typing&&S.selIt&&(e.key==='j'||e.key==='k')){
    const i=S.filtered.indexOf(S.selIt)+(e.key==='j'?1:-1); if(S.filtered[i]){openDetail(S.filtered[i]);const tr=$(`#gridwrap tr[data-i="${i}"]`);if(tr)tr.scrollIntoView({block:'nearest'})}
  }
});
let dragN=0;
addEventListener('dragenter',e=>{e.preventDefault();dragN++;$('#drop').classList.add('show')});
addEventListener('dragleave',e=>{dragN--;if(dragN<=0){dragN=0;$('#drop').classList.remove('show')}});
addEventListener('dragover',e=>e.preventDefault());
addEventListener('drop',e=>{e.preventDefault();dragN=0;$('#drop').classList.remove('show');const it=e.dataTransfer.items&&e.dataTransfer.items[0];const f=e.dataTransfer.files[0];if(!f)return;if([...e.dataTransfer.files].every(x=>/\.(json|zip)$/i.test(x.name))){importDv([...e.dataTransfer.files]);return}if(it&&it.getAsFileSystemHandle){it.getAsFileSystemHandle().then(h=>loadFile(f,h&&h.kind==='file'?h:null),()=>loadFile(f))}else loadFile(f)});

/* ---------- sidebar resize ---------- */
function setSbw(w,save){
  w=Math.max(200,Math.min(640,Math.round(w)));
  document.documentElement.style.setProperty('--sbw',w+'px');
  if(save){S.ui.sbw=w;store.set('dme.ui',S.ui)}
}
(function(){
  const h=document.getElementById('sbres'); if(!h) return;
  h.addEventListener('pointerdown',e=>{
    e.preventDefault(); h.setPointerCapture(e.pointerId); h.classList.add('drag'); document.body.classList.add('resizing');
    const mv=ev=>setSbw(ev.clientX,false);
    const up=ev=>{h.removeEventListener('pointermove',mv);h.removeEventListener('pointerup',up);h.classList.remove('drag');document.body.classList.remove('resizing');setSbw(ev.clientX,true)};
    h.addEventListener('pointermove',mv); h.addEventListener('pointerup',up);
  });
  h.addEventListener('dblclick',()=>{document.documentElement.style.removeProperty('--sbw');delete S.ui.sbw;store.set('dme.ui',S.ui)});
  const sv=(store.get('dme.ui')||{}).sbw; if(sv) setSbw(sv,false);
})();

/* ---------- load ---------- */
function init(wb,name,opts){
  opts=opts||{};
  S.fileName=name;
  S.sheets=parseWorkbook(wb);
  S.byLogical={}; S.sheets.forEach(s=>{if(s.kind==='entity'&&s.logical)S.byLogical[s.logical]=s.idx});
  S.erd=null; S.adj=null; S.issues=null; S.issSt=null; S.choiceCache={}; S.edits=new Map(); S.metaEd=new Map(); S.pending=[]; S.views={}; S.selIt=null; S.rowOv=new Map();
  S.diff=opts.prevSheets?computeDiff(opts.prevSheets,S.sheets,opts.prevName,name):null;
  S.allView=buildAll();
  conformance();
  const restored=applyStored(); relinkAreas();
  S.ui=Object.assign(S.ui,store.get('dme.ui')||{}); if(!S.ui.hidden)S.ui.hidden={};
  // 1.8.1: Relationship Name is hidden by default, also for tables whose column choices were saved earlier
  if(!S.ui.relNameHidden){Object.values(S.ui.hidden).forEach(a=>{if(Array.isArray(a)&&!a.includes('Relationship Name'))a.push('Relationship Name')});S.ui.relNameHidden=true;store.set('dme.ui',S.ui)}
  wbLabel();
  $('#fileLabel').textContent=(isStarter()?'No workbook open · starter template':name+' · '+S.sheets.length+' sheets')+(S.diff?' · vs '+S.diff.pl:'')+(S.handle?' · linked to file':'');
  document.title='Data Model Explorer'+(RO?' (read-only)':'');
  loadDv();
  updateCounts(); S.initCollapse=true;
  go('__overview');
  $('#loading').style.display='none';
  $('#versions').classList.remove('open'); $('#changes').classList.remove('open');
  if(opts.announce){
    if(S.diff&&!S.pending.length) renderVersions();
    if(isStarter()) toast('Showing the empty template. Open a workbook to begin.'); else toast('Loaded '+name+(S.diff?' — '+S.diff.total+' difference'+(S.diff.total===1?'':'s')+' from '+S.diff.pl:'')+(restored?' · '+restored+' edit'+(restored===1?'':'s')+' carried over':'')+(S.pending.length?' · '+S.pending.length+' need attention':''));
    if(S.pending.length) renderChanges();
  } else if(restored||S.pending.length) toast('Restored '+restored+' saved edit'+(restored===1?'':'s')+(S.pending.length?' · '+S.pending.length+' need attention':''));
}
const u8ToB64=u=>{let s='';for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)};
const b64ToU8=b=>{const bin=atob(b);const u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);return u};
function saveVersions(prev,cur){
  // the open and previous workbooks go in IndexedDB (no 5 MB limit, unlike localStorage, which large converted files overflow)
  idb.put({id:'__cur',name:cur.name,b64:cur.b64,proj:cur.proj||S.proj}).then(()=>prev&&prev.b64?idb.put({id:'__prev',name:prev.name,b64:prev.b64,proj:prev.proj}):idb.del('__prev')).catch(()=>{saveState(false,'This browser could not store the open workbook. It will not reopen automatically.');toast('Loaded, but this browser could not remember the new version for next time')});
  try{localStorage.removeItem('dme.prev');localStorage.removeItem('dme.cur')}catch(e){}
}

/* ---------- file library ---------- */
const idb={
  open(){return new Promise((res,rej)=>{try{const r=indexedDB.open('dme.files',1);r.onupgradeneeded=()=>r.result.createObjectStore('f',{keyPath:'id'});r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)}catch(e){rej(e)}})},
  async all(){const db=await this.open();return new Promise((res,rej)=>{const q=db.transaction('f').objectStore('f').getAll();q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)})},
  async put(rec){if(RO) return; const db=await this.open();return new Promise((res,rej)=>{const t=db.transaction('f','readwrite');t.objectStore('f').put(rec);t.oncomplete=()=>res();t.onerror=()=>rej(t.error)})},
  async get(id){const db=await this.open();return new Promise((res,rej)=>{const q=db.transaction('f').objectStore('f').get(id);q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)})},
  async del(id){const db=await this.open();return new Promise((res,rej)=>{const t=db.transaction('f','readwrite');t.objectStore('f').delete(id);t.oncomplete=()=>res();t.onerror=()=>rej(t.error)})}
};
S.lib=[];
function libCounts(rec){
  if(rec.tables!=null) return;
  try{const sh=parseWorkbook(XLSX.read(b64ToU8(rec.b64),XLSX_OPTS));rec.sheets=sh.length;rec.tables=sh.filter(s=>s.kind==='entity').length}catch(e){rec.sheets=0;rec.tables=0}
}
async function libAdd(name,b64,counts,handle,proj){
  if(b64===EMBEDDED_B64) return;
  const ex=S.lib.find(r=>r.b64===b64);
  if(ex){ if(handle||(proj&&!ex.proj)){if(handle)ex.handle=handle;if(!ex.proj)ex.proj=proj;try{await idb.put(ex)}catch(e){}} return }
  const rec={id:'f'+Date.now().toString(36)+Math.random().toString(36).slice(2,6),name,b64,size:Math.round(b64.length*3/4),added:Date.now(),sheets:counts&&counts.sheets,tables:counts&&counts.tables,handle:handle||null,proj:proj||null};
  S.lib.unshift(rec); updFilesBadge();
  try{await idb.put(rec)}catch(e){toast('This browser could not add '+name+' to the Files list')}
}
async function libLoad(){
  let rows=[]; try{rows=await idb.all()}catch(e){}
  S.lib=rows.filter(r=>!String(r.id).startsWith('__')).sort((a,b)=>b.added-a.added);
  const have=b=>b===EMBEDDED_B64||S.lib.some(r=>r.b64===b);
  S.lib.forEach(libCounts);
  // files saved before projects existed: the open one belongs to the open project, the rest each get their own
  S.lib.filter(r=>!r.proj).forEach(r=>{r.proj=r.b64===S.curB64?S.proj:r.id; idb.put(r).catch(()=>{})});
  updFilesBadge();
  const lc=S.lib.find(r=>r.b64===S.curB64&&r.handle); if(lc&&!S.handle){S.handle=lc.handle;updFileLabel()}
  if($('#files').classList.contains('open')) renderFiles();
  wbLabel(); if(S.cur==='__overview') renderOverview();   // the kept-workbook list arrives after the first draw
}
function updFileLabel(){const l=$('#fileLabel');if(l&&S.handle&&!/linked/.test(l.textContent))l.textContent+=' · linked to file'}
function updFilesBadge(){const b=$('#filesCount');if(b){b.textContent=S.lib.length+(store.get('dme.hideb')?0:1);}}
const fmtKB=n=>n>=1048576?(n/1048576).toFixed(1)+' MB':Math.max(1,Math.round(n/1024))+' KB';
function renderFiles(){
  const d=$('#files');
  const bundled={id:'bundled',name:EMBEDDED_NAME,b64:EMBEDDED_B64,bundled:true,size:Math.round(EMBEDDED_B64.length*3/4)}; libCounts(bundled);
  const all=[...S.lib,...(store.get('dme.hideb')?[]:[bundled])];
  const card=r=>{
    const viewing=r.b64===S.curB64, base=!viewing&&S.prevB64&&r.b64===S.prevB64;
    return `<div class="fcard ${viewing?'cur':''}"><div class="fn">${esc(r.name)}</div>
      <div class="dim">${fmtKB(r.size)} · ${r.sheets??'?'} sheets · ${r.tables??'?'} tables${r.bundled?' · built into this page':' · added '+new Date(r.added).toLocaleString()}</div>
      <div style="margin:6px 0">${viewing?'<span class="pill p-blue">VIEWING</span> ':''}${base?'<span class="pill p-amber">COMPARED AGAINST</span> ':''}${r.handle?'<span class="pill p-green">LINKED TO FILE</span> ':''}</div>
      <div class="fbtns">${viewing?'':`<button class="btn" data-fa="open" data-id="${r.id}">Open</button><button class="btn" data-fa="cmp" data-id="${r.id}" title="Keep the current file open and show what changed from this one">Compare with current</button>`}
      <button class="btn" data-fa="dl" data-id="${r.id}">Download</button><button class="btn ghost" data-fa="rm" data-id="${r.id}">Remove</button></div></div>`;
  };
  d.innerHTML=`<header><div style="flex:1;min-width:0"><h3>Files</h3><div class="dim">${all.length} workbook${all.length===1?'':'s'} kept in this browser only</div></div><button class="btn primary" data-fa="add">Add file…</button><button class="btn ghost" data-fclose>✕</button></header>
  <div class="body">${all.map(card).join('')}
  <div class="fcard"><div class="fn">Template</div><div class="dim">${esc(T.name)} · ${T.sheets.length} sheets</div><div class="fbtns" style="margin-top:6px"><button class="btn" data-fa="tmpl">Open template panel</button></div></div>
  <div class="note2">These workbooks are remembered by <b>this browser</b> so you can switch between them. They are not part of the HTML file: anyone you share the file with starts with only the empty template. The Excel files on your computer are never changed.</div>
  <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap;align-items:center"><button class="btn" data-fa="forget">Go back to the empty template…</button><button class="btn danger" data-fa="clearall">Remove all…</button> <span class="dim">Forget every workbook, edit and Dataverse import kept here, and start with the empty template.</span></div></div>`;
  ['#changes','#versions','#detail','#tmplpanel'].forEach(s=>$(s).classList.remove('open')); d.classList.add('open');
}
function libOpen(id,mode){
  const rec=id==='bundled'?{name:EMBEDDED_NAME,b64:EMBEDDED_B64,proj:'bundled'}:S.lib.find(r=>r.id===id); if(!rec) return;
  try{
    const wbRec=XLSX.read(b64ToU8(rec.b64),XLSX_OPTS);
    if(mode==='open'){
      // switching to a file from the list brings back that file's own edits. Two different workbooks are not
      // compared (use "Compare with current" for that)
      saveVersions(null,{name:rec.name,b64:rec.b64,proj:rec.proj||rec.id});
      S.curB64=rec.b64; S.prevB64=null; S.handle=rec.handle||null; S.proj=rec.proj||rec.id; S.restored=false;
      init(wbRec,rec.name,{announce:true});
    } else {
      const prevSheets=parseWorkbook(wbRec);
      saveVersions({name:rec.name,b64:rec.b64},{name:S.fileName,b64:S.curB64});
      S.prevB64=rec.b64;
      init(XLSX.read(b64ToU8(S.curB64),XLSX_OPTS),S.fileName,{prevSheets,prevName:rec.name,announce:true});
    }
    if($('#files').classList.contains('open')) renderFiles();
  }catch(err){toast('Could not open that file ('+err.message+')')}
}
function wireFiles(){
  $('#btnFiles').onclick=()=>{$('#files').classList.contains('open')?$('#files').classList.remove('open'):renderFiles()};
  $('#files').addEventListener('click',async e=>{
    if(e.target.closest('[data-fclose]')){$('#files').classList.remove('open');return}
    const b=e.target.closest('[data-fa]'); if(!b) return; const a=b.dataset.fa, id=b.dataset.id;
    if(a==='add'){pickFile();return}
    if(a==='forget'){doExport('bundled');return}
    if(a==='clearall'){
      if(!await dlg({title:'Remove everything kept in this browser?',body:'Every workbook in this list, all your edits, the version comparison and any imported Dataverse metadata are forgotten, and the page starts again with the empty template.<br><br>The Excel files on your computer are not touched. <b>Export anything you still need first.</b>',ok:'Remove all',danger:true})) return;
      try{const all=await idb.all(); for(const r of all) await idb.del(r.id)}catch(e2){}
      try{Object.keys(localStorage).filter(k=>/^dme\.(edits|erdpos|cur|prev|hideb)/.test(k)).forEach(k=>localStorage.removeItem(k))}catch(e2){}
      location.reload(); return;
    }
    if(a==='tmpl'){renderTemplate();return}
    if(a==='open'||a==='cmp'){libOpen(id,a==='open'?'open':'cmp');return}
    const rec=id==='bundled'?{name:EMBEDDED_NAME,b64:EMBEDDED_B64}:S.lib.find(r=>r.id===id); if(!rec) return;
    if(a==='dl'){download(rec.name,new Blob([b64ToU8(rec.b64)],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}));return}
    if(a==='rm'){if(!await dlg({title:'Remove this file from the list?',body:'<b>'+esc(rec.name)+'</b>'+(rec.b64===S.curB64?' stays open until you load another file.':' will no longer be kept in this browser.')+' The original file on your computer is not touched.',ok:'Remove',danger:true}))return;if(id==='bundled')store.set('dme.hideb',1);else{S.lib=S.lib.filter(r=>r.id!==id);try{await idb.del(id)}catch(e2){}}updFilesBadge();renderFiles()}
  });
  // whichever drawer opened last stays open; the others close
  const drawers=[...document.querySelectorAll('.drawer')]; let was=new Set(drawers.filter(d=>d.classList.contains('open')));
  new MutationObserver(()=>{const now=drawers.filter(d=>d.classList.contains('open')), fresh=now.filter(d=>!was.has(d));
    if(fresh.length) now.forEach(d=>{if(!fresh.includes(d)) d.classList.remove('open')});
    was=new Set(drawers.filter(d=>d.classList.contains('open')))}).observe(document.body,{subtree:true,attributes:true,attributeFilter:['class']});
}

/* ---------- convert a Metadata Document Generator export into the template layout ---------- */
function isMetaExport(wb){
  const n=wb.SheetNames.find(s=>/^entities list$/i.test(s)); if(!n) return false;
  const m=XLSX.utils.sheet_to_json(wb.Sheets[n],{header:1,defval:''});
  return m.some(r=>String(r[0]).trim()==='Entity'&&r.some(c=>String(c).trim()==='Logical Name'));
}
async function convertMetadata(wb,prog){
  let cut=0; const sv=v=>{if(v===true)return 'True';if(v===false)return 'False';if(v==null)return '';if(typeof v==='string'&&v.length>32000){cut++;return v.slice(0,31900)+'\n… (cut: too long for an Excel cell)'}return v};
  const grid=n=>XLSX.utils.sheet_to_json(wb.Sheets[n],{header:1,defval:'',raw:true});
  const list=grid(wb.SheetNames.find(s=>/^entities list$/i.test(s)));
  const hi=list.findIndex(r=>String(r[0]).trim()==='Entity'&&r.some(c=>String(c).trim()==='Logical Name'));
  const H=list[hi].map(c=>String(c).trim()), col=k=>H.indexOf(k);
  const ents=list.slice(hi+1).filter(r=>String(r[col('Logical Name')]).trim()!=='');
  const tabs=wb.SheetNames.filter(s=>!/^entities list$/i.test(s)), used=new Set();
  const findTab=(disp,sch,lg)=>{
    const want=(disp+' ('+sch+')').toLowerCase();
    let t=tabs.find(s=>!used.has(s)&&s.toLowerCase()===want);
    if(!t) t=tabs.find(s=>{if(used.has(s))return false;const m=s.match(/\(([^)]*)\)\s*$/);return m&&m[1].toLowerCase()===String(sch).toLowerCase()});
    if(!t) t=tabs.find(s=>{if(used.has(s))return false;const l=s.toLowerCase();return l.length>=20&&(String(sch).toLowerCase().startsWith(l)||String(lg).toLowerCase().startsWith(l))});
    if(t) used.add(t); return t;
  };
  const out=XLSX.utils.book_new(), dict=[[],['','','All table names to be validated with the client'],['','Area','Table Name','Out of the box/custom table?','Static Data?','Purpose','FormusPro Comments','Added to ERD?','Defined in data model?']];
  const sheets=[]; let nTabs=0, miss=[];
  const AH=['Logical Name','Schema Name','Display Name','Attribute Type','Description','Custom Attribute','Type','Required Level','Additional data','Add to RAF Form?','Comment','Relationship Type','Relationship Name','Cascade Delete'];
  let nAttr=0, done=0;
  for(const r of ents){
    if(done%6===0){prog&&prog({tables:done,total:ents.length,attrs:nAttr,name:String(r[col('Entity')])}); await new Promise(res=>setTimeout(res,0))}
    done++;
    const g=k=>sv(r[col(k)]), disp=g('Entity'), sch=g('Schema Name'), lg=g('Logical Name'), custom=String(g('Is Custom Entity')).toLowerCase()==='true';
    dict.push(['','',disp,custom?'Custom':'OOTB','','','','','Yes']);
    const tab=findTab(disp,sch,lg);
    let name=(disp+' ('+sch+')').replace(/[\\\/\?\*\[\]:]/g,' ').slice(0,31);
    while(sheets.some(s=>s.name.toLowerCase()===name.toLowerCase())) name=name.slice(0,28)+'~'+(sheets.length%100);
    const rows=[['Entity',disp],['Plural Display Name',g('Plural Display Name')],['Description',g('Description')],['Schema Name',sch],['Logical Name',lg],['Object Type Code',g('Object Type Code')],['Is Custom Entity',g('Is Custom Entity')],['Ownership Type',g('Ownership Type')],['Audit Tracking',g('IsAuditEnabled')],
      // what a solution build needs, from the export's wider Entities list (blank when the export doesn't have them)
      ['Primary Name Column',g('PrimaryNameAttribute')],['Primary Key',g('PrimaryIdAttribute')],['Is Activity',g('IsActivity')],['Has Notes',g('HasNotes')],['Has Activities',g('HasActivities')]];
    const hint=[]; hint[10]='e.g. business logic or related automation'; hint[11]='N:1 on a lookup row; N:N on a many-to-many row'; hint[12]='Optional: generated if blank'; hint[13]='Remove Link (default), Restrict or Cascade';
    rows.push(hint); rows.push(AH.slice());
    if(tab){
      nTabs++;
      const m=grid(tab), ah=m.findIndex(x=>String(x[0]).trim().toLowerCase()==='logical name'&&String(x[1]).trim().toLowerCase()==='schema name');
      if(ah>=0){
        const h=m[ah].map(c=>String(c).trim()), ix=k=>h.indexOf(k);
        m.slice(ah+1).forEach(x=>{ if(x.every(c=>String(c).trim()==='')) return;
          const v=k=>{const i=ix(k);return i<0?'':sv(x[i])};
          nAttr++; rows.push([v('Logical Name'),v('Schema Name'),v('Display Name'),v('Attribute Type'),v('Description'),v('Custom Attribute'),v('Type'),v('Required Level'),v('Additional data'),'','','','','']);   // relationship columns left blank: lookups stay "to review" until confirmed
        });
      }
    } else miss.push(disp);
    rows.push([],[],[],['Forms:'],['','Form Name','Formus Comments'],[],[],['Views:'],['','View Name','Columns','Filter']);
    const ws=XLSX.utils.aoa_to_sheet(rows); ws['!cols']=[{wch:34},{wch:26},{wch:30},{wch:18},{wch:50},{wch:14},{wch:10},{wch:16},{wch:44},{wch:16},{wch:30},{wch:18},{wch:34},{wch:18}];
    sheets.push({name,ws});
  }
  prog&&prog({tables:done,total:ents.length,attrs:nAttr,name:'',final:true});
  const wd=XLSX.utils.aoa_to_sheet(dict); wd['!cols']=[{wch:3},{wch:18},{wch:36},{wch:26},{wch:12},{wch:50},{wch:40},{wch:14},{wch:20}];
  XLSX.utils.book_append_sheet(out,wd,'Table Dictionary');
  sheets.forEach(s=>XLSX.utils.book_append_sheet(out,s.ws,s.name));
  return {wb:out,tables:ents.length,withFields:nTabs,attrs:nAttr,miss,cut};
}
function dlg(o){
  return new Promise(res=>{
    const m=document.createElement('div'); m.className='convmask'; m.setAttribute('role','dialog'); m.setAttribute('aria-modal','true');
    const cancel=o.cancel===null?'':'<button class="btn" data-d="0">'+(o.cancel||'Cancel')+'</button>';
    m.innerHTML=`<div class="convbox dlgbox"><h3>${o.title||''}</h3><p>${o.body||''}</p><div class="convbtns">${cancel}<button class="btn ${o.danger?'danger':'primary'}" data-d="1">${o.ok||'OK'}</button></div></div>`;
    const done=v=>{document.removeEventListener('keydown',key,true);m.remove();res(v)};
    const key=e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();done(false)}else if(e.key==='Enter'){e.preventDefault();e.stopPropagation();done(true)}};
    m.addEventListener('click',e=>{const b=e.target.closest('[data-d]');if(b)done(b.dataset.d==='1');else if(e.target===m&&cancel)done(false)});
    document.addEventListener('keydown',key,true); document.body.appendChild(m); m.querySelector('[data-d="1"]').focus();
  });
}
function convModal(fname){
  const o=document.createElement('div'); o.className='convmask';
  o.innerHTML=`<div class="convbox"><h3>Converting metadata export</h3><div class="dim mono" style="word-break:break-all">${esc(fname)}</div>
  <div class="convbar"><i></i></div>
  <div class="convstats"><div><b data-k="t">0</b><span>tables converted</span></div><div><b data-k="a">0</b><span>attributes converted</span></div></div>
  <div class="dim convnow">Reading…</div><div class="convnote"></div><div class="convbtns"></div></div>`;
  document.body.appendChild(o); const q=k=>o.querySelector('[data-k="'+k+'"]');
  return {
    update(p){q('t').textContent=p.tables+' / '+p.total; q('a').textContent=p.attrs.toLocaleString(); o.querySelector('.convbar i').style.width=(p.total?p.tables/p.total*100:0)+'%'; o.querySelector('.convnow').textContent=p.name?p.name:''},
    finish(cv){return new Promise(res=>{
      q('t').textContent=cv.tables+' / '+cv.tables; q('a').textContent=cv.attrs.toLocaleString(); o.querySelector('.convbar i').style.width='100%';
      o.querySelector('h3').textContent='Conversion complete'; o.querySelector('.convnow').textContent='Template layout: Table Dictionary plus one tab per table.';
      const notes=[]; if(cv.miss.length) notes.push(cv.miss.length+' table'+(cv.miss.length===1?'':'s')+' had no matching tab, so they have no fields.'); if(cv.cut) notes.push(cv.cut+' over-long cell'+(cv.cut===1?'':'s')+' shortened to fit Excel.');
      o.querySelector('.convnote').textContent=notes.join(' ');
      const b=o.querySelector('.convbtns'); b.innerHTML='<button class="btn primary">Open</button>'; const go=()=>{o.remove();res()}; b.firstChild.onclick=go; b.firstChild.focus();
    })},
    close(){o.remove()}
  };
}
function loadFile(f,handle){ return new Promise(done=>{
  if(RO&&!/\.json$/i.test(f.name)){toast('This is a read-only copy: it shows '+EMBEDDED_NAME+' only');return done(false)}
  const r=new FileReader();
  r.onload=async ev=>{
    try{
      let u=new Uint8Array(ev.target.result);
      let wb=XLSX.read(u,XLSX_OPTS), fname=f.name, cv=null;
      if(isMetaExport(wb)){const mod=convModal(f.name); try{cv=await convertMetadata(wb,mod.update); await mod.finish(cv)}catch(e3){mod.close();throw e3} wb=cv.wb; cutReport(fitSheetJS(wb),'The converted workbook'); u=new Uint8Array(XLSX.write(wb,{type:'array',bookType:'xlsx'})); fname=f.name.replace(/\.xls$/i,'.xlsx'); handle=null}   // the converted workbook keeps the export's name
      const shs=parseWorkbook(wb);
      if(!shs.length) throw new Error('no usable sheets found');
      // nothing to compare with when the page was showing the empty starter template, or for a converted export
      const fresh=!!cv||isStarter();
      const prevSheets=S.sheets, prevName=S.fileName, prevB64=S.curB64;
      const nb=u8ToB64(u);
      // which project's edits apply to this file? A file seen before keeps its own; a new file with edits open asks
      const known=S.lib.find(r=>r.b64===nb&&r.proj);
      let proj;
      if(known) proj=known.proj;
      else if(!cv&&(S.edits.size||S.pending.length)){
        const n=S.edits.size+S.pending.length;
        const carry=await dlg({title:'Carry your edits over?',body:'You have '+n+' edit'+(n===1?'':'s')+' on <b>'+esc(prevName)+'</b>.<br><br>If <b>'+esc(fname)+'</b> is a <b>newer version of the same data model</b>, your edits are re-applied to it, and any that clash with a changed value are listed for you to check.<br><br>If it is a <b>different workbook</b>, it opens with no edits, and your edits stay with '+esc(prevName)+'.',ok:'Newer version: carry edits over',cancel:'Different workbook'});
        proj=carry?S.proj:newProj();
      } else proj=newProj();
      // a converted export is a new starting point: there is nothing meaningful to compare it with
      saveVersions(fresh?null:{name:prevName,b64:prevB64,proj:S.proj},{name:fname,b64:nb,proj});
      S.curB64=nb; S.prevB64=fresh?null:prevB64; S.handle=handle||null; S.proj=proj; S.restored=false;
      libAdd(fname,nb,{sheets:shs.length,tables:shs.filter(s=>s.kind==='entity').length},handle,proj);
      init(wb,fname,{prevSheets:fresh?null:prevSheets,prevName:prevName,announce:true});
      done(true);
    }catch(err){dlg({title:'Could not read that file',body:esc(err.message),ok:'OK',cancel:null,danger:true}); done(false)}
  };
  r.readAsArrayBuffer(f);
})}
(async()=>{try{
  {const tm=store.get('dme.tmpl');try{if(tm)loadTemplate(tm.b64,tm.name);else loadTemplate(TEMPLATE_B64,TEMPLATE_NAME)}catch(e){loadTemplate(TEMPLATE_B64,TEMPLATE_NAME)}}
  let cur=null, prev=null; try{cur=await idb.get('__cur');prev=await idb.get('__prev')}catch(e){}
  if(!cur&&!RO){cur=store.get('dme.cur');prev=store.get('dme.prev')}
  if(RO){cur=null;prev=null}
  const b64=cur?cur.b64:EMBEDDED_B64, name=cur?cur.name:EMBEDDED_NAME;
  S.curB64=b64; S.prevB64=(cur&&prev)?prev.b64:null;
  S.restored=!!cur&&b64!==EMBEDDED_B64;   // reopened from this browser: the Overview says so
  S.proj=RO?'readonly':cur?(cur.proj||'legacy'):'bundled';
  // one-off move: edits saved by the earlier version (one shared list) go to the workbook that was open then
  {const old=store.get(EDIT_STORE_OLD); if(old&&old.length&&!storedEdits(S.proj).length&&store.set(editKey(S.proj),old)) store.del(EDIT_STORE_OLD)}
  let prevSheets=null,prevName='';
  if(cur&&prev){try{prevSheets=parseWorkbook(XLSX.read(b64ToU8(prev.b64),XLSX_OPTS));prevName=prev.name}catch(e){}}
  init(XLSX.read(b64ToU8(b64),XLSX_OPTS),name,{prevSheets,prevName});
  wireFiles(); if(!RO) libLoad();
  if(LIVE){const b=$('#btnDv'); b.textContent='Environment'; b.title='Load a solution from this environment, or check the workbook against it'; b.classList.remove('hidebtn'); document.body.classList.add('live'); if(isStarter()) renderDv()}
}catch(err){
  $('#loading').innerHTML='<div>Open a workbook to begin (drag an .xlsx here)<br><br><button class="btn primary" onclick="document.getElementById(\'file\').click()">Open file…</button><br><small>'+esc(err.message)+'</small></div>';
}})();
})();
